"""
Example notebook demonstrating basic DSGE model functionality.

This notebook shows how to:
1. Load and initialize a DSGE model
2. Calibrate model parameters
3. Solve the model
4. Generate impulse response functions
5. Visualize the results
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Set plot style
plt.style.use('ggplot')
sns.set_context("notebook", font_scale=1.5)

# Add path to dsge_macro package
sys.path.append('..')

# Import DSGE model components
from dsge_macro.core.smets_wouters import SWModel
from dsge_macro.simulation.irf import IRFGenerator
from dsge_macro.simulation.forecast import Forecaster
from dsge_macro.simulation.variance import VarianceDecomposition
from dsge_macro.simulation.historical import HistoricalDecomposition

# Load data
data_path = '../data/us_dsge_dataset.csv'
data = pd.read_csv(data_path, index_col=0, parse_dates=True)

# Display basic information about the data
print("Data shape:", data.shape)
print("Date range:", data.index.min(), "to", data.index.max())
print("Variables:", ", ".join(data.columns))

# Create a Smets-Wouters model
model = SWModel()

# Display model information
print("\nModel Information:")
print("Name:", model.name)
print("Number of variables:", len(model.variables))
print("Number of parameters:", len(model.parameters))
print("Number of shocks:", len(model.shocks))

# Display model variables
print("\nModel Variables:")
print(", ".join(model.variables))

# Display model shocks
print("\nModel Shocks:")
print(", ".join(model.shocks))

# Display model parameters
print("\nModel Parameters (first 10):")
for i, (name, param) in enumerate(list(model.parameters.items())[:10]):
    print(f"{name}: {param['value']} ({param['description']})")

# Solve the model
model.solve()
print("\nModel solved successfully:", model.solved)

# Generate impulse response functions
irf_generator = IRFGenerator(model)

# Generate IRFs for a technology shock
tech_irf = irf_generator.generate_irf(shock="eps_a", periods=40, shock_size=0.01)

# Plot IRFs for key variables
variables_to_plot = ['y', 'c', 'i', 'l', 'r', 'pi', 'w']
fig, axes = plt.subplots(len(variables_to_plot), 1, figsize=(12, 15), sharex=True)

for i, var in enumerate(variables_to_plot):
    axes[i].plot(tech_irf[var].values)
    axes[i].set_title(f"Response of {var} to Technology Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.savefig("../figures/technology_shock_irf.png")
plt.close()

# Generate IRFs for a monetary policy shock
mp_irf = irf_generator.generate_irf(shock="eps_r", periods=40, shock_size=0.01)

# Plot IRFs for key variables
fig, axes = plt.subplots(len(variables_to_plot), 1, figsize=(12, 15), sharex=True)

for i, var in enumerate(variables_to_plot):
    axes[i].plot(mp_irf[var].values)
    axes[i].set_title(f"Response of {var} to Monetary Policy Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.savefig("../figures/monetary_shock_irf.png")
plt.close()

# Generate IRFs for a preference shock
pref_irf = irf_generator.generate_irf(shock="eps_b", periods=40, shock_size=0.01)

# Plot IRFs for key variables
fig, axes = plt.subplots(len(variables_to_plot), 1, figsize=(12, 15), sharex=True)

for i, var in enumerate(variables_to_plot):
    axes[i].plot(pref_irf[var].values)
    axes[i].set_title(f"Response of {var} to Preference Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.savefig("../figures/preference_shock_irf.png")
plt.close()

# Compare IRFs across different shocks
fig, axes = plt.subplots(2, 2, figsize=(15, 10))

# Output response
axes[0, 0].plot(tech_irf['y'].values, label='Technology Shock')
axes[0, 0].plot(mp_irf['y'].values, label='Monetary Policy Shock')
axes[0, 0].plot(pref_irf['y'].values, label='Preference Shock')
axes[0, 0].set_title("Output Response")
axes[0, 0].set_ylabel("Deviation from SS")
axes[0, 0].legend()

# Inflation response
axes[0, 1].plot(tech_irf['pi'].values, label='Technology Shock')
axes[0, 1].plot(mp_irf['pi'].values, label='Monetary Policy Shock')
axes[0, 1].plot(pref_irf['pi'].values, label='Preference Shock')
axes[0, 1].set_title("Inflation Response")
axes[0, 1].set_ylabel("Deviation from SS")
axes[0, 1].legend()

# Interest rate response
axes[1, 0].plot(tech_irf['r'].values, label='Technology Shock')
axes[1, 0].plot(mp_irf['r'].values, label='Monetary Policy Shock')
axes[1, 0].plot(pref_irf['r'].values, label='Preference Shock')
axes[1, 0].set_title("Interest Rate Response")
axes[1, 0].set_ylabel("Deviation from SS")
axes[1, 0].set_xlabel("Quarters")
axes[1, 0].legend()

# Consumption response
axes[1, 1].plot(tech_irf['c'].values, label='Technology Shock')
axes[1, 1].plot(mp_irf['c'].values, label='Monetary Policy Shock')
axes[1, 1].plot(pref_irf['c'].values, label='Preference Shock')
axes[1, 1].set_title("Consumption Response")
axes[1, 1].set_ylabel("Deviation from SS")
axes[1, 1].set_xlabel("Quarters")
axes[1, 1].legend()

plt.tight_layout()
plt.savefig("../figures/comparison_irf.png")
plt.close()

# Compute variance decomposition
vd = VarianceDecomposition(model)
variance_decomp = vd.compute_variance_decomposition()

# Plot variance decomposition for output
output_decomp = variance_decomp['y']
plt.figure(figsize=(10, 6))
plt.bar(range(len(output_decomp)), output_decomp.values)
plt.xticks(range(len(output_decomp)), output_decomp.index, rotation=45)
plt.title("Variance Decomposition of Output")
plt.ylabel("Contribution (%)")
plt.tight_layout()
plt.savefig("../figures/output_variance_decomp.png")
plt.close()

# Generate forecast
forecaster = Forecaster(model)
forecast = forecaster.generate_forecast(periods=20, n_simulations=100)

# Plot forecast for output
plt.figure(figsize=(10, 6))
plt.plot(forecast['y'].mean(axis=0), label='Mean Forecast')
plt.fill_between(
    range(len(forecast['y'].mean(axis=0))),
    np.percentile(forecast['y'].values, 10, axis=0),
    np.percentile(forecast['y'].values, 90, axis=0),
    alpha=0.3,
    label='80% Confidence Interval'
)
plt.title("Output Forecast")
plt.xlabel("Quarters")
plt.ylabel("Deviation from SS")
plt.legend()
plt.tight_layout()
plt.savefig("../figures/output_forecast.png")
plt.close()

print("\nExample notebook completed successfully!")
print("All figures saved to the 'figures' directory.")
