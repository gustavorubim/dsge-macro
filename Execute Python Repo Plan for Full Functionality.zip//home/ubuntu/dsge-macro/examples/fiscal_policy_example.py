"""
Example notebook demonstrating fiscal policy extension for DSGE models.

This notebook shows how to:
1. Initialize a DSGE model with fiscal policy extension
2. Calibrate fiscal policy parameters
3. Solve the model
4. Generate impulse response functions to fiscal shocks
5. Compute fiscal multipliers
6. Analyze debt sustainability
7. Visualize the results
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Set plot style
plt.style.use('ggplot')
sns.set_context("notebook", font_scale=1.5)

# Add path to dsge_macro package
sys.path.append('..')

# Import DSGE model components
from dsge_macro.extensions.fiscal import FiscalSWModel
from dsge_macro.simulation.irf import IRFGenerator
from dsge_macro.simulation.forecast import Forecaster

# Create directory for figures if it doesn't exist
os.makedirs("../figures", exist_ok=True)

# Load data
data_path = '../data/us_dsge_dataset.csv'
data = pd.read_csv(data_path, index_col=0, parse_dates=True)

# Display basic information about the data
print("Data shape:", data.shape)
print("Date range:", data.index.min(), "to", data.index.max())
print("Variables:", ", ".join(data.columns))

# Create a Fiscal Smets-Wouters model with debt-based fiscal rule
model = FiscalSWModel(fiscal_rule="debt")

# Display model information
print("\nModel Information:")
print("Name:", model.name)
print("Number of variables:", len(model.variables))
print("Number of parameters:", len(model.parameters))
print("Number of shocks:", len(model.shocks))
print("Fiscal rule:", model.fiscal_rule)

# Display fiscal policy variables
fiscal_vars = ['g', 'b', 'tau', 't', 'def']
print("\nFiscal Policy Variables:")
print(", ".join(fiscal_vars))

# Display fiscal policy parameters
fiscal_params = ['g_y_ratio', 'b_y_ratio', 'tau_ss', 'phi_b', 'phi_y', 'rho_g', 'rho_tau']
print("\nFiscal Policy Parameters:")
for name in fiscal_params:
    param = model.parameters[name]
    print(f"{name}: {param['value']} ({param['description']})")

# Calibrate fiscal policy parameters to match US data
# Set government spending to GDP ratio
model.parameters['g_y_ratio']['value'] = 0.2
# Set debt to GDP ratio
model.parameters['b_y_ratio']['value'] = 0.8
# Set tax rate
model.parameters['tau_ss']['value'] = 0.25
# Set fiscal policy response to debt
model.parameters['phi_b']['value'] = 0.1
# Set fiscal policy response to output
model.parameters['phi_y']['value'] = 0.2
# Set government spending persistence
model.parameters['rho_g']['value'] = 0.9
# Set tax rate persistence
model.parameters['rho_tau']['value'] = 0.8

print("\nCalibrated Fiscal Policy Parameters:")
for name in fiscal_params:
    param = model.parameters[name]
    print(f"{name}: {param['value']} ({param['description']})")

# Solve the model
model.solve()
print("\nModel solved successfully:", model.solved)

# Generate impulse response functions
irf_generator = IRFGenerator(model)

# Generate IRFs for a government spending shock
g_irf = irf_generator.generate_irf(shock="eps_g", periods=40, shock_size=0.01)

# Plot IRFs for key variables
variables_to_plot = ['y', 'c', 'i', 'g', 'tau', 'b', 'def']
fig, axes = plt.subplots(len(variables_to_plot), 1, figsize=(12, 15), sharex=True)

for i, var in enumerate(variables_to_plot):
    axes[i].plot(g_irf[var].values)
    axes[i].set_title(f"Response of {var} to Government Spending Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.savefig("../figures/government_spending_shock_irf.png")
plt.close()

# Generate IRFs for a tax rate shock
tau_irf = irf_generator.generate_irf(shock="eps_tau", periods=40, shock_size=0.01)

# Plot IRFs for key variables
fig, axes = plt.subplots(len(variables_to_plot), 1, figsize=(12, 15), sharex=True)

for i, var in enumerate(variables_to_plot):
    axes[i].plot(tau_irf[var].values)
    axes[i].set_title(f"Response of {var} to Tax Rate Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.savefig("../figures/tax_rate_shock_irf.png")
plt.close()

# Compare output response to different fiscal shocks
plt.figure(figsize=(10, 6))
plt.plot(g_irf['y'].values, label='Government Spending Shock')
plt.plot(tau_irf['y'].values, label='Tax Rate Shock')
plt.title("Output Response to Fiscal Shocks")
plt.xlabel("Quarters")
plt.ylabel("Deviation from SS")
plt.legend()
plt.tight_layout()
plt.savefig("../figures/output_response_fiscal_shocks.png")
plt.close()

# Compute fiscal multipliers
multipliers = model.get_fiscal_multiplier(horizon=20, shock_size=0.01)

print("\nFiscal Multipliers:")
print(f"Impact Multiplier: {multipliers['impact']:.3f}")
print(f"Cumulative Multiplier: {multipliers['cumulative']:.3f}")
print(f"Present Value Multiplier: {multipliers['present_value']:.3f}")

# Plot fiscal multipliers
plt.figure(figsize=(8, 6))
plt.bar(['Impact', 'Cumulative', 'Present Value'], 
        [multipliers['impact'], multipliers['cumulative'], multipliers['present_value']])
plt.title("Fiscal Multipliers")
plt.ylabel("Multiplier Value")
plt.tight_layout()
plt.savefig("../figures/fiscal_multipliers.png")
plt.close()

# Analyze debt sustainability
# Compare debt dynamics under different initial debt levels
initial_debt_levels = [0.6, 0.8, 1.0, 1.2]
periods = 40

plt.figure(figsize=(10, 6))

for debt in initial_debt_levels:
    # Compute debt sustainability analysis
    debt_analysis = model.compute_debt_sustainability(initial_debt=debt, periods=periods)
    
    # Plot debt-to-GDP ratio
    plt.plot(debt_analysis['debt_to_gdp'], label=f'Initial Debt: {debt*100:.0f}% of GDP')

plt.title("Debt-to-GDP Ratio Dynamics")
plt.xlabel("Quarters")
plt.ylabel("Debt-to-GDP Ratio")
plt.legend()
plt.tight_layout()
plt.savefig("../figures/debt_sustainability.png")
plt.close()

# Compare different fiscal rules
fiscal_rules = ["debt", "balanced", "exogenous"]
rule_labels = ["Debt-Based Rule", "Balanced Budget", "Exogenous Tax Rate"]

# Create figure for output response to government spending shock
plt.figure(figsize=(10, 6))

for rule, label in zip(fiscal_rules, rule_labels):
    # Create model with specific fiscal rule
    model_rule = FiscalSWModel(fiscal_rule=rule)
    
    # Solve the model
    model_rule.solve()
    
    # Generate IRFs for a government spending shock
    irf_gen = IRFGenerator(model_rule)
    g_irf_rule = irf_gen.generate_irf(shock="eps_g", periods=40, shock_size=0.01)
    
    # Plot output response
    plt.plot(g_irf_rule['y'].values, label=label)

plt.title("Output Response to Government Spending Shock Under Different Fiscal Rules")
plt.xlabel("Quarters")
plt.ylabel("Deviation from SS")
plt.legend()
plt.tight_layout()
plt.savefig("../figures/output_response_fiscal_rules.png")
plt.close()

# Create figure for debt response to government spending shock
plt.figure(figsize=(10, 6))

for rule, label in zip(fiscal_rules, rule_labels):
    # Create model with specific fiscal rule
    model_rule = FiscalSWModel(fiscal_rule=rule)
    
    # Solve the model
    model_rule.solve()
    
    # Generate IRFs for a government spending shock
    irf_gen = IRFGenerator(model_rule)
    g_irf_rule = irf_gen.generate_irf(shock="eps_g", periods=40, shock_size=0.01)
    
    # Plot debt response
    plt.plot(g_irf_rule['b'].values, label=label)

plt.title("Debt Response to Government Spending Shock Under Different Fiscal Rules")
plt.xlabel("Quarters")
plt.ylabel("Deviation from SS")
plt.legend()
plt.tight_layout()
plt.savefig("../figures/debt_response_fiscal_rules.png")
plt.close()

# Generate stochastic simulations with fiscal policy
forecaster = Forecaster(model)
forecast = forecaster.generate_forecast(periods=40, n_simulations=100)

# Plot stochastic simulations for key fiscal variables
fiscal_vars_to_plot = ['g', 'tau', 'b', 'def']
fig, axes = plt.subplots(2, 2, figsize=(15, 10))

for i, var in enumerate(fiscal_vars_to_plot):
    row = i // 2
    col = i % 2
    
    # Plot mean forecast
    axes[row, col].plot(forecast[var].mean(axis=0), label='Mean')
    
    # Plot confidence intervals
    axes[row, col].fill_between(
        range(len(forecast[var].mean(axis=0))),
        np.percentile(forecast[var].values, 10, axis=0),
        np.percentile(forecast[var].values, 90, axis=0),
        alpha=0.3,
        label='80% Confidence Interval'
    )
    
    axes[row, col].set_title(f"{var} Forecast")
    axes[row, col].set_xlabel("Quarters")
    axes[row, col].set_ylabel("Deviation from SS")
    axes[row, col].legend()

plt.tight_layout()
plt.savefig("../figures/fiscal_variables_forecast.png")
plt.close()

print("\nFiscal policy example completed successfully!")
print("All figures saved to the 'figures' directory.")
