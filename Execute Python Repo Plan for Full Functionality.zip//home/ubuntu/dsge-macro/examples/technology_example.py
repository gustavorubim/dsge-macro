"""
Example notebook demonstrating technology enhancements for DSGE models.

This notebook shows how to:
1. Initialize a DSGE model with technology enhancements
2. Calibrate technology parameters
3. Solve the model
4. Generate impulse response functions to technology shocks
5. Analyze growth accounting
6. Visualize the results
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Set plot style
plt.style.use('ggplot')
sns.set_context("notebook", font_scale=1.5)

# Add path to dsge_macro package
sys.path.append('..')

# Import DSGE model components
from dsge_macro.extensions.technology import TechnologySWModel
from dsge_macro.simulation.irf import IRFGenerator
from dsge_macro.simulation.forecast import Forecaster

# Create directory for figures if it doesn't exist
os.makedirs("../figures", exist_ok=True)

# Load data
data_path = '../data/us_dsge_dataset.csv'
data = pd.read_csv(data_path, index_col=0, parse_dates=True)

# Display basic information about the data
print("Data shape:", data.shape)
print("Date range:", data.index.min(), "to", data.index.max())
print("Variables:", ", ".join(data.columns))

# Create technology-enhanced models with different technology types
tech_types = ["ist", "rd", "endogenous"]
models = {}

for tech_type in tech_types:
    models[tech_type] = TechnologySWModel(tech_type=tech_type)
    
# Display model information for the IST model
ist_model = models["ist"]
print("\nModel Information (IST Model):")
print("Name:", ist_model.name)
print("Number of variables:", len(ist_model.variables))
print("Number of parameters:", len(ist_model.parameters))
print("Number of shocks:", len(ist_model.shocks))
print("Technology type:", ist_model.tech_type)

# Display technology variables for each model
print("\nTechnology Variables by Model Type:")
for tech_type, model in models.items():
    if tech_type == "ist":
        tech_vars = ['z', 'mu']
    elif tech_type == "rd":
        tech_vars = ['z', 'rd', 'a', 's']
    else:  # endogenous
        tech_vars = ['z', 'mu', 'rd', 'a', 's']
        
    print(f"{tech_type.upper()}: {', '.join(tech_vars)}")

# Display technology parameters for the IST model
tech_params = ['rho_z', 'rho_mu', 'gamma_mu', 'sigma_eps_z', 'sigma_eps_mu']
print("\nTechnology Parameters (IST Model):")
for name in tech_params:
    if name in ist_model.parameters:
        param = ist_model.parameters[name]
        print(f"{name}: {param['value']} ({param['description']})")

# Display technology parameters for the R&D model
rd_model = models["rd"]
rd_params = ['rho_z', 'phi', 'lambda', 'psi_rd', 'rd_y_ratio', 'delta_a', 'sigma_eps_z', 'sigma_eps_rd']
print("\nTechnology Parameters (R&D Model):")
for name in rd_params:
    if name in rd_model.parameters:
        param = rd_model.parameters[name]
        print(f"{name}: {param['value']} ({param['description']})")

# Solve the IST model
ist_model.solve()
print("\nIST Model solved successfully:", ist_model.solved)

# Generate impulse response functions for the IST model
irf_generator = IRFGenerator(ist_model)

# Generate IRFs for a neutral technology shock
z_irf = irf_generator.generate_irf(shock="eps_z", periods=40, shock_size=0.01)

# Plot IRFs for key variables
variables_to_plot = ['y', 'c', 'i', 'l', 'r', 'pi', 'w', 'z']
fig, axes = plt.subplots(len(variables_to_plot), 1, figsize=(12, 15), sharex=True)

for i, var in enumerate(variables_to_plot):
    axes[i].plot(z_irf[var].values)
    axes[i].set_title(f"Response of {var} to Neutral Technology Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.savefig("../figures/neutral_technology_shock_irf.png")
plt.close()

# Generate IRFs for an investment-specific technology shock
mu_irf = irf_generator.generate_irf(shock="eps_mu", periods=40, shock_size=0.01)

# Plot IRFs for key variables
variables_to_plot = ['y', 'c', 'i', 'l', 'r', 'pi', 'w', 'mu']
fig, axes = plt.subplots(len(variables_to_plot), 1, figsize=(12, 15), sharex=True)

for i, var in enumerate(variables_to_plot):
    axes[i].plot(mu_irf[var].values)
    axes[i].set_title(f"Response of {var} to Investment-Specific Technology Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.savefig("../figures/ist_shock_irf.png")
plt.close()

# Compare output response to different technology shocks
plt.figure(figsize=(10, 6))
plt.plot(z_irf['y'].values, label='Neutral Technology Shock')
plt.plot(mu_irf['y'].values, label='Investment-Specific Technology Shock')
plt.title("Output Response to Technology Shocks")
plt.xlabel("Quarters")
plt.ylabel("Deviation from SS")
plt.legend()
plt.tight_layout()
plt.savefig("../figures/output_response_technology_shocks.png")
plt.close()

# Solve the R&D model
rd_model.solve()
print("\nR&D Model solved successfully:", rd_model.solved)

# Generate impulse response functions for the R&D model
rd_irf_generator = IRFGenerator(rd_model)

# Generate IRFs for an R&D shock
rd_irf = rd_irf_generator.generate_irf(shock="eps_rd", periods=40, shock_size=0.01)

# Plot IRFs for key variables
variables_to_plot = ['y', 'c', 'i', 'l', 'r', 'pi', 'w', 'a', 'rd', 's']
fig, axes = plt.subplots(len(variables_to_plot), 1, figsize=(12, 20), sharex=True)

for i, var in enumerate(variables_to_plot):
    axes[i].plot(rd_irf[var].values)
    axes[i].set_title(f"Response of {var} to R&D Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.savefig("../figures/rd_shock_irf.png")
plt.close()

# Solve the endogenous growth model
endo_model = models["endogenous"]
endo_model.solve()
print("\nEndogenous Growth Model solved successfully:", endo_model.solved)

# Generate impulse response functions for the endogenous growth model
endo_irf_generator = IRFGenerator(endo_model)

# Generate IRFs for a neutral technology shock in the endogenous growth model
endo_z_irf = endo_irf_generator.generate_irf(shock="eps_z", periods=40, shock_size=0.01)

# Compare output response to neutral technology shock across different models
plt.figure(figsize=(10, 6))
plt.plot(z_irf['y'].values, label='IST Model')
plt.plot(rd_irf_generator.generate_irf(shock="eps_z", periods=40, shock_size=0.01)['y'].values, 
         label='R&D Model')
plt.plot(endo_z_irf['y'].values, label='Endogenous Growth Model')
plt.title("Output Response to Neutral Technology Shock Across Models")
plt.xlabel("Quarters")
plt.ylabel("Deviation from SS")
plt.legend()
plt.tight_layout()
plt.savefig("../figures/output_response_across_models.png")
plt.close()

# Create synthetic data for growth accounting
np.random.seed(42)
years = range(1980, 2021)
n_years = len(years)

# Create synthetic growth accounting data
growth_data = pd.DataFrame({
    'y': np.exp(np.log(100) + 0.025 * np.arange(n_years) + 0.03 * np.sin(np.arange(n_years) / 3) + 0.01 * np.random.randn(n_years)),
    'k': np.exp(np.log(300) + 0.02 * np.arange(n_years) + 0.02 * np.sin(np.arange(n_years) / 4) + 0.005 * np.random.randn(n_years)),
    'l': np.exp(np.log(100) + 0.01 * np.arange(n_years) + 0.01 * np.sin(np.arange(n_years) / 5) + 0.005 * np.random.randn(n_years))
}, index=years)

# Compute growth accounting decomposition
growth_accounting = ist_model.compute_growth_accounting(growth_data)

# Plot growth accounting decomposition
plt.figure(figsize=(12, 6))
plt.bar(growth_accounting.index, growth_accounting['capital_contrib'], label='Capital Contribution')
plt.bar(growth_accounting.index, growth_accounting['labor_contrib'], bottom=growth_accounting['capital_contrib'], label='Labor Contribution')
plt.bar(growth_accounting.index, growth_accounting['tfp_contrib'], 
        bottom=growth_accounting['capital_contrib'] + growth_accounting['labor_contrib'], label='TFP Contribution')
plt.plot(growth_accounting.index, growth_accounting['output_growth'], 'k-', linewidth=2, label='Output Growth')
plt.title("Growth Accounting Decomposition")
plt.xlabel("Year")
plt.ylabel("Growth Rate (%)")
plt.legend()
plt.tight_layout()
plt.savefig("../figures/growth_accounting.png")
plt.close()

# Create synthetic data for technology trends
tech_trends_data = pd.DataFrame({
    'y': np.exp(np.log(100) + 0.025 * np.arange(n_years) + 0.03 * np.sin(np.arange(n_years) / 3) + 0.01 * np.random.randn(n_years)),
    'i': np.exp(np.log(20) + 0.03 * np.arange(n_years) + 0.05 * np.sin(np.arange(n_years) / 2) + 0.02 * np.random.randn(n_years))
}, index=years)

# Compute technology trends
tech_trends = ist_model.compute_technology_trends(tech_trends_data)

# Plot technology trends
plt.figure(figsize=(12, 6))
plt.plot(tech_trends.index, tech_trends['neutral_tech_trend'], label='Neutral Technology')
plt.plot(tech_trends.index, tech_trends['ist_trend'], label='Investment-Specific Technology')
plt.title("Technology Trends")
plt.xlabel("Year")
plt.ylabel("Growth Rate (%)")
plt.legend()
plt.tight_layout()
plt.savefig("../figures/technology_trends.png")
plt.close()

# Generate stochastic simulations with technology shocks
forecaster = Forecaster(ist_model)
forecast = forecaster.generate_forecast(periods=40, n_simulations=100)

# Plot stochastic simulations for key technology variables
tech_vars_to_plot = ['y', 'z', 'mu']
fig, axes = plt.subplots(len(tech_vars_to_plot), 1, figsize=(12, 10))

for i, var in enumerate(tech_vars_to_plot):
    # Plot mean forecast
    axes[i].plot(forecast[var].mean(axis=0), label='Mean')
    
    # Plot confidence intervals
    axes[i].fill_between(
        range(len(forecast[var].mean(axis=0))),
        np.percentile(forecast[var].values, 10, axis=0),
        np.percentile(forecast[var].values, 90, axis=0),
        alpha=0.3,
        label='80% Confidence Interval'
    )
    
    axes[i].set_title(f"{var} Forecast")
    axes[i].set_xlabel("Quarters")
    axes[i].set_ylabel("Deviation from SS")
    axes[i].legend()

plt.tight_layout()
plt.savefig("../figures/technology_variables_forecast.png")
plt.close()

print("\nTechnology enhancements example completed successfully!")
print("All figures saved to the 'figures' directory.")
