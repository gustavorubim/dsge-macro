"""
Example notebook demonstrating financial frictions for DSGE models.

This notebook shows how to:
1. Initialize a DSGE model with financial frictions
2. Calibrate financial parameters
3. Solve the model
4. Generate impulse response functions to financial shocks
5. Analyze financial conditions and stress indicators
6. Visualize the results
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Set plot style
plt.style.use('ggplot')
sns.set_context("notebook", font_scale=1.5)

# Add path to dsge_macro package
sys.path.append('..')

# Import DSGE model components
from dsge_macro.extensions.financial import FinancialSWModel
from dsge_macro.simulation.irf import IRFGenerator
from dsge_macro.simulation.forecast import Forecaster

# Create directory for figures if it doesn't exist
os.makedirs("../figures", exist_ok=True)

# Load data
data_path = '../data/us_dsge_dataset.csv'
data = pd.read_csv(data_path, index_col=0, parse_dates=True)

# Display basic information about the data
print("Data shape:", data.shape)
print("Date range:", data.index.min(), "to", data.index.max())
print("Variables:", ", ".join(data.columns))

# Create financial-enhanced models with different friction types
friction_types = ["accelerator", "collateral", "banking"]
models = {}

for friction_type in friction_types:
    models[friction_type] = FinancialSWModel(friction_type=friction_type)
    
# Display model information for the financial accelerator model
fa_model = models["accelerator"]
print("\nModel Information (Financial Accelerator Model):")
print("Name:", fa_model.name)
print("Number of variables:", len(fa_model.variables))
print("Number of parameters:", len(fa_model.parameters))
print("Number of shocks:", len(fa_model.shocks))
print("Friction type:", fa_model.friction_type)

# Display financial variables for each model
print("\nFinancial Variables by Model Type:")
for friction_type, model in models.items():
    if friction_type == "accelerator":
        fin_vars = ['efp', 'n', 'lev', 'rk']
    elif friction_type == "collateral":
        fin_vars = ['efp', 'n', 'lambda_b', 'ltv', 'b']
    else:  # banking
        fin_vars = ['efp', 'n', 'kb', 'l', 'rd', 'rl', 'levb']
        
    print(f"{friction_type.upper()}: {', '.join(fin_vars)}")

# Display financial parameters for the financial accelerator model
fin_params = ['efp_ss', 'rho_n', 'chi', 'gamma_e', 'lev_ss', 'sigma_eps_n', 'sigma_eps_efp']
print("\nFinancial Parameters (Financial Accelerator Model):")
for name in fin_params:
    if name in fa_model.parameters:
        param = fa_model.parameters[name]
        print(f"{name}: {param['value']} ({param['description']})")

# Display financial parameters for the collateral constraints model
cc_model = models["collateral"]
cc_params = ['efp_ss', 'rho_n', 'ltv_ss', 'rho_ltv', 'sigma_eps_n', 'sigma_eps_ltv']
print("\nFinancial Parameters (Collateral Constraints Model):")
for name in cc_params:
    if name in cc_model.parameters:
        param = cc_model.parameters[name]
        print(f"{name}: {param['value']} ({param['description']})")

# Display financial parameters for the banking model
bank_model = models["banking"]
bank_params = ['efp_ss', 'rho_n', 'kappa', 'psi_b', 'rho_kb', 'levb_ss', 'sigma_eps_n', 'sigma_eps_kb']
print("\nFinancial Parameters (Banking Model):")
for name in bank_params:
    if name in bank_model.parameters:
        param = bank_model.parameters[name]
        print(f"{name}: {param['value']} ({param['description']})")

# Calibrate financial accelerator model parameters
fa_model.parameters['efp_ss']['value'] = 0.005  # 50 basis points steady-state premium
fa_model.parameters['chi']['value'] = 0.05      # Elasticity of EFP to leverage
fa_model.parameters['lev_ss']['value'] = 2.0    # Steady-state leverage ratio
fa_model.parameters['gamma_e']['value'] = 0.975 # Survival rate of entrepreneurs
fa_model.parameters['rho_n']['value'] = 0.9     # Net worth persistence

print("\nCalibrated Financial Accelerator Parameters:")
for name in fin_params:
    if name in fa_model.parameters:
        param = fa_model.parameters[name]
        print(f"{name}: {param['value']} ({param['description']})")

# Solve the financial accelerator model
fa_model.solve()
print("\nFinancial Accelerator Model solved successfully:", fa_model.solved)

# Generate impulse response functions for the financial accelerator model
irf_generator = IRFGenerator(fa_model)

# Generate IRFs for a net worth shock
n_irf = irf_generator.generate_irf(shock="eps_n", periods=40, shock_size=-0.01)  # Negative shock

# Plot IRFs for key variables
variables_to_plot = ['y', 'c', 'i', 'l', 'r', 'pi', 'efp', 'n', 'lev']
fig, axes = plt.subplots(len(variables_to_plot), 1, figsize=(12, 18), sharex=True)

for i, var in enumerate(variables_to_plot):
    axes[i].plot(n_irf[var].values)
    axes[i].set_title(f"Response of {var} to Net Worth Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.savefig("../figures/net_worth_shock_irf.png")
plt.close()

# Generate IRFs for an external finance premium shock
efp_irf = irf_generator.generate_irf(shock="eps_efp", periods=40, shock_size=0.01)

# Plot IRFs for key variables
fig, axes = plt.subplots(len(variables_to_plot), 1, figsize=(12, 18), sharex=True)

for i, var in enumerate(variables_to_plot):
    axes[i].plot(efp_irf[var].values)
    axes[i].set_title(f"Response of {var} to External Finance Premium Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.savefig("../figures/efp_shock_irf.png")
plt.close()

# Compare output response to different financial shocks
plt.figure(figsize=(10, 6))
plt.plot(n_irf['y'].values, label='Net Worth Shock')
plt.plot(efp_irf['y'].values, label='External Finance Premium Shock')
plt.title("Output Response to Financial Shocks")
plt.xlabel("Quarters")
plt.ylabel("Deviation from SS")
plt.legend()
plt.tight_layout()
plt.savefig("../figures/output_response_financial_shocks.png")
plt.close()

# Solve the collateral constraints model
cc_model.solve()
print("\nCollateral Constraints Model solved successfully:", cc_model.solved)

# Generate impulse response functions for the collateral constraints model
cc_irf_generator = IRFGenerator(cc_model)

# Generate IRFs for a loan-to-value shock
ltv_irf = cc_irf_generator.generate_irf(shock="eps_ltv", periods=40, shock_size=-0.01)  # Negative shock

# Plot IRFs for key variables
cc_variables = ['y', 'c', 'i', 'l', 'r', 'pi', 'efp', 'n', 'b', 'ltv']
fig, axes = plt.subplots(len(cc_variables), 1, figsize=(12, 20), sharex=True)

for i, var in enumerate(cc_variables):
    axes[i].plot(ltv_irf[var].values)
    axes[i].set_title(f"Response of {var} to Loan-to-Value Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.savefig("../figures/ltv_shock_irf.png")
plt.close()

# Solve the banking model
bank_model.solve()
print("\nBanking Model solved successfully:", bank_model.solved)

# Generate impulse response functions for the banking model
bank_irf_generator = IRFGenerator(bank_model)

# Generate IRFs for a bank capital shock
kb_irf = bank_irf_generator.generate_irf(shock="eps_kb", periods=40, shock_size=-0.01)  # Negative shock

# Plot IRFs for key variables
bank_variables = ['y', 'c', 'i', 'l', 'r', 'pi', 'efp', 'n', 'kb', 'levb', 'rl', 'rd']
fig, axes = plt.subplots(len(bank_variables), 1, figsize=(12, 24), sharex=True)

for i, var in enumerate(bank_variables):
    axes[i].plot(kb_irf[var].values)
    axes[i].set_title(f"Response of {var} to Bank Capital Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.savefig("../figures/bank_capital_shock_irf.png")
plt.close()

# Compare output response to financial shocks across different models
plt.figure(figsize=(10, 6))
plt.plot(n_irf['y'].values, label='Net Worth Shock (Financial Accelerator)')
plt.plot(ltv_irf['y'].values, label='LTV Shock (Collateral Constraints)')
plt.plot(kb_irf['y'].values, label='Bank Capital Shock (Banking)')
plt.title("Output Response to Financial Shocks Across Models")
plt.xlabel("Quarters")
plt.ylabel("Deviation from SS")
plt.legend()
plt.tight_layout()
plt.savefig("../figures/output_response_across_financial_models.png")
plt.close()

# Create synthetic data for financial conditions analysis
np.random.seed(42)
dates = pd.date_range(start='2000-01-01', periods=80, freq='Q')
n_periods = len(dates)

# Create synthetic financial data
financial_data = pd.DataFrame({
    'efp': 0.005 + 0.002 * np.sin(np.arange(n_periods) / 8) + 0.001 * np.random.randn(n_periods),
    'r': 0.02 + 0.01 * np.sin(np.arange(n_periods) / 10) + 0.002 * np.random.randn(n_periods),
    'lev': 2.0 + 0.2 * np.sin(np.arange(n_periods) / 6) + 0.1 * np.random.randn(n_periods),
    'ltv': 0.7 + 0.05 * np.sin(np.arange(n_periods) / 12) + 0.02 * np.random.randn(n_periods),
    'levb': 10.0 + 1.0 * np.sin(np.arange(n_periods) / 8) + 0.5 * np.random.randn(n_periods),
    'rl': 0.025 + 0.01 * np.sin(np.arange(n_periods) / 10) + 0.002 * np.random.randn(n_periods)
}, index=dates)

# Compute financial conditions index for each model
fa_fci = fa_model.compute_financial_conditions_index(financial_data)
cc_fci = cc_model.compute_financial_conditions_index(financial_data)
bank_fci = bank_model.compute_financial_conditions_index(financial_data)

# Plot financial conditions indices
plt.figure(figsize=(12, 6))
plt.plot(fa_fci.index, fa_fci, label='Financial Accelerator')
plt.plot(cc_fci.index, cc_fci, label='Collateral Constraints')
plt.plot(bank_fci.index, bank_fci, label='Banking')
plt.title("Financial Conditions Index")
plt.xlabel("Date")
plt.ylabel("Index Value (0 = Average)")
plt.axhline(y=0, color='k', linestyle='--', alpha=0.5)
plt.legend()
plt.tight_layout()
plt.savefig("../figures/financial_conditions_index.png")
plt.close()

# Compute financial stress indicators
fa_stress = fa_model.compute_financial_stress(financial_data)

# Plot financial stress indicators
fig, axes = plt.subplots(3, 1, figsize=(12, 10), sharex=True)

# Plot FCI
axes[0].plot(fa_stress['fci'])
axes[0].set_title("Financial Conditions Index")
axes[0].set_ylabel("Index Value")
axes[0].axhline(y=0, color='k', linestyle='--', alpha=0.5)

# Plot stress indicator
axes[1].plot(fa_stress['stress_indicator'])
axes[1].set_title("Financial Stress Indicator")
axes[1].set_ylabel("Stress (0/1)")

# Plot stress probability
axes[2].plot(fa_stress['stress_probability'])
axes[2].set_title("Financial Stress Probability")
axes[2].set_ylabel("Probability")
axes[2].set_xlabel("Date")

plt.tight_layout()
plt.savefig("../figures/financial_stress_indicators.png")
plt.close()

# Generate stochastic simulations with financial shocks
forecaster = Forecaster(fa_model)
forecast = forecaster.generate_forecast(periods=40, n_simulations=100)

# Plot stochastic simulations for key financial variables
fin_vars_to_plot = ['y', 'efp', 'n', 'lev']
fig, axes = plt.subplots(2, 2, figsize=(15, 10))

for i, var in enumerate(fin_vars_to_plot):
    row = i // 2
    col = i % 2
    
    # Plot mean forecast
    axes[row, col].plot(forecast[var].mean(axis=0), label='Mean')
    
    # Plot confidence intervals
    axes[row, col].fill_between(
        range(len(forecast[var].mean(axis=0))),
        np.percentile(forecast[var].values, 10, axis=0),
        np.percentile(forecast[var].values, 90, axis=0),
        alpha=0.3,
        label='80% Confidence Interval'
    )
    
    axes[row, col].set_title(f"{var} Forecast")
    axes[row, col].set_xlabel("Quarters")
    axes[row, col].set_ylabel("Deviation from SS")
    axes[row, col].legend()

plt.tight_layout()
plt.savefig("../figures/financial_variables_forecast.png")
plt.close()

# Create a figure showing the financial accelerator mechanism
plt.figure(figsize=(12, 8))

# Create a sequence of leverage values
leverage = np.linspace(1.5, 3.0, 100)

# Compute external finance premium for different elasticities
chi_values = [0.02, 0.05, 0.1]
for chi in chi_values:
    efp = chi * (leverage - fa_model.parameters['lev_ss']['value'])
    plt.plot(leverage, efp * 100, label=f'χ = {chi}')

plt.title("Financial Accelerator Mechanism")
plt.xlabel("Leverage Ratio")
plt.ylabel("External Finance Premium (basis points)")
plt.axvline(x=fa_model.parameters['lev_ss']['value'], color='k', linestyle='--', alpha=0.5, 
            label=f"Steady-State Leverage ({fa_model.parameters['lev_ss']['value']})")
plt.axhline(y=0, color='k', linestyle='-', alpha=0.3)
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("../figures/financial_accelerator_mechanism.png")
plt.close()

print("\nFinancial frictions example completed successfully!")
print("All figures saved to the 'figures' directory.")
