# Getting Started with DSGE-Macro

This tutorial will guide you through the basic steps of using the DSGE-Macro package for macroeconomic modeling and analysis.

## Installation

First, install the package:

```bash
pip install -e .
```

For development, install with additional dependencies:

```bash
pip install -e ".[dev]"
```

## Basic Usage

### Creating and Solving a Model

Let's start by creating a basic Smets-Wouters model:

```python
import numpy as np
import matplotlib.pyplot as plt
from dsge_macro.core.smets_wouters import SWModel

# Create a Smets-Wouters model
model = SWModel()

# Display model information
print(f"Model: {model.name}")
print(f"Number of variables: {len(model.variables)}")
print(f"Number of parameters: {len(model.parameters)}")
print(f"Number of shocks: {len(model.shocks)}")

# Solve the model
model.solve()
print(f"Model solved: {model.solved}")
```

### Generating Impulse Response Functions

Now, let's generate impulse response functions (IRFs) for a technology shock:

```python
from dsge_macro.simulation.irf import IRFGenerator

# Create an IRF generator
irf_generator = IRFGenerator(model)

# Generate IRFs for a technology shock
tech_irf = irf_generator.generate_irf(shock="eps_a", periods=40, shock_size=0.01)

# Plot IRFs for key variables
variables = ['y', 'c', 'i', 'l', 'r', 'pi']
fig, axes = plt.subplots(len(variables), 1, figsize=(10, 12), sharex=True)

for i, var in enumerate(variables):
    axes[i].plot(tech_irf[var].values)
    axes[i].set_title(f"Response of {var} to Technology Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.show()
```

### Computing Variance Decomposition

Let's compute the variance decomposition to understand the contribution of different shocks:

```python
from dsge_macro.simulation.variance import VarianceDecomposition

# Create a variance decomposition object
vd = VarianceDecomposition(model)

# Compute variance decomposition
variance_decomp = vd.compute_variance_decomposition()

# Plot variance decomposition for output
plt.figure(figsize=(10, 6))
plt.bar(range(len(variance_decomp['y'])), variance_decomp['y'].values)
plt.xticks(range(len(variance_decomp['y'])), variance_decomp['y'].index, rotation=45)
plt.title("Variance Decomposition of Output")
plt.ylabel("Contribution (%)")
plt.tight_layout()
plt.show()
```

### Generating Forecasts

Now, let's generate forecasts:

```python
from dsge_macro.simulation.forecast import Forecaster

# Create a forecaster
forecaster = Forecaster(model)

# Generate forecast
forecast = forecaster.generate_forecast(periods=20, n_simulations=100)

# Plot forecast for output
plt.figure(figsize=(10, 6))
plt.plot(forecast['y'].mean(axis=0), label='Mean Forecast')
plt.fill_between(
    range(len(forecast['y'].mean(axis=0))),
    np.percentile(forecast['y'].values, 10, axis=0),
    np.percentile(forecast['y'].values, 90, axis=0),
    alpha=0.3,
    label='80% Confidence Interval'
)
plt.title("Output Forecast")
plt.xlabel("Quarters")
plt.ylabel("Deviation from SS")
plt.legend()
plt.tight_layout()
plt.show()
```

## Working with Extensions

### Fiscal Policy Extension

Let's create a model with fiscal policy extension:

```python
from dsge_macro.extensions.fiscal import FiscalSWModel

# Create a model with fiscal policy extension
fiscal_model = FiscalSWModel(fiscal_rule="debt")

# Customize fiscal parameters
fiscal_model.parameters['g_y_ratio']['value'] = 0.2
fiscal_model.parameters['b_y_ratio']['value'] = 0.8
fiscal_model.parameters['tau_ss']['value'] = 0.25

# Solve the model
fiscal_model.solve()

# Generate IRFs for a government spending shock
fiscal_irf_generator = IRFGenerator(fiscal_model)
g_irf = fiscal_irf_generator.generate_irf(shock="eps_g", periods=40, shock_size=0.01)

# Plot IRFs for key variables
fiscal_variables = ['y', 'c', 'i', 'g', 'tau', 'b', 'def']
fig, axes = plt.subplots(len(fiscal_variables), 1, figsize=(10, 14), sharex=True)

for i, var in enumerate(fiscal_variables):
    axes[i].plot(g_irf[var].values)
    axes[i].set_title(f"Response of {var} to Government Spending Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.show()

# Compute fiscal multipliers
multipliers = fiscal_model.get_fiscal_multiplier(horizon=20, shock_size=0.01)
print(f"Impact Multiplier: {multipliers['impact']:.3f}")
print(f"Cumulative Multiplier: {multipliers['cumulative']:.3f}")
print(f"Present Value Multiplier: {multipliers['present_value']:.3f}")
```

### Technology Extension

Let's create a model with technology extension:

```python
from dsge_macro.extensions.technology import TechnologySWModel

# Create a model with technology extension
tech_model = TechnologySWModel(tech_type="ist")

# Solve the model
tech_model.solve()

# Generate IRFs for an investment-specific technology shock
tech_irf_generator = IRFGenerator(tech_model)
ist_irf = tech_irf_generator.generate_irf(shock="eps_mu", periods=40, shock_size=0.01)

# Plot IRFs for key variables
tech_variables = ['y', 'c', 'i', 'l', 'r', 'pi', 'mu']
fig, axes = plt.subplots(len(tech_variables), 1, figsize=(10, 14), sharex=True)

for i, var in enumerate(tech_variables):
    axes[i].plot(ist_irf[var].values)
    axes[i].set_title(f"Response of {var} to Investment-Specific Technology Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.show()
```

### Financial Frictions Extension

Let's create a model with financial frictions extension:

```python
from dsge_macro.extensions.financial import FinancialSWModel

# Create a model with financial frictions extension
fin_model = FinancialSWModel(friction_type="accelerator")

# Customize financial parameters
fin_model.parameters['efp_ss']['value'] = 0.005
fin_model.parameters['chi']['value'] = 0.05
fin_model.parameters['lev_ss']['value'] = 2.0

# Solve the model
fin_model.solve()

# Generate IRFs for a net worth shock
fin_irf_generator = IRFGenerator(fin_model)
n_irf = fin_irf_generator.generate_irf(shock="eps_n", periods=40, shock_size=-0.01)

# Plot IRFs for key variables
fin_variables = ['y', 'c', 'i', 'l', 'r', 'pi', 'efp', 'n', 'lev']
fig, axes = plt.subplots(len(fin_variables), 1, figsize=(10, 16), sharex=True)

for i, var in enumerate(fin_variables):
    axes[i].plot(n_irf[var].values)
    axes[i].set_title(f"Response of {var} to Net Worth Shock")
    axes[i].set_ylabel("Deviation from SS")

axes[-1].set_xlabel("Quarters")
plt.tight_layout()
plt.show()
```

## Working with Data

### Loading and Transforming Data

Let's load and transform some data:

```python
import pandas as pd
from dsge_macro.data.transform import log_transform, hp_filter_data
from dsge_macro.data.utils import plot_data_time_series

# Load data
data = pd.read_csv("data/us_dsge_dataset.csv", index_col=0, parse_dates=True)

# Display basic information
print("Data shape:", data.shape)
print("Date range:", data.index.min(), "to", data.index.max())
print("Variables:", ", ".join(data.columns))

# Plot time series
plot_data_time_series(
    data, 
    variables=['gdp_real', 'consumption_real', 'investment_real'], 
    figsize=(15, 10), 
    ncols=1
)

# Log-transform data
log_data = log_transform(data)

# Apply HP filter
cycle, trend = hp_filter_data(log_data, lambda_param=1600)

# Plot cyclical component
plot_data_time_series(
    cycle, 
    variables=['gdp_real', 'consumption_real', 'investment_real'], 
    figsize=(15, 10), 
    ncols=1
)
```

### Estimating a Model with Data

Let's estimate a model using data:

```python
from dsge_macro.estimation.bayesian import BayesianEstimator

# Create a model
model = SWModel()

# Create a Bayesian estimator
estimator = BayesianEstimator(model)

# Prepare data for estimation
estimation_data = cycle[['gdp_real', 'consumption_real', 'investment_real', 'labor_force', 'real_interest_rate', 'cpi']]
estimation_data.columns = ['y', 'c', 'i', 'l', 'r', 'pi']  # Map to model variables

# Estimate parameters
posterior = estimator.estimate(estimation_data, n_samples=1000)

# Summarize posterior
summary = estimator.summarize_posterior(posterior)
print(summary)

# Plot posterior distributions
estimator.plot_posterior(posterior)
```

## Next Steps

Now that you've learned the basics of using DSGE-Macro, you can:

1. Explore more complex models and extensions
2. Estimate models with your own data
3. Conduct policy analysis and simulations
4. Create custom visualizations and reports

Check out the example notebooks in the `examples` directory for more advanced usage scenarios.
