# DSGE-Macro Package Documentation

## Overview

DSGE-Macro is a comprehensive Python package for building, estimating, and simulating Dynamic Stochastic General Equilibrium (DSGE) models for macroeconomic analysis. The package implements the Smets-Wouters (2007) model as its core framework and provides extensions for fiscal policy, technology enhancements, and financial frictions.

## Installation

You can install the package directly from the repository:

```bash
pip install -e .
```

For development, install with additional dependencies:

```bash
pip install -e ".[dev]"
```

## Core Features

- **Model Building**: Create and customize DSGE models with flexible parameter specifications
- **Estimation**: Bayesian and maximum likelihood estimation of model parameters
- **Simulation**: Generate impulse response functions, variance decompositions, and forecasts
- **Extensions**: Fiscal policy, technology enhancements, and financial frictions components
- **Data Handling**: Tools for downloading, transforming, and analyzing macroeconomic data
- **Visualization**: Comprehensive plotting utilities for model results

## Quick Start

```python
import numpy as np
import matplotlib.pyplot as plt
from dsge_macro.core.smets_wouters import SWModel
from dsge_macro.simulation.irf import IRFGenerator

# Create a Smets-Wouters model
model = SWModel()

# Solve the model
model.solve()

# Generate impulse response functions for a technology shock
irf_generator = IRFGenerator(model)
tech_irf = irf_generator.generate_irf(shock="eps_a", periods=40, shock_size=0.01)

# Plot IRFs for output
plt.figure(figsize=(10, 6))
plt.plot(tech_irf['y'].values)
plt.title("Response of Output to Technology Shock")
plt.xlabel("Quarters")
plt.ylabel("Deviation from Steady State")
plt.grid(True)
plt.show()
```

## Package Structure

- **core**: Base model classes and Smets-Wouters implementation
- **estimation**: Bayesian and maximum likelihood estimation methods
- **simulation**: Impulse response functions, variance decomposition, and forecasting
- **extensions**: Fiscal policy, technology, and financial frictions extensions
- **data**: Data download, transformation, and analysis utilities
- **utils**: Helper functions and utilities

## Core Module

The core module provides the base model classes and the Smets-Wouters (2007) implementation.

### Base Model Class

```python
from dsge_macro.core.model import DSGEModel

# Create a custom DSGE model
class MyModel(DSGEModel):
    def __init__(self):
        super().__init__(name="My Custom Model")
        # Define parameters, variables, and equations
        self.add_parameter('beta', 0.99, 'Discount factor')
        # ...
```

### Smets-Wouters Model

```python
from dsge_macro.core.smets_wouters import SWModel

# Create a Smets-Wouters model with default parameters
model = SWModel()

# Customize parameters
model.parameters['beta']['value'] = 0.995
model.parameters['sigma_c']['value'] = 1.5

# Solve the model
model.solve()
```

## Estimation Module

The estimation module provides tools for Bayesian and maximum likelihood estimation of model parameters.

### Bayesian Estimation

```python
from dsge_macro.core.smets_wouters import SWModel
from dsge_macro.estimation.bayesian import BayesianEstimator

# Create a model
model = SWModel()

# Create a Bayesian estimator
estimator = BayesianEstimator(model)

# Estimate parameters using data
posterior = estimator.estimate(data, prior=None, n_samples=1000)

# Analyze posterior distribution
summary = estimator.summarize_posterior(posterior)
print(summary)

# Plot posterior distributions
estimator.plot_posterior(posterior)
```

### Maximum Likelihood Estimation

```python
from dsge_macro.core.smets_wouters import SWModel
from dsge_macro.estimation.mle import MLEstimator

# Create a model
model = SWModel()

# Create an MLE estimator
estimator = MLEstimator(model)

# Estimate parameters using data
results = estimator.estimate(data)

# Print results
print(results.summary())
```

## Simulation Module

The simulation module provides tools for generating impulse response functions, variance decompositions, and forecasts.

### Impulse Response Functions

```python
from dsge_macro.core.smets_wouters import SWModel
from dsge_macro.simulation.irf import IRFGenerator

# Create and solve a model
model = SWModel()
model.solve()

# Create an IRF generator
irf_generator = IRFGenerator(model)

# Generate IRFs for a technology shock
tech_irf = irf_generator.generate_irf(shock="eps_a", periods=40, shock_size=0.01)

# Generate IRFs for a monetary policy shock
mp_irf = irf_generator.generate_irf(shock="eps_r", periods=40, shock_size=0.01)

# Plot IRFs
irf_generator.plot_irf(tech_irf, variables=['y', 'c', 'i', 'l', 'r', 'pi'])
```

### Variance Decomposition

```python
from dsge_macro.core.smets_wouters import SWModel
from dsge_macro.simulation.variance import VarianceDecomposition

# Create and solve a model
model = SWModel()
model.solve()

# Create a variance decomposition object
vd = VarianceDecomposition(model)

# Compute variance decomposition
variance_decomp = vd.compute_variance_decomposition()

# Plot variance decomposition for output
vd.plot_variance_decomposition(variance_decomp, variable='y')
```

### Forecasting

```python
from dsge_macro.core.smets_wouters import SWModel
from dsge_macro.simulation.forecast import Forecaster

# Create and solve a model
model = SWModel()
model.solve()

# Create a forecaster
forecaster = Forecaster(model)

# Generate forecast
forecast = forecaster.generate_forecast(periods=20, n_simulations=100)

# Plot forecast for output
forecaster.plot_forecast(forecast, variable='y')
```

## Extensions Module

The extensions module provides fiscal policy, technology enhancements, and financial frictions components.

### Fiscal Policy Extension

```python
from dsge_macro.extensions.fiscal import FiscalSWModel
from dsge_macro.simulation.irf import IRFGenerator

# Create a model with fiscal policy extension
model = FiscalSWModel(fiscal_rule="debt")

# Customize fiscal parameters
model.parameters['g_y_ratio']['value'] = 0.2
model.parameters['b_y_ratio']['value'] = 0.8
model.parameters['tau_ss']['value'] = 0.25

# Solve the model
model.solve()

# Generate IRFs for a government spending shock
irf_generator = IRFGenerator(model)
g_irf = irf_generator.generate_irf(shock="eps_g", periods=40, shock_size=0.01)

# Plot IRFs
irf_generator.plot_irf(g_irf, variables=['y', 'c', 'i', 'g', 'tau', 'b', 'def'])

# Compute fiscal multipliers
multipliers = model.get_fiscal_multiplier(horizon=20, shock_size=0.01)
print(f"Impact Multiplier: {multipliers['impact']:.3f}")
print(f"Cumulative Multiplier: {multipliers['cumulative']:.3f}")
```

### Technology Extension

```python
from dsge_macro.extensions.technology import TechnologySWModel
from dsge_macro.simulation.irf import IRFGenerator

# Create a model with technology extension
model = TechnologySWModel(tech_type="ist")

# Solve the model
model.solve()

# Generate IRFs for an investment-specific technology shock
irf_generator = IRFGenerator(model)
ist_irf = irf_generator.generate_irf(shock="eps_mu", periods=40, shock_size=0.01)

# Plot IRFs
irf_generator.plot_irf(ist_irf, variables=['y', 'c', 'i', 'l', 'r', 'pi', 'mu'])

# Compute growth accounting
growth_accounting = model.compute_growth_accounting(data)
model.plot_growth_accounting(growth_accounting)
```

### Financial Frictions Extension

```python
from dsge_macro.extensions.financial import FinancialSWModel
from dsge_macro.simulation.irf import IRFGenerator

# Create a model with financial frictions extension
model = FinancialSWModel(friction_type="accelerator")

# Customize financial parameters
model.parameters['efp_ss']['value'] = 0.005
model.parameters['chi']['value'] = 0.05
model.parameters['lev_ss']['value'] = 2.0

# Solve the model
model.solve()

# Generate IRFs for a net worth shock
irf_generator = IRFGenerator(model)
n_irf = irf_generator.generate_irf(shock="eps_n", periods=40, shock_size=-0.01)

# Plot IRFs
irf_generator.plot_irf(n_irf, variables=['y', 'c', 'i', 'l', 'r', 'pi', 'efp', 'n', 'lev'])

# Compute financial conditions index
fci = model.compute_financial_conditions_index(data)
model.plot_financial_conditions_index(fci)
```

## Data Module

The data module provides tools for downloading, transforming, and analyzing macroeconomic data.

### Data Download

```python
from dsge_macro.data.download import download_us_macro_data, download_us_financial_data

# Download US macroeconomic data
macro_data = download_us_macro_data(start_year=1980, end_year=2023, save_path="data/us_macro_data.csv")

# Download US financial data
financial_data = download_us_financial_data(start_date='2000-01-01', save_path="data/us_financial_data.csv")
```

### Data Transformation

```python
from dsge_macro.data.transform import log_transform, hp_filter_data, compute_growth_rates

# Log-transform data
log_data = log_transform(data)

# Apply HP filter
cycle, trend = hp_filter_data(log_data, lambda_param=1600)

# Compute growth rates
growth_data = compute_growth_rates(data, periods=4, annualize=True)
```

### Data Analysis

```python
from dsge_macro.data.utils import create_data_summary, plot_data_correlation_heatmap, plot_data_time_series

# Create data summary
summary = create_data_summary(data, save_path="data/summary.csv")

# Plot correlation heatmap
plot_data_correlation_heatmap(data, figsize=(12, 10), save_path="figures/correlation_heatmap.png")

# Plot time series
plot_data_time_series(data, variables=['gdp_real', 'consumption_real', 'investment_real'], 
                     figsize=(15, 10), ncols=1, save_path="figures/time_series.png")
```

## Examples

The package includes several example notebooks demonstrating its functionality:

1. **Basic Model Example**: Demonstrates core DSGE model functionality
2. **Fiscal Policy Example**: Shows how to use the fiscal policy extension
3. **Technology Example**: Illustrates technology enhancements and growth accounting
4. **Financial Frictions Example**: Demonstrates financial frictions and stress analysis

To run the examples:

```bash
cd examples
python basic_model_example.py
python fiscal_policy_example.py
python technology_example.py
python financial_frictions_example.py
```

## API Reference

### Core Module

#### DSGEModel

Base class for all DSGE models.

- `__init__(name)`: Initialize a DSGE model with a name
- `add_parameter(name, value, description, prior=None)`: Add a parameter to the model
- `add_variable(name, description)`: Add a variable to the model
- `add_shock(name, description)`: Add a shock to the model
- `add_equation(equation, description)`: Add an equation to the model
- `solve(method='first_order')`: Solve the model using the specified method
- `get_steady_state()`: Compute the steady state of the model
- `get_state_space_representation()`: Get the state-space representation of the model

#### SWModel

Implementation of the Smets-Wouters (2007) model.

- `__init__()`: Initialize a Smets-Wouters model with default parameters
- `solve(method='first_order')`: Solve the model using the specified method
- `get_steady_state()`: Compute the steady state of the model
- `get_state_space_representation()`: Get the state-space representation of the model

### Estimation Module

#### BayesianEstimator

Class for Bayesian estimation of DSGE models.

- `__init__(model)`: Initialize a Bayesian estimator for a model
- `estimate(data, prior=None, n_samples=1000)`: Estimate model parameters using Bayesian methods
- `summarize_posterior(posterior)`: Summarize the posterior distribution
- `plot_posterior(posterior)`: Plot the posterior distribution

#### MLEstimator

Class for maximum likelihood estimation of DSGE models.

- `__init__(model)`: Initialize an MLE estimator for a model
- `estimate(data)`: Estimate model parameters using maximum likelihood
- `compute_standard_errors(results)`: Compute standard errors for parameter estimates
- `plot_likelihood_surface(results)`: Plot the likelihood surface

### Simulation Module

#### IRFGenerator

Class for generating impulse response functions.

- `__init__(model)`: Initialize an IRF generator for a model
- `generate_irf(shock, periods=40, shock_size=0.01)`: Generate IRFs for a specific shock
- `plot_irf(irf, variables=None)`: Plot IRFs for specified variables

#### VarianceDecomposition

Class for computing variance decompositions.

- `__init__(model)`: Initialize a variance decomposition object for a model
- `compute_variance_decomposition()`: Compute variance decomposition
- `plot_variance_decomposition(variance_decomp, variable)`: Plot variance decomposition for a variable

#### Forecaster

Class for generating forecasts.

- `__init__(model)`: Initialize a forecaster for a model
- `generate_forecast(periods=20, n_simulations=100)`: Generate forecast
- `plot_forecast(forecast, variable)`: Plot forecast for a variable

### Extensions Module

#### FiscalSWModel

Extension of the Smets-Wouters model with fiscal policy.

- `__init__(fiscal_rule="debt")`: Initialize a fiscal policy model with a specific rule
- `get_fiscal_multiplier(horizon=20, shock_size=0.01)`: Compute fiscal multipliers
- `compute_debt_sustainability(initial_debt, periods=40)`: Analyze debt sustainability

#### TechnologySWModel

Extension of the Smets-Wouters model with technology enhancements.

- `__init__(tech_type="ist")`: Initialize a technology model with a specific type
- `compute_growth_accounting(data)`: Compute growth accounting decomposition
- `compute_technology_trends(data)`: Compute technology trends

#### FinancialSWModel

Extension of the Smets-Wouters model with financial frictions.

- `__init__(friction_type="accelerator")`: Initialize a financial frictions model with a specific type
- `compute_financial_conditions_index(data)`: Compute financial conditions index
- `compute_financial_stress(data)`: Compute financial stress indicators

## License

This project is licensed under the MIT License - see the LICENSE file for details.
