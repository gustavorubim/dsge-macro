# API Reference

## Core Module

### DSGEModel

The `DSGEModel` class is the base class for all DSGE models in the package. It provides the core functionality for defining, solving, and analyzing DSGE models.

#### Methods

- `__init__(name: str)`: Initialize a DSGE model with a name.
- `add_parameter(name: str, value: float, description: str, prior: dict = None)`: Add a parameter to the model.
- `add_variable(name: str, description: str)`: Add a variable to the model.
- `add_shock(name: str, description: str)`: Add a shock to the model.
- `add_equation(equation: str, description: str)`: Add an equation to the model.
- `solve(method: str = 'first_order')`: Solve the model using the specified method.
- `get_steady_state()`: Compute the steady state of the model.
- `get_state_space_representation()`: Get the state-space representation of the model.
- `log_linearize()`: Log-linearize the model equations around the steady state.
- `check_blanchard_kahn()`: Check if the Blanchard-Kahn conditions are satisfied.
- `simulate(periods: int, shocks: dict = None)`: Simulate the model for a given number of periods.

### SWModel

The `SWModel` class implements the Smets-Wouters (2007) model, which is a medium-scale DSGE model with various nominal and real frictions.

#### Methods

- `__init__()`: Initialize a Smets-Wouters model with default parameters.
- `solve(method: str = 'first_order')`: Solve the model using the specified method.
- `get_steady_state()`: Compute the steady state of the model.
- `get_state_space_representation()`: Get the state-space representation of the model.
- `calibrate_to_us_data(data: pd.DataFrame)`: Calibrate the model parameters to match US data.
- `get_model_equations()`: Get the model equations in log-linearized form.
- `get_model_parameters()`: Get the model parameters with their descriptions and values.

## Estimation Module

### BayesianEstimator

The `BayesianEstimator` class provides methods for Bayesian estimation of DSGE models using Markov Chain Monte Carlo (MCMC) methods.

#### Methods

- `__init__(model: DSGEModel)`: Initialize a Bayesian estimator for a model.
- `estimate(data: pd.DataFrame, prior: dict = None, n_samples: int = 1000)`: Estimate model parameters using Bayesian methods.
- `summarize_posterior(posterior: dict)`: Summarize the posterior distribution.
- `plot_posterior(posterior: dict)`: Plot the posterior distribution.
- `compute_marginal_likelihood(posterior: dict)`: Compute the marginal likelihood of the model.
- `compute_posterior_predictive(posterior: dict, periods: int = 20)`: Compute the posterior predictive distribution.
- `plot_prior_posterior(posterior: dict, prior: dict)`: Plot the prior and posterior distributions.
- `compute_hpd_interval(posterior: dict, alpha: float = 0.05)`: Compute the highest posterior density interval.

### MLEstimator

The `MLEstimator` class provides methods for maximum likelihood estimation of DSGE models.

#### Methods

- `__init__(model: DSGEModel)`: Initialize an MLE estimator for a model.
- `estimate(data: pd.DataFrame)`: Estimate model parameters using maximum likelihood.
- `compute_standard_errors(results: dict)`: Compute standard errors for parameter estimates.
- `plot_likelihood_surface(results: dict)`: Plot the likelihood surface.
- `compute_information_criteria(results: dict)`: Compute information criteria (AIC, BIC, HQC).
- `compute_likelihood_ratio_test(results1: dict, results2: dict)`: Compute likelihood ratio test for nested models.
- `compute_confidence_intervals(results: dict, alpha: float = 0.05)`: Compute confidence intervals for parameter estimates.

### Calibration

The `Calibration` class provides methods for calibrating DSGE models to match specific targets.

#### Methods

- `__init__(model: DSGEModel)`: Initialize a calibration object for a model.
- `calibrate_to_targets(targets: dict)`: Calibrate the model to match specific targets.
- `calibrate_to_moments(data: pd.DataFrame, moment_mapping: dict)`: Calibrate the model to match empirical moments.
- `calibrate_to_irfs(irfs: dict, irf_mapping: dict)`: Calibrate the model to match empirical impulse response functions.
- `compute_distance_to_targets(targets: dict)`: Compute the distance between model-implied values and targets.
- `plot_calibration_results(targets: dict)`: Plot the calibration results.

## Simulation Module

### IRFGenerator

The `IRFGenerator` class provides methods for generating and analyzing impulse response functions.

#### Methods

- `__init__(model: DSGEModel)`: Initialize an IRF generator for a model.
- `generate_irf(shock: str, periods: int = 40, shock_size: float = 0.01)`: Generate IRFs for a specific shock.
- `plot_irf(irf: pd.DataFrame, variables: list = None)`: Plot IRFs for specified variables.
- `compare_irfs(irfs: dict, variables: list = None)`: Compare IRFs from different shocks or models.
- `compute_cumulative_irf(irf: pd.DataFrame)`: Compute cumulative impulse response functions.
- `normalize_irf(irf: pd.DataFrame, variable: str)`: Normalize IRFs by the response of a specific variable.
- `export_irf(irf: pd.DataFrame, file_path: str)`: Export IRFs to a file.

### VarianceDecomposition

The `VarianceDecomposition` class provides methods for computing and analyzing variance decompositions.

#### Methods

- `__init__(model: DSGEModel)`: Initialize a variance decomposition object for a model.
- `compute_variance_decomposition()`: Compute variance decomposition.
- `plot_variance_decomposition(variance_decomp: dict, variable: str)`: Plot variance decomposition for a variable.
- `compute_historical_decomposition(data: pd.DataFrame)`: Compute historical decomposition.
- `plot_historical_decomposition(hist_decomp: dict, variable: str)`: Plot historical decomposition for a variable.
- `compute_forecast_error_variance_decomposition(periods: list = None)`: Compute forecast error variance decomposition.
- `export_variance_decomposition(variance_decomp: dict, file_path: str)`: Export variance decomposition to a file.

### Forecaster

The `Forecaster` class provides methods for generating and analyzing forecasts.

#### Methods

- `__init__(model: DSGEModel)`: Initialize a forecaster for a model.
- `generate_forecast(periods: int = 20, n_simulations: int = 100)`: Generate forecast.
- `plot_forecast(forecast: dict, variable: str)`: Plot forecast for a variable.
- `compute_forecast_statistics(forecast: dict)`: Compute statistics for the forecast.
- `compute_forecast_bands(forecast: dict, alphas: list = [0.1, 0.2])`: Compute forecast bands.
- `compare_forecasts(forecasts: dict, variable: str)`: Compare forecasts from different models.
- `export_forecast(forecast: dict, file_path: str)`: Export forecast to a file.

## Extensions Module

### FiscalSWModel

The `FiscalSWModel` class extends the Smets-Wouters model with fiscal policy components.

#### Methods

- `__init__(fiscal_rule: str = "debt")`: Initialize a fiscal policy model with a specific rule.
- `get_fiscal_multiplier(horizon: int = 20, shock_size: float = 0.01)`: Compute fiscal multipliers.
- `compute_debt_sustainability(initial_debt: float, periods: int = 40)`: Analyze debt sustainability.
- `compute_optimal_fiscal_policy(objective: str = "output")`: Compute optimal fiscal policy.
- `compute_fiscal_space(max_debt: float = 1.5)`: Compute fiscal space.
- `plot_fiscal_multipliers(multipliers: dict)`: Plot fiscal multipliers.
- `plot_debt_dynamics(debt_path: pd.DataFrame)`: Plot debt dynamics.

### TechnologySWModel

The `TechnologySWModel` class extends the Smets-Wouters model with technology enhancements.

#### Methods

- `__init__(tech_type: str = "ist")`: Initialize a technology model with a specific type.
- `compute_growth_accounting(data: pd.DataFrame)`: Compute growth accounting decomposition.
- `compute_technology_trends(data: pd.DataFrame)`: Compute technology trends.
- `compute_potential_output(data: pd.DataFrame)`: Compute potential output.
- `compute_output_gap(data: pd.DataFrame)`: Compute output gap.
- `plot_growth_accounting(growth_accounting: pd.DataFrame)`: Plot growth accounting decomposition.
- `plot_technology_trends(tech_trends: pd.DataFrame)`: Plot technology trends.

### FinancialSWModel

The `FinancialSWModel` class extends the Smets-Wouters model with financial frictions.

#### Methods

- `__init__(friction_type: str = "accelerator")`: Initialize a financial frictions model with a specific type.
- `compute_financial_conditions_index(data: pd.DataFrame)`: Compute financial conditions index.
- `compute_financial_stress(data: pd.DataFrame)`: Compute financial stress indicators.
- `compute_credit_cycle(data: pd.DataFrame)`: Compute credit cycle.
- `compute_financial_accelerator_multiplier()`: Compute financial accelerator multiplier.
- `plot_financial_conditions_index(fci: pd.DataFrame)`: Plot financial conditions index.
- `plot_financial_stress(stress: pd.DataFrame)`: Plot financial stress indicators.

## Data Module

### Download

The `download` module provides functions for downloading macroeconomic and financial data.

#### Functions

- `download_us_macro_data(start_year: int = 1980, end_year: int = 2023, save_path: str = None)`: Download US macroeconomic data.
- `download_us_financial_data(start_date: str = '2000-01-01', end_date: str = None, save_path: str = None)`: Download US financial data.
- `download_euro_area_data(start_year: int = 1995, end_year: int = 2023, save_path: str = None)`: Download Euro Area data.
- `download_global_data(countries: list, indicators: list, start_year: int = 1980, end_year: int = 2023, save_path: str = None)`: Download global data.
- `create_dsge_dataset(macro_data: pd.DataFrame, financial_data: pd.DataFrame = None, save_path: str = None)`: Create a dataset for DSGE model estimation.

### Transform

The `transform` module provides functions for transforming and processing data.

#### Functions

- `log_transform(data: pd.DataFrame)`: Log-transform data.
- `hp_filter_data(data: pd.DataFrame, lambda_param: float = 1600)`: Apply HP filter to data.
- `compute_growth_rates(data: pd.DataFrame, periods: int = 1, annualize: bool = False)`: Compute growth rates.
- `linear_detrend(data: pd.DataFrame)`: Apply linear detrending to data.
- `first_difference(data: pd.DataFrame)`: Compute first differences.
- `seasonal_adjust(data: pd.DataFrame, method: str = 'x13')`: Apply seasonal adjustment.
- `standardize_data(data: pd.DataFrame)`: Standardize data.
- `plot_transformed_data(data1: pd.DataFrame, data2: pd.DataFrame, transformation_name: str = '')`: Plot transformed data.
- `plot_autocorrelations(data: pd.DataFrame, lags: int = 10, save_path: str = None)`: Plot autocorrelations.

### Utils

The `utils` module provides utility functions for data analysis and visualization.

#### Functions

- `load_data(file_path: str)`: Load data from a file.
- `save_data(data: pd.DataFrame, file_path: str)`: Save data to a file.
- `create_data_summary(data: pd.DataFrame, save_path: str = None)`: Create a summary of the data.
- `plot_data_correlation_heatmap(data: pd.DataFrame, figsize: tuple = (12, 10), save_path: str = None)`: Plot a correlation heatmap.
- `plot_data_time_series(data: pd.DataFrame, variables: list = None, figsize: tuple = (15, 10), ncols: int = 1, save_path: str = None)`: Plot time series.
- `create_training_validation_split(data: pd.DataFrame, train_ratio: float = 0.8)`: Split data into training and validation sets.
- `create_lagged_features(data: pd.DataFrame, lags: int = 1)`: Create lagged features.
- `create_rolling_features(data: pd.DataFrame, window: int = 3)`: Create rolling window features.
- `interpolate_missing_values(data: pd.DataFrame, method: str = 'linear')`: Interpolate missing values.
- `detect_outliers(data: pd.DataFrame, method: str = 'zscore')`: Detect outliers in data.
