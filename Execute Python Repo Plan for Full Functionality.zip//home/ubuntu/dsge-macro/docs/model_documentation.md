# Model Documentation

## Smets-Wouters (2007) Model

The Smets-Wouters (2007) model is a medium-scale DSGE model with various nominal and real frictions. It has become a standard reference model in macroeconomic analysis and policy evaluation.

### Model Features

- Sticky prices and wages with partial indexation
- Variable capital utilization
- Investment adjustment costs
- Habit formation in consumption
- Fixed costs in production
- Seven structural shocks:
  - Technology shock
  - Investment-specific technology shock
  - Risk premium shock
  - Government spending shock
  - Monetary policy shock
  - Price markup shock
  - Wage markup shock

### Model Equations

The model consists of the following log-linearized equations:

1. **Resource constraint**:
   $y_t = c_y c_t + i_y i_t + z_y z_t + \varepsilon_t^g$

2. **Consumption Euler equation**:
   $c_t = c_1 c_{t-1} + (1-c_1) E_t[c_{t+1}] + c_2 (r_t - E_t[\pi_{t+1}]) + \varepsilon_t^b$

3. **Investment equation**:
   $i_t = i_1 i_{t-1} + (1-i_1) E_t[i_{t+1}] + i_2 q_t + \varepsilon_t^i$

4. **Value of capital**:
   $q_t = q_1 E_t[q_{t+1}] + (1-q_1) E_t[r_{t+1}^k] - (r_t - E_t[\pi_{t+1}]) + \frac{1}{\psi} \varepsilon_t^b$

5. **Capital accumulation**:
   $\bar{k}_t = k_1 \bar{k}_{t-1} + (1-k_1) i_t + k_2 \varepsilon_t^i$

6. **Capital utilization**:
   $z_t = z_1 r_t^k$

7. **Capital services**:
   $k_t = \bar{k}_{t-1} + z_t$

8. **Phillips curve**:
   $\pi_t = \pi_1 \pi_{t-1} + \pi_2 E_t[\pi_{t+1}] - \pi_3 \mu_t^p + \varepsilon_t^p$

9. **Rental rate of capital**:
   $r_t^k = -(k_t - l_t) + w_t$

10. **Marginal cost**:
    $\mu_t^p = \alpha r_t^k + (1-\alpha) w_t - \varepsilon_t^a$

11. **Wage Phillips curve**:
    $w_t = w_1 w_{t-1} + (1-w_1) E_t[w_{t+1} + \pi_{t+1}] - w_2 \pi_t + w_3 \pi_{t-1} - w_4 \mu_t^w + \varepsilon_t^w$

12. **Labor supply**:
    $\mu_t^w = w_t - \sigma_l l_t - \frac{1}{1-h/\gamma} (c_t - h/\gamma c_{t-1})$

13. **Monetary policy rule**:
    $r_t = \rho r_{t-1} + (1-\rho) [\phi_\pi \pi_t + \phi_y (y_t - y_t^p)] + \phi_{dy} [(y_t - y_t^p) - (y_{t-1} - y_{t-1}^p)] + \varepsilon_t^r$

14. **Potential output**:
    $y_t^p = \text{Output level under flexible prices and wages}$

### Model Parameters

The model has the following key parameters:

| Parameter | Description | Default Value |
|-----------|-------------|---------------|
| $\beta$ | Discount factor | 0.99 |
| $\sigma_c$ | Intertemporal elasticity of substitution | 1.5 |
| $h$ | Habit formation parameter | 0.7 |
| $\sigma_l$ | Labor supply elasticity | 2.0 |
| $\xi_p$ | Calvo price stickiness | 0.75 |
| $\xi_w$ | Calvo wage stickiness | 0.75 |
| $\iota_p$ | Price indexation | 0.5 |
| $\iota_w$ | Wage indexation | 0.5 |
| $\alpha$ | Capital share | 0.3 |
| $\psi$ | Capital adjustment cost | 5.0 |
| $\phi_p$ | Fixed cost in production | 1.5 |
| $\rho$ | Interest rate smoothing | 0.8 |
| $\phi_\pi$ | Taylor rule inflation | 1.5 |
| $\phi_y$ | Taylor rule output gap | 0.125 |
| $\phi_{dy}$ | Taylor rule output gap growth | 0.125 |

### Shock Processes

The model includes seven structural shocks, each following an AR(1) process:

1. **Technology shock** ($\varepsilon_t^a$):
   $\varepsilon_t^a = \rho_a \varepsilon_{t-1}^a + \eta_t^a$

2. **Risk premium shock** ($\varepsilon_t^b$):
   $\varepsilon_t^b = \rho_b \varepsilon_{t-1}^b + \eta_t^b$

3. **Government spending shock** ($\varepsilon_t^g$):
   $\varepsilon_t^g = \rho_g \varepsilon_{t-1}^g + \eta_t^g$

4. **Investment-specific shock** ($\varepsilon_t^i$):
   $\varepsilon_t^i = \rho_i \varepsilon_{t-1}^i + \eta_t^i$

5. **Monetary policy shock** ($\varepsilon_t^r$):
   $\varepsilon_t^r = \rho_r \varepsilon_{t-1}^r + \eta_t^r$

6. **Price markup shock** ($\varepsilon_t^p$):
   $\varepsilon_t^p = \rho_p \varepsilon_{t-1}^p + \eta_t^p$

7. **Wage markup shock** ($\varepsilon_t^w$):
   $\varepsilon_t^w = \rho_w \varepsilon_{t-1}^w + \eta_t^w$

## Fiscal Policy Extension

The fiscal policy extension adds government debt dynamics and fiscal rules to the Smets-Wouters model.

### Additional Variables

- Government debt ($b_t$)
- Tax rate ($\tau_t$)
- Government deficit ($def_t$)

### Additional Equations

1. **Government budget constraint**:
   $b_t = \frac{1}{\beta} b_{t-1} + \frac{g_y}{\beta} g_t - \frac{\tau_y}{\beta} \tau_t - \frac{\tau_y}{\beta} y_t$

2. **Fiscal rule (debt-based)**:
   $\tau_t = \rho_\tau \tau_{t-1} + (1-\rho_\tau) [\phi_b b_t + \phi_y y_t] + \varepsilon_t^\tau$

3. **Government deficit**:
   $def_t = g_t - \tau_t - y_t$

### Fiscal Rule Options

1. **Debt-based rule**: Tax rate responds to debt level and output
2. **Balanced budget**: Government spending equals tax revenue
3. **Exogenous tax rate**: Tax rate follows an exogenous process

## Technology Extension

The technology extension adds investment-specific technology, R&D, and endogenous growth to the Smets-Wouters model.

### Technology Types

1. **Investment-Specific Technology (IST)**:
   - Adds investment-specific technology shock ($\mu_t$)
   - Modifies investment and capital accumulation equations

2. **R&D**:
   - Adds R&D spending ($rd_t$)
   - Adds knowledge accumulation ($a_t$)
   - Adds spillover effects ($s_t$)

3. **Endogenous Growth**:
   - Combines IST and R&D
   - Adds endogenous productivity growth

### Additional Equations (IST)

1. **Modified investment equation**:
   $i_t = i_1 i_{t-1} + (1-i_1) E_t[i_{t+1}] + i_2 q_t + \mu_t + \varepsilon_t^i$

2. **IST process**:
   $\mu_t = \rho_\mu \mu_{t-1} + \eta_t^\mu$

### Additional Equations (R&D)

1. **R&D spending**:
   $rd_t = \rho_{rd} rd_{t-1} + (1-\rho_{rd}) [y_t] + \varepsilon_t^{rd}$

2. **Knowledge accumulation**:
   $a_t = (1-\delta_a) a_{t-1} + \delta_a rd_t + s_t$

3. **Spillover effects**:
   $s_t = \psi_{rd} a_{t-1}$

4. **Modified production function**:
   $y_t = \alpha k_t + (1-\alpha) l_t + \phi a_t + \varepsilon_t^a$

## Financial Frictions Extension

The financial frictions extension adds credit market imperfections to the Smets-Wouters model.

### Friction Types

1. **Financial Accelerator**:
   - Adds external finance premium ($efp_t$)
   - Adds entrepreneurial net worth ($n_t$)
   - Adds leverage ratio ($lev_t$)

2. **Collateral Constraints**:
   - Adds borrowing constraints based on collateral value
   - Adds loan-to-value ratio ($ltv_t$)
   - Adds Lagrange multiplier on borrowing constraint ($\lambda_t^b$)

3. **Banking Sector**:
   - Adds bank capital ($kb_t$)
   - Adds bank leverage ($levb_t$)
   - Adds lending rate ($rl_t$) and deposit rate ($rd_t$)

### Additional Equations (Financial Accelerator)

1. **External finance premium**:
   $efp_t = \chi (lev_t - lev_{ss}) + \varepsilon_t^{efp}$

2. **Entrepreneurial net worth**:
   $n_t = \gamma_e n_{t-1} + (1-\gamma_e) [r_t^k - (r_{t-1} - \pi_t) - efp_{t-1}] + \varepsilon_t^n$

3. **Leverage ratio**:
   $lev_t = q_t + k_t - n_t$

4. **Modified capital return**:
   $E_t[r_{t+1}^k - (r_t - \pi_{t+1})] = efp_t$

### Additional Equations (Banking Sector)

1. **Bank capital accumulation**:
   $kb_t = (1-\delta_b) kb_{t-1} + \delta_b [rl_t - rd_t] + \varepsilon_t^{kb}$

2. **Bank leverage**:
   $levb_t = l_t - kb_t$

3. **Lending rate**:
   $rl_t = rd_t + \kappa levb_t + \varepsilon_t^{rl}$

4. **Deposit rate**:
   $rd_t = r_t + \varepsilon_t^{rd}$
