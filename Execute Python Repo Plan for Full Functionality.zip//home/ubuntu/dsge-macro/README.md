# DSGE-Macro

A comprehensive Python package for Dynamic Stochastic General Equilibrium (DSGE) macroeconomic modeling, estimation, and analysis.

## Overview

DSGE-Macro provides a flexible framework for building, estimating, and simulating DSGE models for macroeconomic analysis. The package implements the Smets-Wouters (2007) model as a baseline and includes extensions for fiscal policy, technology enhancements, and financial frictions.

## Features

- **Core Model Components**:
  - Base model class with parameter handling and solution methods
  - Smets-Wouters (2007) model implementation
  - Steady-state solvers for computing model equilibrium
  - First-order, second-order, and third-order perturbation solutions

- **Estimation Methods**:
  - Bayesian estimation using MCMC (via PyMC)
  - Maximum likelihood estimation
  - Calibration tools
  - Posterior analysis tools

- **Simulation Tools**:
  - Impulse response function generation with visualization
  - Historical decomposition tools
  - Variance decomposition
  - Forecasting tools

- **Model Extensions**:
  - Fiscal policy extension with government spending, taxation, and debt dynamics
  - Technology enhancements with investment-specific technology and R&D
  - Financial frictions with financial accelerator, collateral constraints, and banking sector

- **Data Handling**:
  - US macroeconomic data utilities
  - Data transformation tools (HP filter, growth rates, etc.)

## Installation

```bash
pip install dsge-macro
```

Or install from source:

```bash
git clone https://github.com/yourusername/dsge-macro.git
cd dsge-macro
pip install -e .
```

## Quick Start

```python
import numpy as np
import matplotlib.pyplot as plt
from dsge_macro.core.smets_wouters import SWModel

# Initialize the model
model = SWModel()

# Solve the model
model.solve()

# Generate impulse responses to a monetary policy shock
from dsge_macro.simulation.irf import IRFGenerator
irf_gen = IRFGenerator(model)
irf = irf_gen.generate_irf("eps_r", periods=40, shock_size=0.01)

# Plot the responses
irf.plot(variables=["y", "pi", "r"], figsize=(10, 6))
plt.tight_layout()
plt.show()
```

## Examples

See the `examples` directory for more detailed examples:

- `basic_model_example.py`: Basic usage of the Smets-Wouters model
- `fiscal_policy_example.py`: Fiscal policy analysis
- `technology_example.py`: Technology shocks and growth accounting
- `financial_frictions_example.py`: Financial frictions and stress analysis

## Documentation

Comprehensive documentation is available in the `docs` directory:

- `documentation.md`: General overview and usage
- `api_reference.md`: Detailed API reference
- `tutorials/getting_started.md`: Getting started tutorial
- `model_documentation.md`: Theoretical model documentation

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Citation

If you use this package in your research, please cite:

```
@software{dsge_macro,
  author = {Your Name},
  title = {DSGE-Macro: A Python Package for DSGE Modeling},
  year = {2025},
  url = {https://github.com/yourusername/dsge-macro}
}
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
