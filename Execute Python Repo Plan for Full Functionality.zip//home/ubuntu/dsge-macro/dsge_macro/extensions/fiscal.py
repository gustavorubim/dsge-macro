                          prior_mean=0.1, prior_std=0.05,
                          description="Fiscal policy response to debt")
        
        # Fiscal policy response to output
        self.add_parameter("phi_y", 0.2, 
                          prior_dist="gamma", 
                          prior_mean=0.2, prior_std=0.1,
                          description="Fiscal policy response to output")
        
        # Government spending persistence
        self.add_parameter("rho_g", 0.8, 
                          prior_dist="beta", 
                          prior_mean=0.8, prior_std=0.1,
                          description="Government spending persistence")
        
        # Tax rate persistence
        self.add_parameter("rho_tau", 0.8, 
                          prior_dist="beta", 
                          prior_mean=0.8, prior_std=0.1,
                          description="Tax rate persistence")
        
    def _add_fiscal_shocks(self):
        """Add fiscal policy shocks to the model."""
        # Government spending shock
        if "eps_g" not in self.shocks:
            self.shocks.append("eps_g")
            
        # Add shock standard deviation
        self.add_parameter("sigma_eps_g", 0.01, 
                          prior_dist="inv_gamma", 
                          prior_mean=0.01, prior_std=0.005,
                          description="Standard deviation of government spending shock")
        
        # Tax rate shock
        if "eps_tau" not in self.shocks:
            self.shocks.append("eps_tau")
            
        # Add shock standard deviation
        self.add_parameter("sigma_eps_tau", 0.01, 
                          prior_dist="inv_gamma", 
                          prior_mean=0.01, prior_std=0.005,
                          description="Standard deviation of tax rate shock")
        
    def add_fiscal_equations(self, base_model_equations: List[str]) -> List[str]:
        """Add fiscal policy equations to the model.
        
        Args:
            base_model_equations (List[str]): Base model equations
            
        Returns:
            List[str]: Extended model equations with fiscal policy
        """
        # Start with base model equations
        equations = base_model_equations.copy()
        
        # Government spending process (AR(1))
        equations.append("g = (1 - rho_g) * g_ss + rho_g * g(-1) + eps_g")
        
        # Tax rate process
        if self.fiscal_rule == "exogenous":
            # Exogenous tax rate (AR(1))
            equations.append("tau = (1 - rho_tau) * tau_ss + rho_tau * tau(-1) + eps_tau")
        elif self.fiscal_rule == "balanced":
            # Balanced budget rule
            equations.append("tau * y = g")
        elif self.fiscal_rule == "debt":
            # Debt-based rule
            equations.append("tau = tau_ss + phi_b * (b(-1) - b_ss) + phi_y * (y - y_ss) + eps_tau")
        
        # Government revenue
        equations.append("t = tau * y")
        
        # Primary deficit
        equations.append("def = g - t")
        
        # Government debt evolution
        equations.append("b = (1 + r(-1)) * b(-1) + def")
        
        # Resource constraint with government
        # Find and replace the resource constraint
        for i, eq in enumerate(equations):
            if eq.startswith("y =") and "c +" in eq and "i +" in eq:
                # Replace with new resource constraint including government
                equations[i] = eq.replace("y =", "y = g +")
                break
        
        return equations
        
    def compute_steady_state(self) -> Dict[str, float]:
        """Compute the steady state of the model.
        
        Returns:
            Dict[str, float]: Steady state values
        """
        # Get base steady state
        ss = super().compute_steady_state()
        
        # Add fiscal variables
        # Steady-state output
        y_ss = ss.get("y", 1.0)
        
        # Steady-state interest rate
        r_ss = ss.get("r", 0.01)
        
        # Government spending
        g_y_ratio = self.parameters["g_y_ratio"]["value"]
        g_ss = g_y_ratio * y_ss
        ss["g"] = g_ss
        
        # Government debt
        b_y_ratio = self.parameters["b_y_ratio"]["value"]
        b_ss = b_y_ratio * y_ss
        ss["b"] = b_ss
        
        # Tax rate
        if self.fiscal_rule == "balanced":
            # Balanced budget: tau * y = g
            tau_ss = g_ss / y_ss
        else:
            # Debt rule or exogenous: use parameter
            tau_ss = self.parameters["tau_ss"]["value"]
        ss["tau"] = tau_ss
        
        # Government revenue
        t_ss = tau_ss * y_ss
        ss["t"] = t_ss
        
        # Primary deficit
        def_ss = g_ss - t_ss
        ss["def"] = def_ss
        
        # Check debt sustainability
        if self.fiscal_rule == "debt":
            # Debt is sustainable if primary deficit equals interest payments
            sustainable_def = -r_ss * b_ss
            if abs(def_ss - sustainable_def) > 1e-6:
                print(f"Warning: Steady-state primary deficit ({def_ss:.4f}) does not equal "
                      f"negative of interest payments ({sustainable_def:.4f})")
                print("Debt may not be sustainable in the long run.")
        
        return ss
        
    def get_fiscal_multiplier(self, horizon: int = 20, shock_size: float = 0.01) -> Dict[str, float]:
        """Compute the fiscal multiplier.
        
        Args:
            horizon (int, optional): Horizon for computing multiplier. Defaults to 20.
            shock_size (float, optional): Size of government spending shock. Defaults to 0.01.
            
        Returns:
            Dict[str, float]: Fiscal multipliers (impact, cumulative, present value)
        """
        if not self.solved:
            self.solve()
            
        # Generate impulse response to government spending shock
        from dsge_macro.simulation.irf import IRFGenerator
        irf_gen = IRFGenerator(self)
        irf = irf_gen.generate_irf("eps_g", periods=horizon, shock_size=shock_size)
        
        # Get responses
        y_response = irf["y"].values
        g_response = irf["g"].values
        
        # Compute multipliers
        
        # Impact multiplier
        impact_multiplier = y_response[0] / g_response[0]
        
        # Cumulative multiplier
        cum_y_response = np.sum(y_response)
        cum_g_response = np.sum(g_response)
        cumulative_multiplier = cum_y_response / cum_g_response
        
        # Present value multiplier
        r_ss = self.compute_steady_state()["r"]
        discount_factors = np.array([(1 / (1 + r_ss)) ** t for t in range(horizon)])
        pv_y_response = np.sum(y_response * discount_factors)
        pv_g_response = np.sum(g_response * discount_factors)
        present_value_multiplier = pv_y_response / pv_g_response
        
        return {
            "impact": impact_multiplier,
            "cumulative": cumulative_multiplier,
            "present_value": present_value_multiplier
        }
        
    def compute_debt_sustainability(self, initial_debt: float, 
                                   periods: int = 100) -> Dict[str, np.ndarray]:
        """Compute debt sustainability analysis.
        
        Args:
            initial_debt (float): Initial debt level
            periods (int, optional): Number of periods to simulate. Defaults to 100.
            
        Returns:
            Dict[str, np.ndarray]: Debt sustainability analysis results
        """
        if not self.solved:
            self.solve()