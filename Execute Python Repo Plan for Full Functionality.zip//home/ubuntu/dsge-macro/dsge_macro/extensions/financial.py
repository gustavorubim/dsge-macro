"""
Financial frictions extension for DSGE models.

This module provides extensions to the Smets-Wouters model that incorporate
financial frictions, including financial accelerator, collateral constraints,
and banking sector dynamics.
"""

import numpy as np
import jax
import jax.numpy as jnp
from typing import Dict, List, Tuple, Optional, Union, Callable
import xarray as xr

from dsge_macro.core.model import DSGEModel
from dsge_macro.core.smets_wouters import SWModel
from dsge_macro.core.parameters import ParameterManager
from dsge_macro.core.steady_state import SteadyStateSolver


class FinancialFrictionBase:
    """Base class for financial friction extensions.
    
    This class provides common methods for financial friction extensions.
    """
    
    def __init__(self, friction_type: str = "accelerator"):
        """Initialize financial friction extension.
        
        Args:
            friction_type (str, optional): Type of financial friction.
                Options: "accelerator", "collateral", "banking".
                Defaults to "accelerator".
        """
        self.friction_type = friction_type
        
    def add_financial_parameters(self):
        """Add financial friction parameters to the model."""
        # Common parameters
        self.add_parameter("efp_ss", 0.005, 
                          prior_dist="beta", 
                          prior_mean=0.005, prior_std=0.002,
                          description="Steady-state external finance premium")
        
        # Financial accelerator parameters
        if self.friction_type == "accelerator":
            self.add_parameter("nu", 0.05, 
                              prior_dist="beta", 
                              prior_mean=0.05, prior_std=0.02,
                              description="Entrepreneurial survival rate")
            
            self.add_parameter("chi", 0.05, 
                              prior_dist="beta", 
                              prior_mean=0.05, prior_std=0.02,
                              description="Elasticity of EFP to leverage")
            
        # Collateral constraint parameters
        elif self.friction_type == "collateral":
            self.add_parameter("ltv", 0.75, 
                              prior_dist="beta", 
                              prior_mean=0.75, prior_std=0.1,
                              description="Loan-to-value ratio")
            
            self.add_parameter("theta", 0.9, 
                              prior_dist="beta", 
                              prior_mean=0.9, prior_std=0.05,
                              description="Share of collateralizable capital")
            
        # Banking sector parameters
        elif self.friction_type == "banking":
            self.add_parameter("kappa_b", 0.1, 
                              prior_dist="beta", 
                              prior_mean=0.1, prior_std=0.05,
                              description="Bank capital requirement")
            
            self.add_parameter("delta_b", 0.1, 
                              prior_dist="beta", 
                              prior_mean=0.1, prior_std=0.05,
                              description="Bank capital depreciation rate")
            
    def _add_financial_shocks(self):
        """Add financial shocks to the model."""
        # Net worth shock (common to all friction types)
        if "eps_n" not in self.shocks:
            self.shocks.append("eps_n")
            
        # Add shock standard deviation
        self.add_parameter("sigma_eps_n", 0.01, 
                          prior_dist="inv_gamma", 
                          prior_mean=0.01, prior_std=0.005,
                          description="Standard deviation of net worth shock")
        
        # Financial accelerator shock
        if self.friction_type == "accelerator":
            if "eps_efp" not in self.shocks:
                self.shocks.append("eps_efp")
                
            # Add shock standard deviation
            self.add_parameter("sigma_eps_efp", 0.01, 
                              prior_dist="inv_gamma", 
                              prior_mean=0.01, prior_std=0.005,
                              description="Standard deviation of EFP shock")
            
        # Collateral constraint shock
        if self.friction_type == "collateral":
            if "eps_ltv" not in self.shocks:
                self.shocks.append("eps_ltv")
                
            # Add shock standard deviation
            self.add_parameter("sigma_eps_ltv", 0.01, 
                              prior_dist="inv_gamma", 
                              prior_mean=0.01, prior_std=0.005,
                              description="Standard deviation of LTV shock")
            
        # Banking sector shock
        if self.friction_type == "banking":
            if "eps_kb" not in self.shocks:
                self.shocks.append("eps_kb")
                
            # Add shock standard deviation
            self.add_parameter("sigma_eps_kb", 0.01, 
                              prior_dist="inv_gamma", 
                              prior_mean=0.01, prior_std=0.005,
                              description="Standard deviation of bank capital shock")
            
    def add_financial_equations(self, base_model_equations: List[str]) -> List[str]:
        """Add financial equations to the model.
        
        Args:
            base_model_equations (List[str]): Base model equations
            
        Returns:
            List[str]: Extended model equations
        """
        equations = base_model_equations.copy()
        
        # Common financial equations
        equations.append("efp = efp_ss * (1 + eps_n)")
        
        # Financial accelerator equations
        if self.friction_type == "accelerator":
            equations.append("lev = q + k - n")  # Leverage definition
            equations.append("efp = efp_ss * lev^chi * (1 + eps_efp)")
            equations.append("n = nu * (rk * k(-1) - r(-1) * (q(-1) + k(-1) - n(-1))) + (1-nu) * w")
            
        # Collateral constraint equations
        elif self.friction_type == "collateral":
            equations.append("b <= ltv * theta * q * k * (1 + eps_ltv)")
            equations.append("efp = lambda_b * (ltv * theta * q * k * (1 + eps_ltv) - b)")
            equations.append("n = q * k - b")
            
        # Banking sector equations
        elif self.friction_type == "banking":
            equations.append("kb = (1 - delta_b) * kb(-1) + j_b + eps_kb")
            equations.append("b <= (1 / kappa_b - 1) * kb")
            equations.append("levb = b / kb")  # Bank leverage definition
            equations.append("efp = lambda_b * ((1 / kappa_b - 1) * kb - b)")
            equations.append("j_b = r_b * b - r * d")
            equations.append("d = b - kb")
            
        return equations
        
    def compute_steady_state(self) -> Dict[str, float]:
        """Compute the steady state of the model.
        
        Returns:
            Dict[str, float]: Steady state values
        """
        # Get base steady state
        ss = super().compute_steady_state()
        
        # Add financial variables
        # Steady-state interest rate
        r_ss = ss.get("r", 0.01)
        
        # External finance premium
        efp_ss = self.parameters["efp_ss"]["value"]
        ss["efp"] = efp_ss
        
        # Financial accelerator
        if self.friction_type == "accelerator":
            # Entrepreneurial survival rate
            nu = self.parameters["nu"]["value"]
            
            # Capital and investment
            k_ss = ss.get("k", 10.0)
            q_ss = ss.get("q", 1.0)
            
            # Net worth (assume 50% leverage)
            ss["n"] = 0.5 * q_ss * k_ss
            
            # Leverage
            ss["lev"] = np.log(q_ss * k_ss / ss["n"])
            
        # Collateral constraint
        elif self.friction_type == "collateral":
            # Loan-to-value ratio
            ltv = self.parameters["ltv"]["value"]
            theta = self.parameters["theta"]["value"]
            
            # Capital and investment
            k_ss = ss.get("k", 10.0)
            q_ss = ss.get("q", 1.0)
            
            # Borrowing constraint
            ss["b"] = ltv * theta * q_ss * k_ss
            
            # Net worth
            ss["n"] = q_ss * k_ss - ss["b"]
            
            # Lagrange multiplier
            ss["lambda_b"] = efp_ss / (ltv * theta * q_ss * k_ss - ss["b"] + 1e-10)
            
            # LTV as a variable (for monitoring)
            ss["ltv"] = ltv
            
        # Banking sector
        elif self.friction_type == "banking":
            # Bank capital requirement
            kappa_b = self.parameters["kappa_b"]["value"]
            
            # Capital and investment
            k_ss = ss.get("k", 10.0)
            q_ss = ss.get("q", 1.0)
            
            # Borrowing
            ss["b"] = 0.5 * q_ss * k_ss
            
            # Bank capital
            ss["kb"] = kappa_b * ss["b"]
            
            # Bank leverage
            ss["levb"] = ss["b"] / ss["kb"]
            
            # Deposits
            ss["d"] = ss["b"] - ss["kb"]
            
            # Bank profits
            ss["j_b"] = (r_ss + efp_ss) * ss["b"] - r_ss * ss["d"]
            
            # Lagrange multiplier
            ss["lambda_b"] = efp_ss / ((1 / kappa_b - 1) * ss["kb"] - ss["b"] + 1e-10)
            
        # Add log-linearized steady state (all zero)
        for var in ["efp", "n", "b", "kb", "d", "j_b", "lambda_b", "lev", "levb", "ltv"]:
            if var in ss:
                ss[f"{var}_hat"] = 0.0
                
        return ss
        
    def compute_financial_conditions_index(self, data: xr.Dataset) -> xr.DataArray:
        """Compute a financial conditions index.
        
        Args:
            data (xr.Dataset): Model simulated or estimated data
            
        Returns:
            xr.DataArray: Financial conditions index
        """
        # Extract relevant variables
        variables = []
        weights = []
        
        # Common variables
        if "efp" in data:
            variables.append(data["efp"])
            weights.append(1.0)
            
        # Financial accelerator
        if self.friction_type == "accelerator":
            if "n" in data:
                variables.append(-data["n"])  # Negative weight on net worth
                weights.append(0.5)
                
        # Collateral constraint
        elif self.friction_type == "collateral":
            if "lambda_b" in data:
                variables.append(data["lambda_b"])
                weights.append(0.5)
                
        # Banking sector
        elif self.friction_type == "banking":
            if "kb" in data:
                variables.append(-data["kb"])  # Negative weight on bank capital
                weights.append(0.5)
                
        # Normalize weights
        weights = [w / sum(weights) for w in weights]
        
        # Compute index
        fci = sum(w * v for w, v in zip(weights, variables))
        
        return fci


class FinancialSWModel(SWModel, FinancialFrictionBase):
    """Smets-Wouters model with financial frictions.
    
    This class extends the Smets-Wouters model with financial frictions,
    including financial accelerator, collateral constraints, and banking sector.
    """
    
    def __init__(self, name: str = "Financial Smets-Wouters Model", friction_type: str = "accelerator"):
        """Initialize the financial Smets-Wouters model.
        
        Args:
            name (str, optional): Name of the model. 
                Defaults to "Financial Smets-Wouters Model".
            friction_type (str, optional): Type of financial friction.
                Options: "accelerator", "collateral", "banking".
                Defaults to "accelerator".
        """
        # Initialize base classes
        SWModel.__init__(self, name=name)
        FinancialFrictionBase.__init__(self, friction_type=friction_type)
        
        # Add financial variables
        self._add_financial_variables()
        
        # Add financial parameters
        self.add_financial_parameters()
        
        # Add financial shocks
        self._add_financial_shocks()
        
        # Add financial equations
        self.equations = self.add_financial_equations(self.equations)
        
    def _add_sw_parameters(self):
        """Add Smets-Wouters parameters to the model."""
        # Household preferences
        self.add_parameter("beta", 0.99, 
                          prior_dist="beta", 
                          prior_mean=0.99, prior_std=0.002,
                          description="Discount factor")
        
        self.add_parameter("sigma_c", 1.5, 
                          prior_dist="normal", 
                          prior_mean=1.5, prior_std=0.375,
                          description="Elasticity of intertemporal substitution")
        
        self.add_parameter("h", 0.7, 
                          prior_dist="beta", 
                          prior_mean=0.7, prior_std=0.1,
                          description="Habit formation parameter")
        
        self.add_parameter("sigma_l", 2.0, 
                          prior_dist="normal", 
                          prior_mean=2.0, prior_std=0.75,
                          description="Inverse Frisch elasticity")
        
        # Production
        self.add_parameter("alpha", 0.3, 
                          prior_dist="normal", 
                          prior_mean=0.3, prior_std=0.05,
                          description="Capital share")
        
        self.add_parameter("delta", 0.025, 
                          prior_dist="beta", 
                          prior_mean=0.025, prior_std=0.005,
                          description="Depreciation rate")
        
        self.add_parameter("epsilon_p", 10.0, 
                          prior_dist="gamma", 
                          prior_mean=10.0, prior_std=2.5,
                          description="Price elasticity of demand")
        
        self.add_parameter("epsilon_w", 10.0, 
                          prior_dist="gamma", 
                          prior_mean=10.0, prior_std=2.5,
                          description="Wage elasticity of labor demand")
        
        # Price and wage setting
        self.add_parameter("xi_p", 0.75, 
                          prior_dist="beta", 
                          prior_mean=0.75, prior_std=0.05,
                          description="Calvo price stickiness")
        
        self.add_parameter("xi_w", 0.75, 
                          prior_dist="beta", 
                          prior_mean=0.75, prior_std=0.05,
                          description="Calvo wage stickiness")
        
        self.add_parameter("gamma_p", 0.5, 
                          prior_dist="beta", 
                          prior_mean=0.5, prior_std=0.15,
                          description="Price indexation")
        
        self.add_parameter("gamma_w", 0.5, 
                          prior_dist="beta", 
                          prior_mean=0.5, prior_std=0.15,
                          description="Wage indexation")
        
        # Investment
        self.add_parameter("phi_i", 4.0, 
                          prior_dist="normal", 
                          prior_mean=4.0, prior_std=1.5,
                          description="Investment adjustment cost")
        
        self.add_parameter("psi", 0.2, 
                          prior_dist="beta", 
                          prior_mean=0.2, prior_std=0.1,
                          description="Capital utilization cost")
        
        # Monetary policy
        self.add_parameter("phi_pi", 1.5, 
                          prior_dist="normal", 
                          prior_mean=1.5, prior_std=0.25,
  
(Content truncated due to size limit. Use line ranges to read in chunks)