            # Innovation rate
            equations.append("s = phi * (rd / a) ^ lambda")
            
            # Knowledge accumulation
            equations.append("a = (1 - delta_a) * a(-1) + s * a(-1) + eps_rd")
            
            # R&D investment (with adjustment costs)
            equations.append("rd = (1 - psi_rd/2 * (rd/rd(-1) - 1)^2) * rd(-1) + eps_rd")
            
            # Modify production function to include knowledge stock
            for i, eq in enumerate(equations):
                if eq.startswith("y =") and "k" in eq and "l" in eq:
                    # Replace with new production function including knowledge
                    equations[i] = eq.replace("z", "z + a")
                    break
                    
            # Modify resource constraint to include R&D
            for i, eq in enumerate(equations):
                if eq.startswith("y =") and "c +" in eq and "i +" in eq:
                    # Replace with new resource constraint including R&D
                    equations[i] = eq.replace("y =", "y = rd +")
                    break
                    
        # Endogenous growth
        if self.tech_type == "endogenous":
            # Modify neutral technology to depend on knowledge stock
            for i, eq in enumerate(equations):
                if eq.startswith("z ="):
                    # Replace with new technology process including knowledge feedback
                    equations[i] = "z = rho_z * z(-1) + lambda * (a - a(-1)) + eps_z"
                    break
                    
        return equations
        
    def compute_steady_state(self) -> Dict[str, float]:
        """Compute the steady state of the model.
        
        Returns:
            Dict[str, float]: Steady state values
        """
        # Get base steady state
        ss = super().compute_steady_state()
        
        # Add technology variables
        # Steady-state output
        y_ss = ss.get("y", 1.0)
        
        # Neutral technology
        z_ss = 0.0  # Log-linearized model, steady state is zero
        ss["z"] = z_ss
        
        # Investment-specific technology
        if self.tech_type == "ist" or self.tech_type == "endogenous":
            mu_ss = 0.0  # Log-linearized model, steady state is zero
            ss["mu"] = mu_ss
            
        # R&D variables
        if self.tech_type == "rd" or self.tech_type == "endogenous":
            # R&D investment
            rd_y_ratio = self.parameters["rd_y_ratio"]["value"]
            rd_ss = rd_y_ratio * y_ss
            ss["rd"] = rd_ss
            
            # Knowledge stock
            delta_a = self.parameters["delta_a"]["value"]
            phi = self.parameters["phi"]["value"]
            lambda_param = self.parameters["lambda"]["value"]
            
            # Steady-state innovation rate
            s_ss = delta_a
            ss["s"] = s_ss
            
            # Steady-state knowledge stock
            a_ss = (s_ss / phi) ** (1 / lambda_param) * rd_ss
            ss["a"] = a_ss
            
        return ss
        
    def compute_growth_accounting(self, data: pd.DataFrame, 
                                 variable_mapping: Optional[Dict[str, str]] = None) -> pd.DataFrame:
        """Compute growth accounting decomposition.
        
        Args:
            data (pd.DataFrame): Data for growth accounting
            variable_mapping (Dict[str, str], optional): Mapping from model variables
                to data columns. Defaults to None (use same names).
                
        Returns:
            pd.DataFrame: Growth accounting decomposition
        """
        # Create variable mapping if not provided
        if variable_mapping is None:
            variable_mapping = {var: var for var in self.variables}
            
        # Get relevant variables
        output_col = variable_mapping.get("y", "y")
        capital_col = variable_mapping.get("k", "k")
        labor_col = variable_mapping.get("l", "l")
        
        # Check if variables exist in data
        for col in [output_col, capital_col, labor_col]:
            if col not in data.columns:
                raise ValueError(f"Variable {col} not found in data")
                
        # Get data
        output = data[output_col].values
        capital = data[capital_col].values
        labor = data[labor_col].values
        
        # Get capital share
        alpha = self.parameters["alpha"]["value"]
        
        # Compute growth rates
        output_growth = np.diff(np.log(output)) * 100
        capital_growth = np.diff(np.log(capital)) * 100
        labor_growth = np.diff(np.log(labor)) * 100
        
        # Compute contributions
        capital_contrib = alpha * capital_growth
        labor_contrib = (1 - alpha) * labor_growth
        tfp_contrib = output_growth - capital_contrib - labor_contrib
        
        # Create DataFrame
        results = pd.DataFrame({
            "output_growth": output_growth,
            "capital_contrib": capital_contrib,
            "labor_contrib": labor_contrib,
            "tfp_contrib": tfp_contrib
        }, index=data.index[1:])
        
        return results
        
    def compute_technology_trends(self, data: pd.DataFrame,
                                 variable_mapping: Optional[Dict[str, str]] = None,
                                 hp_lambda: float = 1600) -> pd.DataFrame:
        """Compute technology trends using HP filter.
        
        Args:
            data (pd.DataFrame): Data for trend extraction
            variable_mapping (Dict[str, str], optional): Mapping from model variables
                to data columns. Defaults to None (use same names).
            hp_lambda (float, optional): HP filter smoothing parameter. Defaults to 1600.
                
        Returns:
            pd.DataFrame: Technology trends
        """
        try:
            from statsmodels.tsa.filters.hp_filter import hpfilter
        except ImportError:
            raise ImportError("statsmodels is required for HP filtering")
            
        # Create variable mapping if not provided
        if variable_mapping is None:
            variable_mapping = {var: var for var in self.variables}
            
        # Get relevant variables
        output_col = variable_mapping.get("y", "y")
        investment_col = variable_mapping.get("i", "i")
        
        # Check if variables exist in data
        for col in [output_col, investment_col]:
            if col not in data.columns:
                raise ValueError(f"Variable {col} not found in data")
                
        # Get data
        output = data[output_col].values
        investment = data[investment_col].values
        
        # Compute relative price of investment (proxy for IST)
        # In a real application, we would use actual price data
        # Here we use the investment-to-output ratio as a proxy
        rel_price = investment / output
        
        # Apply HP filter
        _, output_trend = hpfilter(np.log(output), lamb=hp_lambda)
        _, inv_trend = hpfilter(np.log(investment), lamb=hp_lambda)
        _, price_trend = hpfilter(np.log(rel_price), lamb=hp_lambda)
        
        # Compute growth rates
        output_trend_growth = np.diff(output_trend) * 100
        inv_trend_growth = np.diff(inv_trend) * 100
        price_trend_growth = -np.diff(price_trend) * 100  # Negative because price decrease = IST increase
        
        # Compute neutral technology trend (Solow residual)
        # Get capital share
        alpha = self.parameters["alpha"]["value"]
        neutral_tech_trend = output_trend_growth - alpha * inv_trend_growth
        
        # Create DataFrame
        results = pd.DataFrame({
            "neutral_tech_trend": neutral_tech_trend,
            "ist_trend": price_trend_growth,
            "output_trend_growth": output_trend_growth,
            "investment_trend_growth": inv_trend_growth
        }, index=data.index[1:])
        
        return results


class TechnologySWModel(TechnologyDSGEModel):