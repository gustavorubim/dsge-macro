"""
Model equations for the Smets-Wouters (2007) DSGE model.

This module provides the log-linearized equations for the Smets-Wouters (2007)
model, as well as utilities for constructing the model in both log-linearized
and non-linear forms.
"""

import numpy as np
import jax
import jax.numpy as jnp
from typing import Dict, List, Tuple, Optional, Union, Callable


def create_sw_equations():
    """Create the log-linearized equations for the Smets-Wouters model.
    
    Returns:
        List[Callable]: List of equation functions
    """
    equations = []
    
    # 1. Consumption Euler equation
    def consumption_euler(variables, parameters, lag_variables, lead_variables):
        c_t = variables['c_hat']
        c_t1 = lag_variables['c_hat']
        c_t_lead = lead_variables['c_hat']
        r_t = variables['r_hat']
        eps_b_t = variables['eps_b_hat']
        pi_t_lead = lead_variables['pi_hat']
        
        # Extract parameters
        h = parameters['h']
        sigma_c = parameters['sigma_c']
        
        # Equation: c_t = (h/(1+h)) * c_t-1 + (1/(1+h)) * E_t[c_t+1] + ((sigma_c-1)/sigma_c) * (w_t * l_t - w_t-1 * l_t-1) - (1-h)/(sigma_c*(1+h)) * (r_t - E_t[pi_t+1]) + eps_b_t
        return c_t - (h/(1+h)) * c_t1 - (1/(1+h)) * c_t_lead + (1-h)/(sigma_c*(1+h)) * (r_t - pi_t_lead) - eps_b_t
    
    equations.append(consumption_euler)
    
    # 2. Investment Euler equation
    def investment_euler(variables, parameters, lag_variables, lead_variables):
        i_t = variables['i_hat']
        i_t1 = lag_variables['i_hat']
        i_t_lead = lead_variables['i_hat']
        q_t = variables['q_hat']
        eps_i_t = variables['eps_i_hat']
        
        # Extract parameters
        beta = parameters['beta']
        phi_i = parameters['phi_i']
        
        # Equation: i_t = (1/(1+beta)) * i_t-1 + (beta/(1+beta)) * E_t[i_t+1] + (1/(phi_i*(1+beta))) * q_t + eps_i_t
        return i_t - (1/(1+beta)) * i_t1 - (beta/(1+beta)) * i_t_lead - (1/(phi_i*(1+beta))) * q_t - eps_i_t
    
    equations.append(investment_euler)
    
    # 3. Tobin's Q equation
    def tobins_q(variables, parameters, lag_variables, lead_variables):
        q_t = variables['q_hat']
        r_t = variables['r_hat']
        pi_t_lead = lead_variables['pi_hat']
        rk_t_lead = lead_variables['rk_hat']
        q_t_lead = lead_variables['q_hat']
        eps_b_t = variables['eps_b_hat']
        
        # Extract parameters
        beta = parameters['beta']
        delta = parameters['delta']
        
        # Equation: q_t = (beta*(1-delta)) * E_t[q_t+1] + (1-(beta*(1-delta))) * E_t[rk_t+1] - (r_t - E_t[pi_t+1] + eps_b_t)
        return q_t - beta*(1-delta) * q_t_lead - (1-(beta*(1-delta))) * rk_t_lead + (r_t - pi_t_lead + eps_b_t)
    
    equations.append(tobins_q)
    
    # 4. Capital accumulation equation
    def capital_accumulation(variables, parameters, lag_variables, lead_variables):
        k_t = variables['k_hat']
        k_t1 = lag_variables['k_hat']
        i_t = variables['i_hat']
        eps_i_t = variables['eps_i_hat']
        
        # Extract parameters
        delta = parameters['delta']
        
        # Equation: k_t = (1-delta) * k_t-1 + delta * i_t + delta * phi_i * eps_i_t
        return k_t - (1-delta) * k_t1 - delta * i_t - delta * parameters['phi_i'] * eps_i_t
    
    equations.append(capital_accumulation)
    
    # 5. Capital utilization equation
    def capital_utilization(variables, parameters, lag_variables, lead_variables):
        u_t = variables['u_hat']
        rk_t = variables['rk_hat']
        
        # Extract parameters
        psi = parameters['psi']
        
        # Equation: u_t = (1/psi) * rk_t
        return u_t - (1/psi) * rk_t
    
    equations.append(capital_utilization)
    
    # 6. Production function
    def production_function(variables, parameters, lag_variables, lead_variables):
        y_t = variables['y_hat']
        k_t1 = lag_variables['k_hat']
        u_t = variables['u_hat']
        L_t = variables['L_hat']
        eps_a_t = variables['eps_a_hat']
        
        # Extract parameters
        alpha = parameters['alpha']
        phi = parameters['phi']
        
        # Equation: y_t = phi * (alpha * (k_t-1 + u_t) + (1-alpha) * L_t + eps_a_t)
        return y_t - phi * (alpha * (k_t1 + u_t) + (1-alpha) * L_t + eps_a_t)
    
    equations.append(production_function)
    
    # 7. Marginal cost equation
    def marginal_cost(variables, parameters, lag_variables, lead_variables):
        mc_t = variables['mc_hat']
        w_t = variables['w_hat']
        rk_t = variables['rk_hat']
        k_t1 = lag_variables['k_hat']
        u_t = variables['u_hat']
        L_t = variables['L_hat']
        eps_a_t = variables['eps_a_hat']
        
        # Extract parameters
        alpha = parameters['alpha']
        
        # Equation: mc_t = alpha * rk_t + (1-alpha) * w_t - eps_a_t
        return mc_t - alpha * rk_t - (1-alpha) * w_t + eps_a_t
    
    equations.append(marginal_cost)
    
    # 8. Phillips curve (price setting)
    def phillips_curve(variables, parameters, lag_variables, lead_variables):
        pi_t = variables['pi_hat']
        pi_t1 = lag_variables['pi_hat']
        pi_t_lead = lead_variables['pi_hat']
        mc_t = variables['mc_hat']
        eps_p_t = variables['eps_p_hat']
        
        # Extract parameters
        beta = parameters['beta']
        xi_p = parameters['xi_p']
        gamma_p = parameters['gamma_p']
        
        # Equation: pi_t = (gamma_p/(1+beta*gamma_p)) * pi_t-1 + (beta/(1+beta*gamma_p)) * E_t[pi_t+1] + ((1-xi_p)*(1-beta*xi_p))/((1+beta*gamma_p)*xi_p) * mc_t + eps_p_t
        return pi_t - (gamma_p/(1+beta*gamma_p)) * pi_t1 - (beta/(1+beta*gamma_p)) * pi_t_lead - ((1-xi_p)*(1-beta*xi_p))/((1+beta*gamma_p)*xi_p) * mc_t - eps_p_t
    
    equations.append(phillips_curve)
    
    # 9. Wage setting equation
    def wage_setting(variables, parameters, lag_variables, lead_variables):
        w_t = variables['w_hat']
        w_t1 = lag_variables['w_hat']
        w_t_lead = lead_variables['w_hat']
        pi_t = variables['pi_hat']
        pi_t1 = lag_variables['pi_hat']
        pi_t_lead = lead_variables['pi_hat']
        L_t = variables['L_hat']
        c_t = variables['c_hat']
        c_t1 = lag_variables['c_hat']
        eps_w_t = variables['eps_w_hat']
        
        # Extract parameters
        beta = parameters['beta']
        xi_w = parameters['xi_w']
        gamma_w = parameters['gamma_w']
        sigma_l = parameters['sigma_l']
        sigma_c = parameters['sigma_c']
        h = parameters['h']
        
        # Equation: w_t = (1/(1+beta)) * w_t-1 + (beta/(1+beta)) * E_t[w_t+1] + (gamma_w/(1+beta)) * pi_t-1 - ((1+beta*gamma_w)/(1+beta)) * pi_t + (beta/(1+beta)) * E_t[pi_t+1]
        #           + ((1-xi_w)*(1-beta*xi_w))/((1+beta)*xi_w*(1+sigma_l*(1+1/(lambda_w-1)))) * (sigma_l * L_t + (1/(1-h)) * c_t - (h/(1-h)) * c_t-1 - w_t) + eps_w_t
        lambda_w = 1.5  # Wage markup
        return w_t - (1/(1+beta)) * w_t1 - (beta/(1+beta)) * w_t_lead - (gamma_w/(1+beta)) * pi_t1 + ((1+beta*gamma_w)/(1+beta)) * pi_t - (beta/(1+beta)) * pi_t_lead - ((1-xi_w)*(1-beta*xi_w))/((1+beta)*xi_w*(1+sigma_l*(1+1/(lambda_w-1)))) * (sigma_l * L_t + (1/(1-h)) * c_t - (h/(1-h)) * c_t1 - w_t) - eps_w_t
    
    equations.append(wage_setting)
    
    # 10. Monetary policy rule (Taylor rule)
    def taylor_rule(variables, parameters, lag_variables, lead_variables):
        r_t = variables['r_hat']
        r_t1 = lag_variables['r_hat']
        pi_t = variables['pi_hat']
        y_t = variables['y_hat']
        y_t1 = lag_variables['y_hat']
        y_pot_t = variables['y_pot_hat']
        y_pot_t1 = lag_variables['y_pot_hat']
        eps_r_t = variables['eps_r_hat']
        
        # Extract parameters
        rho = parameters['rho']
        r_pi = parameters['r_pi']
        r_y = parameters['r_y']
        r_dy = parameters['r_dy']
        
        # Equation: r_t = rho * r_t-1 + (1-rho) * (r_pi * pi_t + r_y * (y_t - y_pot_t)) + r_dy * ((y_t - y_pot_t) - (y_t-1 - y_pot_t-1)) + eps_r_t
        return r_t - rho * r_t1 - (1-rho) * (r_pi * pi_t + r_y * (y_t - y_pot_t)) - r_dy * ((y_t - y_pot_t) - (y_t1 - y_pot_t1)) - eps_r_t
    
    equations.append(taylor_rule)
    
    # 11. Market clearing condition
    def market_clearing(variables, parameters, lag_variables, lead_variables):
        y_t = variables['y_hat']
        c_t = variables['c_hat']
        i_t = variables['i_hat']
        u_t = variables['u_hat']
        g_t = variables['g_hat']
        
        # Extract parameters
        c_y = parameters.get('c_y', 0.6)  # Consumption-output ratio
        i_y = parameters.get('i_y', 0.2)  # Investment-output ratio
        g_y = parameters.get('g_y', 0.2)  # Government-output ratio
        r_k_ss = parameters.get('r_k_ss', 0.03)  # Steady state rental rate of capital
        
        # Equation: y_t = c_y * c_t + i_y * i_t + r_k_ss * u_t + g_t
        return y_t - c_y * c_t - i_y * i_t - r_k_ss * u_t - g_t
    
    equations.append(market_clearing)
    
    # 12-18. Shock processes (AR(1) processes)
    def productivity_shock(variables, parameters, lag_variables, lead_variables):
        eps_a_t = variables['eps_a_hat']
        eps_a_t1 = lag_variables['eps_a_hat']
        
        # Extract parameters
        rho_a = parameters.get('rho_a', 0.95)
        
        # Equation: eps_a_t = rho_a * eps_a_t-1 + e_a_t
        return eps_a_t - rho_a * eps_a_t1
    
    equations.append(productivity_shock)
    
    def risk_premium_shock(variables, parameters, lag_variables, lead_variables):
        eps_b_t = variables['eps_b_hat']
        eps_b_t1 = lag_variables['eps_b_hat']
        
        # Extract parameters
        rho_b = parameters.get('rho_b', 0.8)
        
        # Equation: eps_b_t = rho_b * eps_b_t-1 + e_b_t
        return eps_b_t - rho_b * eps_b_t1
    
    equations.append(risk_premium_shock)
    
    def government_shock(variables, parameters, lag_variables, lead_variables):
        g_t = variables['g_hat']
        g_t1 = lag_variables['g_hat']
        
        # Extract parameters
        rho_g = parameters.get('rho_g', 0.97)
        
        # Equation: g_t = rho_g * g_t-1 + e_g_t
        return g_t - rho_g * g_t1
    
    equations.append(government_shock)
    
    def investment_shock(variables, parameters, lag_variables, lead_variables):
        eps_i_t = variables['eps_i_hat']
        eps_i_t1 = lag_variables['eps_i_hat']
        
        # Extract parameters
        rho_i = parameters.get('rho_i', 0.8)
        
        # Equation: eps_i_t = rho_i * eps_i_t-1 + e_i_t
        return eps_i_t - rho_i * eps_i_t1
    
    equations.append(investment_shock)
    
    def monetary_policy_shock(variables, parameters, lag_variables, lead_variables):
        eps_r_t = variables['eps_r_hat']
        eps_r_t1 = lag_variables['eps_r_hat']
        
        # Extract parameters
        rho_r = parameters.get('rho_r', 0.15)
        
        # Equation: eps_r_t = rho_r * eps_r_t-1 + e_r_t
        return eps_r_t - rho_r * eps_r_t1
    
    equations.append(monetary_policy_shock)
    
    def price_markup_shock(variables, parameters, lag_variables, lead_variables):
        eps_p_t = variables['eps_p_hat']
        eps_p_t1 = lag_variables['eps_p_hat']
        
        # Extract parameters
        rho_p = parameters.get('rho_p', 0.9)
        
        # Equation: eps_p_t = rho_p * eps_p_t-1 + e_p_t
        return eps_p_t - rho_p * eps_p_t1
    
    equations.append(price_markup_shock)
    
    def wage_markup_shock(variables, parameters, lag_variables, lead_variables):
        eps_w_t = variables['eps_w_hat']
        eps_w_t1 = lag_variables['eps_w_hat']
        
        # Extract parameters
        rho_w = parameters.get('rho_w', 0.9)
        
        # Equation: eps_w_t = rho_w * eps_w_t-1 + e_w_t
        return eps_w_t - rho_w * eps_w_t1
    
    equations.append(wage_markup_shock)
    
    return equations


def create_sw_variables():
    """Create the list of variables for the Smets-Wouters model.
    
    Returns:
        List[str]: List of variable names
    """
    return [
        'y_hat',      # Output
        'c_hat',      # Consumption
        'i_hat',      # Investment
        'k_hat',      # Capital
        'L_hat',      # Labor
        'w_hat',      # Real wage
        'r_hat',      # Real interest rate
        'pi_hat',     # Inflation
        'rk_hat',     # Rental rate of capital
        'u_hat',      # Capital utilization
        'q_hat',      # Tobin's Q
        'mc_hat',     # Marginal cost
        'y_pot_hat',  # Potential output
        'g_hat',      # Government spending
        'eps_a_hat',  # Technology shock
        'eps_b_hat',  # Risk premium shock
        'eps_i_hat',  # Investment shock
        'eps_r_hat',  # Monetary policy shock
        'eps_p_hat',  # Price markup shock
        'eps_w_hat',  # Wage markup shock
    ]


def create_sw_shocks():
    """Create the list of shocks for the Smets-Wouters model.
    
    Returns:
        List[str]: List of shock names
    """
    return [
        'eps_a',  # Technology shock
        'eps_b',  # Risk premium shock
        'eps_g',  # Government spending shock
        'eps_i',  # Investment shock
        'eps_r',  # Monetary policy shock
        'eps_p',  # Price markup shock
        'eps_w',  # Wage markup shock
    ]


def create_sw_parameters():
    """Create the default parameters for the Smets-Wouters model.
    
    Returns:
        Dict[str, Dict]: Dictionary of parameter information
    """
    parameters = {
        # Household parameters
        'beta': {
            'value': 0.99,
            'prior_mean': 0.99,
            'prior_std': 0.002,
            'prior_dist': 'beta',
            'description': 'Discount factor'
        },
        'sigma_c': {
            'value': 1.5,
            'prior_mean': 1.5,
            'prior_std': 0.37,
            'prior_dist': 'normal',
            'description': 'Intertemporal elasticity of substitution'
        },
        'h': {
            'value': 0.7,
            'prior_mean': 0.7,
            'prior_std': 0.1,
            'prior_dist': 'beta',
            'description': 'Habit persistence'
        },
        'sigma_l': {
            'value': 2.0,
            'prior_mean': 2.0,
            'prior_std': 0.75,
            'prior_dist': 'normal',
            'description': 'Labor supply elasticity'
        },
        
        # Firm parameters
        'alpha': {
            'value': 0.3,
            'prior_mean': 0.3,
            'prior_std': 0.05,
            'prior_dist': 'normal',
            'description': 'Capital share'
        },
        'delta': {
            'value': 0.025,
            'prior_mean': 0.025,
            'prior_std': 0.005,
            'prior_dist': 'beta',
            'description': 'Depreciation rate'
        },
        'phi': {
            'value': 1.5,
            'prior_mean': 1.5,
            'prior_std': 0.25,
            'prior_dist': 'normal',
            'description': 'Fixed cost parameter'
        },
        'xi_p': {
            'value': 0.75,
            'prior_mean': 0.75,
            'prior_std': 0.05,
            'prior_dist': 'beta',
            'description': 'Price stickiness'
        },
        'xi_w': {
            'value': 0.75,
            'prior_mean': 0.75,
            'prior_std': 0.05,
            'prior_dist': 'beta',
            'description': 'Wage stickiness'
        },
        'gamma_p': {
            'value': 0.5,
            'prior_mean': 0.5,
            'prior_std': 0.15,
            'prior_dist': 'beta',
            'description': 'Price indexation'
        },
        'gamma_w': {
            'value': 0.5,
            'prior_mean': 0.5,
            'prior_std': 0.15,
            'prior_dist': 'beta',
            'description': 'Wage indexation'
        },
        'psi': {
            'value': 0.2,
            'prior_mean': 0.2,
            'prior_std': 0.1
(Content truncated due to size limit. Use line ranges to read in chunks)