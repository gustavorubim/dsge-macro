                    self.parameters[name]['value'] = value
                else:
                    raise ValueError(f"Parameter {name} not found in model")
        
        self.calibrated = True
        
    def compute_steady_state(self):
        """Compute the steady state of the model.
        
        This method should be implemented by subclasses.
        """
        raise NotImplementedError("Steady state computation not implemented")
        
    def linearize(self):
        """Linearize the model around the steady state.
        
        This method should be implemented by subclasses.
        """
        raise NotImplementedError("Model linearization not implemented")
        