"""
Steady state solvers for DSGE models.

This module provides utilities for computing the steady state of DSGE models,
including numerical solvers and analytical solutions for specific models.
"""

import numpy as np
import jax
import jax.numpy as jnp
from typing import Dict, List, Tuple, Optional, Union, Callable
from scipy import optimize


class SteadyStateSolver:
    """Base class for steady state solvers.
    
    This class provides methods for computing the steady state of DSGE models
    using various numerical methods.
    """
    
    def __init__(self, tolerance: float = 1e-6, max_iterations: int = 1000):
        """Initialize a steady state solver.
        
        Args:
            tolerance (float, optional): Convergence tolerance. Defaults to 1e-6.
            max_iterations (int, optional): Maximum number of iterations. Defaults to 1000.
        """
        self.tolerance = tolerance
        self.max_iterations = max_iterations
        
    def solve(self, equations: List[Callable], initial_guess: Dict[str, float]) -> Dict[str, float]:
        """Solve for the steady state using a numerical solver.
        
        Args:
            equations (List[Callable]): List of steady state equations
            initial_guess (Dict[str, float]): Initial guess for the steady state
            
        Returns:
            Dict[str, float]: Steady state values
        """
        # Convert the initial guess to a vector
        var_names = list(initial_guess.keys())
        x0 = np.array([initial_guess[var] for var in var_names])
        
        # Define the objective function
        def objective(x):
            # Convert the vector back to a dictionary
            values = {var: x[i] for i, var in enumerate(var_names)}
            
            # Evaluate the equations
            residuals = []
            for eq in equations:
                residuals.append(eq(values))
                
            return np.array(residuals)
        
        # Solve the system of equations
        result = optimize.root(objective, x0, method='hybr', tol=self.tolerance)
        
        if not result.success:
            raise ValueError(f"Steady state solver failed to converge: {result.message}")
            
        # Convert the solution back to a dictionary
        steady_state = {var: result.x[i] for i, var in enumerate(var_names)}
        
        return steady_state
        
    def solve_with_fsolve(self, equations: List[Callable], initial_guess: Dict[str, float]) -> Dict[str, float]:
        """Solve for the steady state using scipy.optimize.fsolve.
        
        Args:
            equations (List[Callable]): List of steady state equations
            initial_guess (Dict[str, float]): Initial guess for the steady state
            
        Returns:
            Dict[str, float]: Steady state values
        """
        # Convert the initial guess to a vector
        var_names = list(initial_guess.keys())
        x0 = np.array([initial_guess[var] for var in var_names])
        
        # Define the objective function
        def objective(x):
            # Convert the vector back to a dictionary
            values = {var: x[i] for i, var in enumerate(var_names)}
            
            # Evaluate the equations
            residuals = []
            for eq in equations:
                residuals.append(eq(values))
                
            return np.array(residuals)
        
        # Solve the system of equations
        result = optimize.fsolve(objective, x0, xtol=self.tolerance)
        
        # Convert the solution back to a dictionary
        steady_state = {var: result[i] for i, var in enumerate(var_names)}
        
        return steady_state
        
    def solve_with_fixed_point(self, update_func: Callable, initial_guess: Dict[str, float]) -> Dict[str, float]:
        """Solve for the steady state using fixed-point iteration.
        
        Args:
            update_func (Callable): Function that updates the steady state values
            initial_guess (Dict[str, float]): Initial guess for the steady state
            
        Returns:
            Dict[str, float]: Steady state values
        """
        current = initial_guess.copy()
        
        for i in range(self.max_iterations):
            next_values = update_func(current)
            
            # Check for convergence
            max_diff = 0
            for var in current:
                diff = abs(next_values[var] - current[var])
                max_diff = max(max_diff, diff)
                
            if max_diff < self.tolerance:
                return next_values
                
            current = next_values
            
        raise ValueError(f"Fixed-point iteration failed to converge after {self.max_iterations} iterations")
        
    def check_steady_state(self, equations: List[Callable], steady_state: Dict[str, float]) -> bool:
        """Check if a steady state solution satisfies the equations.
        
        Args:
            equations (List[Callable]): List of steady state equations
            steady_state (Dict[str, float]): Steady state values to check
            
        Returns:
            bool: True if the steady state satisfies the equations, False otherwise
        """
        # Evaluate the equations
        residuals = []
        for eq in equations:
            residuals.append(eq(steady_state))
            
        # Check if all residuals are close to zero
        max_residual = max(abs(np.array(residuals)))
        
        return max_residual < self.tolerance


class SWModelSteadyState:
    """Steady state solver for the Smets-Wouters model.
    
    This class provides analytical solutions for the steady state of the
    Smets-Wouters (2007) model.
    """
    
    def __init__(self):
        """Initialize the Smets-Wouters steady state solver."""
        pass
        
    def compute(self, parameters: Dict[str, float]) -> Dict[str, float]:
        """Compute the steady state of the Smets-Wouters model.
        
        Args:
            parameters (Dict[str, float]): Model parameters
            
        Returns:
            Dict[str, float]: Steady state values
        """
        # Extract parameters
        beta = parameters.get('beta', 0.99)  # Discount factor
        delta = parameters.get('delta', 0.025)  # Depreciation rate
        alpha = parameters.get('alpha', 0.3)  # Capital share
        phi = parameters.get('phi', 6.0)  # Fixed cost parameter
        sigma_c = parameters.get('sigma_c', 1.5)  # Intertemporal elasticity of substitution
        h = parameters.get('h', 0.7)  # Habit persistence
        sigma_l = parameters.get('sigma_l', 2.0)  # Labor supply elasticity
        xi_w = parameters.get('xi_w', 0.75)  # Wage stickiness
        xi_p = parameters.get('xi_p', 0.75)  # Price stickiness
        gamma_w = parameters.get('gamma_w', 0.5)  # Wage indexation
        gamma_p = parameters.get('gamma_p', 0.5)  # Price indexation
        psi = parameters.get('psi', 0.2)  # Capital utilization cost
        phi_i = parameters.get('phi_i', 1.5)  # Investment adjustment cost
        r_pi = parameters.get('r_pi', 1.5)  # Taylor rule inflation response
        r_y = parameters.get('r_y', 0.125)  # Taylor rule output response
        r_dy = parameters.get('r_dy', 0.125)  # Taylor rule output growth response
        rho = parameters.get('rho', 0.75)  # Interest rate smoothing
        pi_bar = parameters.get('pi_bar', 1.0)  # Steady state inflation
        gamma = parameters.get('gamma', 1.0)  # Steady state growth rate
        
        # Compute steady state values
        steady_state = {}
        
        # Inflation and interest rates
        steady_state['pi'] = pi_bar
        steady_state['r'] = pi_bar * gamma / beta - 1  # Real interest rate
        steady_state['R'] = (1 + steady_state['r']) * pi_bar  # Nominal interest rate
        
        # Capital and investment
        steady_state['rk'] = (1/beta - (1-delta)) / alpha  # Rental rate of capital
        steady_state['k_y'] = alpha / steady_state['rk']  # Capital-output ratio
        steady_state['i_y'] = delta * steady_state['k_y']  # Investment-output ratio
        
        # Labor and wages
        steady_state['L'] = 1.0  # Normalized labor
        steady_state['w'] = (1-alpha) * (steady_state['k_y'])**(alpha/(1-alpha))  # Real wage
        
        # Output and consumption
        steady_state['y'] = (steady_state['k_y'])**(-alpha/(1-alpha)) * steady_state['L']  # Output
        steady_state['k'] = steady_state['k_y'] * steady_state['y']  # Capital
        steady_state['i'] = steady_state['i_y'] * steady_state['y']  # Investment
        steady_state['c'] = steady_state['y'] - steady_state['i']  # Consumption
        
        # Other variables
        steady_state['z'] = 1.0  # Technology level (normalized)
        steady_state['u'] = 1.0  # Capital utilization (normalized)
        steady_state['q'] = 1.0  # Tobin's Q (normalized)
        steady_state['mc'] = 1.0 / (1 + 1/(phi-1))  # Marginal cost
        
        # Log-linearized steady state (all zero)
        # Fix: Create a copy of the keys to avoid modifying the dictionary during iteration
        var_keys = list(steady_state.keys())
        for var in var_keys:
            steady_state[f"{var}_hat"] = 0.0
            
        return steady_state
