"""
Parameter handling for DSGE models.

This module provides utilities for managing model parameters, including
prior distributions for Bayesian estimation, parameter transformations,
and parameter constraints.
"""

import numpy as np
import jax
import jax.numpy as jnp
from typing import Dict, List, Tuple, Optional, Union, Callable
import pymc as pm
import arviz as az


class ParameterManager:
    """Manager for DSGE model parameters.
    
    This class provides utilities for managing model parameters, including
    prior distributions for Bayesian estimation, parameter transformations,
    and parameter constraints.
    
    Attributes:
        parameters (Dict): Dictionary of model parameters
        priors (Dict): Dictionary of prior distributions
        bounds (Dict): Dictionary of parameter bounds
        transformations (Dict): Dictionary of parameter transformations
    """
    
    def __init__(self):
        """Initialize a parameter manager."""
        self.parameters = {}
        self.priors = {}
        self.bounds = {}
        self.transformations = {}
        
    def add_parameter(self, name: str, value: float, prior_mean: Optional[float] = None, 
                     prior_std: Optional[float] = None, prior_dist: Optional[str] = None,
                     lower_bound: Optional[float] = None, upper_bound: Optional[float] = None,
                     transformation: Optional[str] = None, description: Optional[str] = None):
        """Add a parameter to the manager.
        
        Args:
            name (str): Name of the parameter
            value (float): Value of the parameter
            prior_mean (float, optional): Mean of the prior distribution. Defaults to None.
            prior_std (float, optional): Standard deviation of the prior distribution. Defaults to None.
            prior_dist (str, optional): Type of prior distribution. Defaults to None.
                Options: "normal", "beta", "gamma", "inv_gamma", "uniform"
            lower_bound (float, optional): Lower bound for the parameter. Defaults to None.
            upper_bound (float, optional): Upper bound for the parameter. Defaults to None.
            transformation (str, optional): Transformation to apply to the parameter. Defaults to None.
                Options: "exp", "logit", "log", "identity"
            description (str, optional): Description of the parameter. Defaults to None.
        """
        self.parameters[name] = {
            'value': value,
            'prior_mean': prior_mean,
            'prior_std': prior_std,
            'prior_dist': prior_dist,
            'description': description
        }
        
        if lower_bound is not None or upper_bound is not None:
            self.bounds[name] = (lower_bound, upper_bound)
            
        if transformation is not None:
            self.transformations[name] = transformation
            
        if prior_dist is not None and prior_mean is not None and prior_std is not None:
            self.priors[name] = {
                'dist': prior_dist,
                'mean': prior_mean,
                'std': prior_std
            }
            
    def get_parameter(self, name: str) -> float:
        """Get the value of a parameter.
        
        Args:
            name (str): Name of the parameter
            
        Returns:
            float: Value of the parameter
        """
        if name not in self.parameters:
            raise ValueError(f"Parameter {name} not found")
            
        return self.parameters[name]['value']
        
    def set_parameter(self, name: str, value: float):
        """Set the value of a parameter.
        
        Args:
            name (str): Name of the parameter
            value (float): Value to set
        """
        if name not in self.parameters:
            raise ValueError(f"Parameter {name} not found")
            
        self.parameters[name]['value'] = value
        
    def get_all_parameters(self) -> Dict[str, float]:
        """Get all parameter values.
        
        Returns:
            Dict[str, float]: Dictionary of parameter values
        """
        return {name: param['value'] for name, param in self.parameters.items()}
        
    def set_all_parameters(self, values: Dict[str, float]):
        """Set multiple parameter values.
        
        Args:
            values (Dict[str, float]): Dictionary of parameter values to set
        """
        for name, value in values.items():
            if name in self.parameters:
                self.parameters[name]['value'] = value
            else:
                raise ValueError(f"Parameter {name} not found")
                
    def transform_parameter(self, name: str, value: float) -> float:
        """Apply transformation to a parameter value.
        
        Args:
            name (str): Name of the parameter
            value (float): Value to transform
            
        Returns:
            float: Transformed value
        """
        if name not in self.transformations:
            return value
            
        transform = self.transformations[name]
        
        if transform == 'exp':
            return np.exp(value)
        elif transform == 'log':
            return np.log(value)
        elif transform == 'logit':
            lower, upper = self.bounds.get(name, (-np.inf, np.inf))
            if lower == -np.inf or upper == np.inf:
                raise ValueError(f"Logit transformation requires finite bounds for parameter {name}")
            return lower + (upper - lower) / (1 + np.exp(-value))
        elif transform == 'identity':
            return value
        else:
            raise ValueError(f"Unknown transformation: {transform}")
            
    def inverse_transform_parameter(self, name: str, value: float) -> float:
        """Apply inverse transformation to a parameter value.
        
        Args:
            name (str): Name of the parameter
            value (float): Value to inverse transform
            
        Returns:
            float: Inverse transformed value
        """
        if name not in self.transformations:
            return value
            
        transform = self.transformations[name]
        
        if transform == 'exp':
            return np.log(value)
        elif transform == 'log':
            return np.exp(value)
        elif transform == 'logit':
            lower, upper = self.bounds.get(name, (-np.inf, np.inf))
            if lower == -np.inf or upper == np.inf:
                raise ValueError(f"Logit transformation requires finite bounds for parameter {name}")
            return -np.log((upper - lower) / (value - lower) - 1)
        elif transform == 'identity':
            return value
        else:
            raise ValueError(f"Unknown transformation: {transform}")
            
    def create_prior_distribution(self, name: str, model: Optional[pm.Model] = None) -> pm.Distribution:
        """Create a PyMC prior distribution for a parameter.
        
        Args:
            name (str): Name of the parameter
            model (pm.Model, optional): PyMC model to add the distribution to. Defaults to None.
            
        Returns:
            pm.Distribution: PyMC distribution object
        """
        if name not in self.priors:
            raise ValueError(f"No prior defined for parameter {name}")
            
        prior = self.priors[name]
        dist_type = prior['dist']
        mean = prior['mean']
        std = prior['std']
        
        # Get bounds if they exist
        lower, upper = self.bounds.get(name, (-np.inf, np.inf))
        
        # Create the distribution
        if dist_type == 'normal':
            return pm.Normal(name, mu=mean, sigma=std, model=model)
        elif dist_type == 'beta':
            # For beta, we need to compute alpha and beta from mean and std
            if lower != 0 or upper != 1:
                raise ValueError("Beta distribution requires bounds [0, 1]")
            variance = std ** 2
            alpha = mean * (mean * (1 - mean) / variance - 1)
            beta = (1 - mean) * (mean * (1 - mean) / variance - 1)
            return pm.Beta(name, alpha=alpha, beta=beta, model=model)
        elif dist_type == 'gamma':
            if lower < 0:
                raise ValueError("Gamma distribution requires lower bound >= 0")
            # For gamma, we need to compute alpha and beta from mean and std
            variance = std ** 2
            alpha = (mean ** 2) / variance
            beta = mean / variance
            return pm.Gamma(name, alpha=alpha, beta=beta, model=model)
        elif dist_type == 'inv_gamma':
            if lower < 0:
                raise ValueError("Inverse gamma distribution requires lower bound >= 0")
            # For inverse gamma, we need to compute alpha and beta from mean and std
            variance = std ** 2
            alpha = 2 + (mean ** 2) / variance
            beta = mean * (alpha - 1)
            return pm.InverseGamma(name, alpha=alpha, beta=beta, model=model)
        elif dist_type == 'uniform':
            if lower == -np.inf or upper == np.inf:
                raise ValueError("Uniform distribution requires finite bounds")
            return pm.Uniform(name, lower=lower, upper=upper, model=model)
        else:
            raise ValueError(f"Unknown distribution type: {dist_type}")
            
    def create_all_priors(self, model: Optional[pm.Model] = None) -> Dict[str, pm.Distribution]:
        """Create PyMC prior distributions for all parameters with priors.
        
        Args:
            model (pm.Model, optional): PyMC model to add the distributions to. Defaults to None.
            
        Returns:
            Dict[str, pm.Distribution]: Dictionary of PyMC distribution objects
        """
        distributions = {}
        
        for name in self.priors:
            distributions[name] = self.create_prior_distribution(name, model)
            
        return distributions
        
    def apply_bounds(self, name: str, value: float) -> float:
        """Apply bounds to a parameter value.
        
        Args:
            name (str): Name of the parameter
            value (float): Value to bound
            
        Returns:
            float: Bounded value
        """
        if name not in self.bounds:
            return value
            
        lower, upper = self.bounds[name]
        
        if lower is not None and value < lower:
            return lower
        elif upper is not None and value > upper:
            return upper
        else:
            return value
            
    def apply_all_bounds(self, values: Dict[str, float]) -> Dict[str, float]:
        """Apply bounds to multiple parameter values.
        
        Args:
            values (Dict[str, float]): Dictionary of parameter values
            
        Returns:
            Dict[str, float]: Dictionary of bounded parameter values
        """
        bounded_values = {}
        
        for name, value in values.items():
            bounded_values[name] = self.apply_bounds(name, value)
            
        return bounded_values
        
    def get_prior_mean(self, name: str) -> float:
        """Get the prior mean for a parameter.
        
        Args:
            name (str): Name of the parameter
            
        Returns:
            float: Prior mean
        """
        if name not in self.priors:
            raise ValueError(f"No prior defined for parameter {name}")
            
        return self.priors[name]['mean']
        
    def get_prior_std(self, name: str) -> float:
        """Get the prior standard deviation for a parameter.
        
        Args:
            name (str): Name of the parameter
            
        Returns:
            float: Prior standard deviation
        """
        if name not in self.priors:
            raise ValueError(f"No prior defined for parameter {name}")
            
        return self.priors[name]['std']
        
    def get_prior_dist(self, name: str) -> str:
        """Get the prior distribution type for a parameter.
        
        Args:
            name (str): Name of the parameter
            
        Returns:
            str: Prior distribution type
        """
        if name not in self.priors:
            raise ValueError(f"No prior defined for parameter {name}")
            
        return self.priors[name]['dist']
        
    def get_bounds(self, name: str) -> Tuple[Optional[float], Optional[float]]:
        """Get the bounds for a parameter.
        
        Args:
            name (str): Name of the parameter
            
        Returns:
            Tuple[Optional[float], Optional[float]]: Lower and upper bounds
        """
        if name not in self.bounds:
            return (None, None)
            
        return self.bounds[name]
        
    def get_transformation(self, name: str) -> Optional[str]:
        """Get the transformation for a parameter.
        
        Args:
            name (str): Name of the parameter
            
        Returns:
            Optional[str]: Transformation type
        """
        if name not in self.transformations:
            return None
            
        return self.transformations[name]
        
    def __str__(self) -> str:
        """Return a string representation of the parameter manager.
        
        Returns:
            str: String representation of the parameter manager
        """
        return f"ParameterManager with {len(self.parameters)} parameters"