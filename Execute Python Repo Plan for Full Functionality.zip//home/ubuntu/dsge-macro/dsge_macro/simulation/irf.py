"""
Impulse response function generation for DSGE models.

This module provides utilities for generating and analyzing impulse response
functions (IRFs) for DSGE models.
"""

import numpy as np
import jax
import jax.numpy as jnp
from typing import Dict, List, Tuple, Optional, Union, Callable
import pandas as pd
import xarray as xr
import matplotlib.pyplot as plt

from dsge_macro.core.model import DSGEModel


class IRFGenerator:
    """Generator for impulse response functions.
    
    This class provides methods for generating and analyzing impulse response
    functions (IRFs) for DSGE models.
    
    Attributes:
        model (DSGEModel): DSGE model
    """
    
    def __init__(self, model: DSGEModel):
        """Initialize an IRF generator.
        
        Args:
            model (DSGEModel): DSGE model
        """
        self.model = model
        
    def generate_irf(self, shock: str, periods: int = 40, 
                    variables: Optional[List[str]] = None,
                    shock_size: float = 1.0) -> xr.Dataset:
        """Generate impulse response functions for a given shock.
        
        Args:
            shock (str): Name of the shock
            periods (int, optional): Number of periods to simulate. Defaults to 40.
            variables (List[str], optional): List of variables to include in the IRF.
                Defaults to None (all variables).
            shock_size (float, optional): Size of the shock in standard deviations.
                Defaults to 1.0.
                
        Returns:
            xr.Dataset: Dataset containing the impulse response functions
        """
        if not self.model.solved:
            self.model.solve()
            
        if shock not in self.model.shocks:
            raise ValueError(f"Shock {shock} not found in model")
            
        # Get shock index
        shock_idx = self.model.shocks.index(shock)
        
        # Get variables to include
        if variables is None:
            variables = self.model.variables
        else:
            for var in variables:
                if var not in self.model.variables:
                    raise ValueError(f"Variable {var} not found in model")
        
        # Get variable indices
        var_indices = [self.model.variables.index(var) for var in variables]
        
        # Initialize IRF
        irf = np.zeros((periods, len(variables)))
        
        # Get solution matrices
        T = self.model.solution['T']
        R = self.model.solution['R']
        
        # Get shock standard deviation
        shock_std = self.model.parameters.get(f"sigma_{shock}", {}).get('value', 1.0)
        
        # Compute IRF
        state = np.zeros(len(self.model.variables))
        
        # Initial shock
        state = R[:, shock_idx] * shock_size * shock_std
        irf[0, :] = state[var_indices]
        
        # Propagate the shock
        for t in range(1, periods):
            state = T @ state
            irf[t, :] = state[var_indices]
        
        # Create xarray dataset
        ds = xr.Dataset(
            data_vars={var: (('time'), irf[:, i]) for i, var in enumerate(variables)},
            coords={'time': np.arange(periods)}
        )
        
        # Add metadata
        ds.attrs['shock'] = shock
        ds.attrs['shock_size'] = shock_size
        ds.attrs['model'] = self.model.name
        
        return ds
        
    def generate_multiple_irfs(self, shocks: List[str], periods: int = 40,
                              variables: Optional[List[str]] = None,
                              shock_size: float = 1.0) -> Dict[str, xr.Dataset]:
        """Generate impulse response functions for multiple shocks.
        
        Args:
            shocks (List[str]): List of shocks
            periods (int, optional): Number of periods to simulate. Defaults to 40.
            variables (List[str], optional): List of variables to include in the IRF.
                Defaults to None (all variables).
            shock_size (float, optional): Size of the shock in standard deviations.
                Defaults to 1.0.
                
        Returns:
            Dict[str, xr.Dataset]: Dictionary of datasets containing the impulse response functions
        """
        irfs = {}
        
        for shock in shocks:
            irfs[shock] = self.generate_irf(shock, periods, variables, shock_size)
            
        return irfs
        
    def plot_irf(self, irf: xr.Dataset, variables: Optional[List[str]] = None,
                figsize: Tuple[int, int] = (12, 8), ncols: int = 3,
                title: Optional[str] = None) -> plt.Figure:
        """Plot impulse response functions.
        
        Args:
            irf (xr.Dataset): Dataset containing the impulse response functions
            variables (List[str], optional): List of variables to plot.
                Defaults to None (all variables in the dataset).
            figsize (Tuple[int, int], optional): Figure size. Defaults to (12, 8).
            ncols (int, optional): Number of columns in the plot grid. Defaults to 3.
            title (str, optional): Title for the plot. Defaults to None.
                
        Returns:
            plt.Figure: Figure object
        """
        # Get variables to plot
        if variables is None:
            variables = list(irf.data_vars)
        else:
            for var in variables:
                if var not in irf.data_vars:
                    raise ValueError(f"Variable {var} not found in IRF dataset")
                    
        # Compute number of rows and columns
        n_vars = len(variables)
        ncols = min(ncols, n_vars)
        nrows = (n_vars + ncols - 1) // ncols
        
        # Create figure
        fig, axes = plt.subplots(nrows, ncols, figsize=figsize, squeeze=False)
        
        # Plot IRFs
        for i, var in enumerate(variables):
            row = i // ncols
            col = i % ncols
            ax = axes[row, col]
            
            # Plot IRF
            ax.plot(irf.time, irf[var], linewidth=2)
            
            # Add horizontal line at zero
            ax.axhline(y=0, color='k', linestyle='-', alpha=0.2)
            
            # Add labels
            ax.set_title(var)
            ax.set_xlabel('Periods')
            ax.set_ylabel('Deviation from SS')
            
        # Add overall title
        if title is None:
            shock = irf.attrs.get('shock', 'Unknown')
            shock_size = irf.attrs.get('shock_size', 1.0)
            title = f"Impulse Response Functions: {shock} Shock ({shock_size} SD)"
            
        fig.suptitle(title, fontsize=14)
        
        # Adjust layout
        fig.tight_layout(rect=[0, 0, 1, 0.95])
        
        # Remove empty subplots
        for i in range(n_vars, nrows * ncols):
            row = i // ncols
            col = i % ncols
            fig.delaxes(axes[row, col])
            
        return fig
        
    def plot_multiple_irfs(self, irfs: Dict[str, xr.Dataset], variable: str,
                          figsize: Tuple[int, int] = (10, 6),
                          title: Optional[str] = None) -> plt.Figure:
        """Plot impulse response functions for a single variable across multiple shocks.
        
        Args:
            irfs (Dict[str, xr.Dataset]): Dictionary of datasets containing the impulse response functions
            variable (str): Variable to plot
            figsize (Tuple[int, int], optional): Figure size. Defaults to (10, 6).
            title (str, optional): Title for the plot. Defaults to None.
                
        Returns:
            plt.Figure: Figure object
        """
        # Check if variable exists in all IRFs
        for shock, irf in irfs.items():
            if variable not in irf.data_vars:
                raise ValueError(f"Variable {variable} not found in IRF dataset for {shock} shock")
                
        # Create figure
        fig, ax = plt.subplots(figsize=figsize)
        
        # Plot IRFs
        for shock, irf in irfs.items():
            ax.plot(irf.time, irf[variable], linewidth=2, label=shock)
            
        # Add horizontal line at zero
        ax.axhline(y=0, color='k', linestyle='-', alpha=0.2)
        
        # Add labels and legend
        ax.set_xlabel('Periods')
        ax.set_ylabel('Deviation from SS')
        ax.legend()
        
        # Add title
        if title is None:
            title = f"Impulse Response Functions: {variable}"
            
        ax.set_title(title)
        
        # Adjust layout
        fig.tight_layout()
        
        return fig
        
    def compare_irfs(self, irf1: xr.Dataset, irf2: xr.Dataset, 
                    variables: Optional[List[str]] = None,
                    labels: Tuple[str, str] = ('Model 1', 'Model 2'),
                    figsize: Tuple[int, int] = (12, 8), ncols: int = 3,
                    title: Optional[str] = None) -> plt.Figure:
        """Compare impulse response functions from two different models or parameterizations.
        
        Args:
            irf1 (xr.Dataset): First IRF dataset
            irf2 (xr.Dataset): Second IRF dataset
            variables (List[str], optional): List of variables to plot.
                Defaults to None (variables common to both datasets).
            labels (Tuple[str, str], optional): Labels for the two IRFs.
                Defaults to ('Model 1', 'Model 2').
            figsize (Tuple[int, int], optional): Figure size. Defaults to (12, 8).
            ncols (int, optional): Number of columns in the plot grid. Defaults to 3.
            title (str, optional): Title for the plot. Defaults to None.
                
        Returns:
            plt.Figure: Figure object
        """
        # Get variables to plot
        if variables is None:
            variables = [var for var in irf1.data_vars if var in irf2.data_vars]
        else:
            for var in variables:
                if var not in irf1.data_vars:
                    raise ValueError(f"Variable {var} not found in first IRF dataset")
                if var not in irf2.data_vars:
                    raise ValueError(f"Variable {var} not found in second IRF dataset")
                    
        # Compute number of rows and columns
        n_vars = len(variables)
        ncols = min(ncols, n_vars)
        nrows = (n_vars + ncols - 1) // ncols
        
        # Create figure
        fig, axes = plt.subplots(nrows, ncols, figsize=figsize, squeeze=False)
        
        # Plot IRFs
        for i, var in enumerate(variables):
            row = i // ncols
            col = i % ncols
            ax = axes[row, col]
            
            # Plot IRFs
            ax.plot(irf1.time, irf1[var], linewidth=2, label=labels[0])
            ax.plot(irf2.time, irf2[var], linewidth=2, linestyle='--', label=labels[1])
            
            # Add horizontal line at zero
            ax.axhline(y=0, color='k', linestyle='-', alpha=0.2)
            
            # Add labels
            ax.set_title(var)
            ax.set_xlabel('Periods')
            ax.set_ylabel('Deviation from SS')
            
            # Add legend to first subplot
            if i == 0:
                ax.legend()
                
        # Add overall title
        if title is None:
            shock1 = irf1.attrs.get('shock', 'Unknown')
            shock2 = irf2.attrs.get('shock', 'Unknown')
            if shock1 == shock2:
                title = f"Comparison of Impulse Response Functions: {shock1} Shock"
            else:
                title = f"Comparison of Impulse Response Functions"
            
        fig.suptitle(title, fontsize=14)
        
        # Adjust layout
        fig.tight_layout(rect=[0, 0, 1, 0.95])
        
        # Remove empty subplots
        for i in range(n_vars, nrows * ncols):
            row = i // ncols
            col = i % ncols
            fig.delaxes(axes[row, col])
            
        return fig
        
    def compute_cumulative_irf(self, irf: xr.Dataset) -> xr.Dataset:
        """Compute cumulative impulse response functions.
        
        Args:
            irf (xr.Dataset): Dataset containing the impulse response functions
                
        Returns:
            xr.Dataset: Dataset containing the cumulative impulse response functions
        """
        # Initialize cumulative IRF
        cum_irf = xr.Dataset(coords={'time': irf.time})
        
        # Compute cumulative sum for each variable
        for var in irf.data_vars:
            cum_irf[var] = irf[var].cumsum(dim='time')
            
        # Copy metadata
        cum_irf.attrs = irf.attrs.copy()
        cum_irf.attrs['cumulative'] = True
        
        return cum_irf
        
    def compute_peak_response(self, irf: xr.Dataset) -> Dict[str, Tuple[float, int]]:
        """Compute the peak response for each variable.
        
        Args:
            irf (xr.Dataset): Dataset containing the impulse response functions
                
        Returns:
            Dict[str, Tuple[float, int]]: Dictionary of peak responses and their timing
        """
        peak_response = {}
        
        for var in irf.data_vars:
            # Get absolute values
            abs_values = np.abs(irf[var].values)
            
            # Find peak
            peak_idx = np.argmax(abs_values)
            peak_value = irf[var].values[peak_idx]
            
            peak_response[var] = (peak_value, peak_idx)
            
        return peak_response
        
    def compute_half_life(self, irf: xr.Dataset) -> Dict[str, Optional[int]]:
        """Compute the half-life of the response for each variable.
        
        Args:
            irf (xr.Dataset): Dataset containing the impulse response functions
                
        Returns:
            Dict[str, Optional[int]]: Dictionary of half-lives
        """
        half_life = {}
        
        for var in irf.data_vars:
            # Get values
            values = irf[var].values
            
            # Get peak
            peak_idx = np.argmax(np.abs(values))
            peak_value = values[peak_idx]
            
            # If peak is zero, half-life is undefined
            if peak_value == 0:
                half_life[var] = None
                continue
                
            # Compute half of peak
            half_peak = peak_value / 2
            
            # Find first time after peak where response is less than half of peak
            half_life_idx = None
            for t in range(peak_idx + 1, len(values)):
                if np.abs(values[t]) <= np.abs(half_peak):
                    half_life_idx = t - peak_idx
                    break
                    
            half_life[var] = half_life_idx
            
        return half_life
        
    def compute_persistence(self, irf: xr.Dataset, horizon: int = 20) -> Dict[str, float]:
        """Compute the persistence of the response for each variable.
        
        Args:
            irf (xr.Dataset): Dataset containing the impulse response functions
            horizon (int, optional): Horizon for computing persistence. Defaults to 20.
                
        Returns:
            Dict[str, float]: Dictionary of persistence measures
        """
        persistence = {}
        
        for var in irf.data_vars:
            # Get values
            values = irf[var].values
            
            # Compute sum of absolute values up to horizon
            if horizon > len(values):
                horizon = len(values)
                
            sum_abs = np.sum(np.abs(values[:horizon]))
            
            # Normalize by initial impact
            if values[0] != 0:
                persistence[var] = sum_abs / np.abs(values[0])
            else:
                persistence[var] = np.nan
                
        return persistence
