"""
Forecasting tools for DSGE models.

This module provides utilities for generating and analyzing forecasts
from DSGE models, including point forecasts, forecast intervals,
and conditional forecasts.
"""

import numpy as np
import jax
import jax.numpy as jnp
from typing import Dict, List, Tuple, Optional, Union, Callable
import pandas as pd
import xarray as xr
import matplotlib.pyplot as plt
from scipy import stats

from dsge_macro.core.model import DSGEModel


class Forecaster:
    """Forecaster for DSGE models.
    
    This class provides methods for generating and analyzing forecasts
    from DSGE models.
    
    Attributes:
        model (DSGEModel): DSGE model
    """
    
    def __init__(self, model: DSGEModel):
        """Initialize a forecaster.
        
        Args:
            model (DSGEModel): DSGE model
        """
        self.model = model
        
    def generate_forecast(self, initial_state: Dict[str, float], 
                         periods: int = 20, n_simulations: int = 100,
                         variables: Optional[List[str]] = None,
                         shock_scale: float = 1.0) -> xr.Dataset:
        """Generate forecasts from the model.
        
        Args:
            initial_state (Dict[str, float]): Initial state of the model
            periods (int, optional): Number of periods to forecast. Defaults to 20.
            n_simulations (int, optional): Number of simulations to run. Defaults to 100.
            variables (List[str], optional): Variables to include in the forecast.
                Defaults to None (all variables).
            shock_scale (float, optional): Scale factor for shock standard deviations.
                Defaults to 1.0.
                
        Returns:
            xr.Dataset: Dataset containing the forecasts
        """
        if not self.model.solved:
            self.model.solve()
            
        # Get variables to include
        if variables is None:
            variables = self.model.variables
        else:
            for var in variables:
                if var not in self.model.variables:
                    raise ValueError(f"Variable {var} not found in model")
        
        # Get variable indices
        var_indices = [self.model.variables.index(var) for var in variables]
        
        # Get solution matrices
        T = self.model.solution['T']
        R = self.model.solution['R']
        
        # Get shock standard deviations
        shock_stds = np.array([self.model.parameters.get(f"sigma_{shock}", {}).get('value', 1.0) 
                              for shock in self.model.shocks])
        
        # Initialize forecasts
        forecasts = np.zeros((n_simulations, periods, len(variables)))
        
        # Convert initial state to vector
        initial_vector = np.zeros(len(self.model.variables))
        for var, value in initial_state.items():
            if var in self.model.variables:
                idx = self.model.variables.index(var)
                initial_vector[idx] = value
                
        # Generate forecasts
        for i in range(n_simulations):
            # Initialize state
            state = initial_vector.copy()
            
            # Generate random shocks
            rng = np.random.default_rng(seed=i)
            shocks = rng.normal(0, 1, (periods, len(self.model.shocks))) * shock_stds * shock_scale
            
            # Simulate the model
            for t in range(periods):
                # Update state
                state = T @ state + R @ shocks[t, :]
                
                # Store results
                forecasts[i, t, :] = state[var_indices]
                
        # Create xarray dataset
        ds = xr.Dataset(
            data_vars={var: (('simulation', 'time'), forecasts[:, :, i]) 
                      for i, var in enumerate(variables)},
            coords={'simulation': np.arange(n_simulations), 'time': np.arange(periods)}
        )
        
        # Add metadata
        ds.attrs['model'] = self.model.name
        ds.attrs['shock_scale'] = shock_scale
        
        return ds
        
    def generate_conditional_forecast(self, initial_state: Dict[str, float],
                                     conditions: Dict[str, np.ndarray],
                                     periods: int = 20, n_simulations: int = 100,
                                     variables: Optional[List[str]] = None,
                                     shock_scale: float = 1.0) -> xr.Dataset:
        """Generate conditional forecasts from the model.
        
        Args:
            initial_state (Dict[str, float]): Initial state of the model
            conditions (Dict[str, np.ndarray]): Conditions for the forecast
                Keys are variable names, values are arrays of length periods
            periods (int, optional): Number of periods to forecast. Defaults to 20.
            n_simulations (int, optional): Number of simulations to run. Defaults to 100.
            variables (List[str], optional): Variables to include in the forecast.
                Defaults to None (all variables).
            shock_scale (float, optional): Scale factor for shock standard deviations.
                Defaults to 1.0.
                
        Returns:
            xr.Dataset: Dataset containing the forecasts
        """
        if not self.model.solved:
            self.model.solve()
            
        # Get variables to include
        if variables is None:
            variables = self.model.variables
        else:
            for var in variables:
                if var not in self.model.variables:
                    raise ValueError(f"Variable {var} not found in model")
        
        # Get variable indices
        var_indices = [self.model.variables.index(var) for var in variables]
        
        # Get solution matrices
        T = self.model.solution['T']
        R = self.model.solution['R']
        
        # Get shock standard deviations
        shock_stds = np.array([self.model.parameters.get(f"sigma_{shock}", {}).get('value', 1.0) 
                              for shock in self.model.shocks])
        
        # Initialize forecasts
        forecasts = np.zeros((n_simulations, periods, len(variables)))
        
        # Convert initial state to vector
        initial_vector = np.zeros(len(self.model.variables))
        for var, value in initial_state.items():
            if var in self.model.variables:
                idx = self.model.variables.index(var)
                initial_vector[idx] = value
                
        # Get conditioned variables and their indices
        conditioned_vars = list(conditions.keys())
        conditioned_indices = [self.model.variables.index(var) for var in conditioned_vars]
        
        # Check that conditions have the right length
        for var, values in conditions.items():
            if len(values) != periods:
                raise ValueError(f"Condition for {var} has length {len(values)}, expected {periods}")
                
        # Generate conditional forecasts
        for i in range(n_simulations):
            # Initialize state
            state = initial_vector.copy()
            
            # Generate random shocks
            rng = np.random.default_rng(seed=i)
            shocks = rng.normal(0, 1, (periods, len(self.model.shocks))) * shock_stds * shock_scale
            
            # Simulate the model
            for t in range(periods):
                # Update state
                state = T @ state + R @ shocks[t, :]
                
                # Apply conditions
                for j, var in enumerate(conditioned_vars):
                    state[conditioned_indices[j]] = conditions[var][t]
                
                # Store results
                forecasts[i, t, :] = state[var_indices]
                
        # Create xarray dataset
        ds = xr.Dataset(
            data_vars={var: (('simulation', 'time'), forecasts[:, :, i]) 
                      for i, var in enumerate(variables)},
            coords={'simulation': np.arange(n_simulations), 'time': np.arange(periods)}
        )
        
        # Add metadata
        ds.attrs['model'] = self.model.name
        ds.attrs['shock_scale'] = shock_scale
        ds.attrs['conditional'] = True
        ds.attrs['conditioned_vars'] = conditioned_vars
        
        return ds
        
    def compute_forecast_statistics(self, forecast: xr.Dataset) -> xr.Dataset:
        """Compute statistics for a forecast.
        
        Args:
            forecast (xr.Dataset): Dataset containing the forecasts
                
        Returns:
            xr.Dataset: Dataset containing the forecast statistics
        """
        # Initialize statistics
        stats_ds = xr.Dataset(coords={'time': forecast.time})
        
        # Compute statistics for each variable
        for var in forecast.data_vars:
            # Get forecasts for this variable
            var_forecast = forecast[var]
            
            # Compute mean
            stats_ds[f"{var}_mean"] = var_forecast.mean(dim='simulation')
            
            # Compute median
            stats_ds[f"{var}_median"] = var_forecast.median(dim='simulation')
            
            # Compute standard deviation
            stats_ds[f"{var}_std"] = var_forecast.std(dim='simulation')
            
            # Compute quantiles
            for q in [0.05, 0.1, 0.25, 0.75, 0.9, 0.95]:
                stats_ds[f"{var}_q{int(q*100)}"] = var_forecast.quantile(q, dim='simulation')
                
        # Add metadata
        stats_ds.attrs = forecast.attrs.copy()
        
        return stats_ds
        
    def plot_forecast(self, forecast: xr.Dataset, variable: str,
                     figsize: Tuple[int, int] = (10, 6),
                     title: Optional[str] = None,
                     show_intervals: bool = True,
                     interval_alpha: float = 0.3,
                     history: Optional[pd.DataFrame] = None,
                     history_var: Optional[str] = None,
                     history_periods: int = 20) -> plt.Figure:
        """Plot a forecast for a variable.
        
        Args:
            forecast (xr.Dataset): Dataset containing the forecasts
            variable (str): Variable to plot
            figsize (Tuple[int, int], optional): Figure size. Defaults to (10, 6).
            title (str, optional): Title for the plot. Defaults to None.
            show_intervals (bool, optional): Whether to show prediction intervals.
                Defaults to True.
            interval_alpha (float, optional): Alpha for prediction intervals.
                Defaults to 0.3.
            history (pd.DataFrame, optional): Historical data. Defaults to None.
            history_var (str, optional): Variable name in historical data.
                Defaults to None (same as variable).
            history_periods (int, optional): Number of historical periods to show.
                Defaults to 20.
                
        Returns:
            plt.Figure: Figure object
        """
        # Check if variable exists in forecast
        if variable not in forecast.data_vars:
            raise ValueError(f"Variable {variable} not found in forecast dataset")
            
        # Compute forecast statistics
        stats = self.compute_forecast_statistics(forecast)
        
        # Create figure
        fig, ax = plt.subplots(figsize=figsize)
        
        # Plot mean forecast
        ax.plot(stats.time, stats[f"{variable}_mean"], color='blue', linewidth=2, label='Mean Forecast')
        
        # Plot median forecast
        ax.plot(stats.time, stats[f"{variable}_median"], color='green', linewidth=2, 
               linestyle='--', label='Median Forecast')
        
        # Plot prediction intervals
        if show_intervals:
            # 50% interval
            ax.fill_between(stats.time, stats[f"{variable}_q25"], stats[f"{variable}_q75"],
                           color='blue', alpha=interval_alpha, label='50% Interval')
            
            # 80% interval
            ax.fill_between(stats.time, stats[f"{variable}_q10"], stats[f"{variable}_q90"],
                           color='blue', alpha=interval_alpha/2, label='80% Interval')
            
            # 90% interval
            ax.fill_between(stats.time, stats[f"{variable}_q5"], stats[f"{variable}_q95"],
                           color='blue', alpha=interval_alpha/3, label='90% Interval')
            
        # Plot historical data if provided
        if history is not None:
            if history_var is None:
                history_var = variable
                
            if history_var in history.columns:
                # Get historical data
                hist_data = history[history_var].values
                
                # Get time index for historical data
                if history_periods > len(hist_data):
                    history_periods = len(hist_data)
                    
                hist_time = np.arange(-history_periods, 0)
                hist_data = hist_data[-history_periods:]
                
                # Plot historical data
                ax.plot(hist_time, hist_data, color='black', linewidth=2, label='Historical')
                
                # Add vertical line at t=0
                ax.axvline(x=0, color='red', linestyle='--', alpha=0.5)
                
        # Add labels and legend
        ax.set_xlabel('Time')
        ax.set_ylabel(variable)
        ax.legend(loc='best')
        
        # Add title
        if title is None:
            title = f"Forecast: {variable}"
            
        ax.set_title(title)
        
        # Adjust layout
        fig.tight_layout()
        
        return fig
        
    def plot_all_forecasts(self, forecast: xr.Dataset, 
                          variables: Optional[List[str]] = None,
                          figsize: Tuple[int, int] = (15, 10),
                          ncols: int = 2,
                          show_intervals: bool = True,
                          interval_alpha: float = 0.3,
                          history: Optional[pd.DataFrame] = None,
                          history_vars: Optional[Dict[str, str]] = None,
                          history_periods: int = 20) -> plt.Figure:
        """Plot forecasts for multiple variables.
        
        Args:
            forecast (xr.Dataset): Dataset containing the forecasts
            variables (List[str], optional): Variables to plot. Defaults to None (all variables).
            figsize (Tuple[int, int], optional): Figure size. Defaults to (15, 10).
            ncols (int, optional): Number of columns in the plot grid. Defaults to 2.
            show_intervals (bool, optional): Whether to show prediction intervals.
                Defaults to True.
            interval_alpha (float, optional): Alpha for prediction intervals.
                Defaults to 0.3.
            history (pd.DataFrame, optional): Historical data. Defaults to None.
            history_vars (Dict[str, str], optional): Mapping from model variables to
                historical data columns. Defaults to None (same names).
            history_periods (int, optional): Number of historical periods to show.
                Defaults to 20.
                
        Returns:
            plt.Figure: Figure object
        """
        # Get variables to plot
        if variables is None:
            variables = list(forecast.data_vars)
            
        # Compute forecast statistics
        stats = self.compute_forecast_statistics(forecast)
        
        # Create mapping from model variables to historical data columns
        if history_vars is None and history is not None:
            history_vars = {var: var for var in variables if var in history.columns}
            
        # Compute number of rows and columns
        n_vars = len(variables)
        ncols = min
(Content truncated due to size limit. Use line ranges to read in chunks)