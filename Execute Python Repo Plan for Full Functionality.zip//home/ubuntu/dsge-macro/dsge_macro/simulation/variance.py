"""
Variance decomposition tools for DSGE models.

This module provides utilities for computing and visualizing variance
decompositions of macroeconomic variables in DSGE models.
"""

import numpy as np
import jax
import jax.numpy as jnp
from typing import Dict, List, Tuple, Optional, Union, Callable
import pandas as pd
import xarray as xr
import matplotlib.pyplot as plt

from dsge_macro.core.model import DSGEModel


class VarianceDecomposition:
    """Variance decomposition for DSGE models.
    
    This class provides methods for computing and visualizing variance
    decompositions of macroeconomic variables in DSGE models.
    
    Attributes:
        model (DSGEModel): DSGE model
    """
    
    def __init__(self, model: DSGEModel):
        """Initialize a variance decomposition.
        
        Args:
            model (DSGEModel): DSGE model
        """
        self.model = model
        
    def compute_unconditional_variance(self) -> xr.DataArray:
        """Compute the unconditional variance decomposition.
        
        Returns:
            xr.DataArray: DataArray containing the variance decomposition
        """
        if not self.model.solved:
            self.model.solve()
            
        # Get state space representation
        state_space = self.model.get_state_space_representation()
        
        # Extract state space matrices
        A = state_space['A']  # State transition matrix
        B = state_space['B']  # Shock impact matrix
        
        # Number of variables and shocks
        n_vars = len(self.model.variables)
        n_shocks = len(self.model.shocks)
        
        # Initialize variance decomposition
        variance_decomp = np.zeros((n_vars, n_shocks))
        
        # Compute unconditional variance
        # This is a placeholder for the actual computation
        # In a real implementation, we would solve the Lyapunov equation
        # V = A @ V @ A.T + B @ Sigma @ B.T
        # where Sigma is the covariance matrix of the shocks
        
        # For now, we'll use a simple approximation
        # Simulate the model for a long time and compute the variance
        # of each variable due to each shock
        
        # Simulate the model for each shock separately
        T = 1000  # Number of periods
        burn_in = 200  # Burn-in periods
        
        for j in range(n_shocks):
            # Create shock series with only this shock active
            shocks = np.zeros((T, n_shocks))
            shocks[:, j] = np.random.normal(0, 1, T)
            
            # Simulate the model
            state = np.zeros(n_vars)
            states = np.zeros((T, n_vars))
            
            for t in range(T):
                state = A @ state + B @ shocks[t, :]
                states[t, :] = state
                
            # Compute variance (excluding burn-in)
            for i in range(n_vars):
                variance_decomp[i, j] = np.var(states[burn_in:, i])
                
        # Normalize by total variance
        total_variance = np.sum(variance_decomp, axis=1, keepdims=True)
        variance_decomp = variance_decomp / total_variance
        
        # Create xarray DataArray
        da = xr.DataArray(
            data=variance_decomp,
            dims=['variable', 'shock'],
            coords={'variable': self.model.variables, 'shock': self.model.shocks}
        )
        
        # Add metadata
        da.attrs['model'] = self.model.name
        da.attrs['type'] = 'unconditional'
        
        return da
        
    def compute_forecast_variance(self, horizons: List[int]) -> xr.DataArray:
        """Compute the forecast error variance decomposition.
        
        Args:
            horizons (List[int]): Forecast horizons
            
        Returns:
            xr.DataArray: DataArray containing the variance decomposition
        """
        if not self.model.solved:
            self.model.solve()
            
        # Get state space representation
        state_space = self.model.get_state_space_representation()
        
        # Extract state space matrices
        A = state_space['A']  # State transition matrix
        B = state_space['B']  # Shock impact matrix
        
        # Number of variables, shocks, and horizons
        n_vars = len(self.model.variables)
        n_shocks = len(self.model.shocks)
        n_horizons = len(horizons)
        
        # Initialize variance decomposition
        variance_decomp = np.zeros((n_vars, n_shocks, n_horizons))
        
        # Compute forecast error variance decomposition
        for h_idx, h in enumerate(horizons):
            # Compute impulse responses up to horizon h
            irf = np.zeros((h+1, n_vars, n_shocks))
            
            # Initial impact
            irf[0, :, :] = B
            
            # Propagate the shocks
            for t in range(1, h+1):
                for j in range(n_shocks):
                    irf[t, :, j] = A @ irf[t-1, :, j]
                    
            # Compute variance decomposition
            for i in range(n_vars):
                # Compute total forecast error variance
                total_var = 0
                for j in range(n_shocks):
                    # Get shock standard deviation
                    shock_std = self.model.parameters.get(f"sigma_{self.model.shocks[j]}", {}).get('value', 1.0)
                    
                    # Compute contribution to variance
                    shock_var = np.sum(irf[:, i, j] ** 2) * (shock_std ** 2)
                    variance_decomp[i, j, h_idx] = shock_var
                    total_var += shock_var
                    
                # Normalize by total variance
                if total_var > 0:
                    variance_decomp[i, :, h_idx] /= total_var
                    
        # Create xarray DataArray
        da = xr.DataArray(
            data=variance_decomp,
            dims=['variable', 'shock', 'horizon'],
            coords={'variable': self.model.variables, 'shock': self.model.shocks, 'horizon': horizons}
        )
        
        # Add metadata
        da.attrs['model'] = self.model.name
        da.attrs['type'] = 'forecast'
        
        return da
        
    def plot_unconditional_variance(self, variance_decomp: xr.DataArray,
                                   variables: Optional[List[str]] = None,
                                   figsize: Tuple[int, int] = (10, 6),
                                   title: Optional[str] = None) -> plt.Figure:
        """Plot the unconditional variance decomposition.
        
        Args:
            variance_decomp (xr.DataArray): DataArray containing the variance decomposition
            variables (List[str], optional): Variables to plot. Defaults to None (all variables).
            figsize (Tuple[int, int], optional): Figure size. Defaults to (10, 6).
            title (str, optional): Title for the plot. Defaults to None.
                
        Returns:
            plt.Figure: Figure object
        """
        # Check if this is an unconditional variance decomposition
        if variance_decomp.attrs.get('type') != 'unconditional':
            raise ValueError("This is not an unconditional variance decomposition")
            
        # Get variables to plot
        if variables is None:
            variables = variance_decomp.variable.values
        else:
            for var in variables:
                if var not in variance_decomp.variable.values:
                    raise ValueError(f"Variable {var} not found in variance decomposition")
                    
        # Get shocks
        shocks = variance_decomp.shock.values
        
        # Create figure
        fig, ax = plt.subplots(figsize=figsize)
        
        # Create stacked bar plot
        bottom = np.zeros(len(variables))
        
        for shock in shocks:
            values = [variance_decomp.sel(variable=var, shock=shock).values for var in variables]
            ax.bar(variables, values, bottom=bottom, label=shock)
            bottom += values
            
        # Add labels and legend
        ax.set_xlabel('Variable')
        ax.set_ylabel('Variance Contribution')
        ax.legend(loc='best')
        
        # Add title
        if title is None:
            title = "Unconditional Variance Decomposition"
            
        ax.set_title(title)
        
        # Adjust layout
        fig.tight_layout()
        
        return fig
        
    def plot_forecast_variance(self, variance_decomp: xr.DataArray,
                              variable: str, horizons: Optional[List[int]] = None,
                              figsize: Tuple[int, int] = (10, 6),
                              title: Optional[str] = None) -> plt.Figure:
        """Plot the forecast error variance decomposition for a variable.
        
        Args:
            variance_decomp (xr.DataArray): DataArray containing the variance decomposition
            variable (str): Variable to plot
            horizons (List[int], optional): Horizons to plot. Defaults to None (all horizons).
            figsize (Tuple[int, int], optional): Figure size. Defaults to (10, 6).
            title (str, optional): Title for the plot. Defaults to None.
                
        Returns:
            plt.Figure: Figure object
        """
        # Check if this is a forecast variance decomposition
        if variance_decomp.attrs.get('type') != 'forecast':
            raise ValueError("This is not a forecast error variance decomposition")
            
        # Check if variable exists
        if variable not in variance_decomp.variable.values:
            raise ValueError(f"Variable {variable} not found in variance decomposition")
            
        # Get horizons to plot
        if horizons is None:
            horizons = variance_decomp.horizon.values
        else:
            for h in horizons:
                if h not in variance_decomp.horizon.values:
                    raise ValueError(f"Horizon {h} not found in variance decomposition")
                    
        # Get shocks
        shocks = variance_decomp.shock.values
        
        # Create figure
        fig, ax = plt.subplots(figsize=figsize)
        
        # Create stacked area plot
        x = horizons
        bottom = np.zeros(len(horizons))
        
        for shock in shocks:
            y = [variance_decomp.sel(variable=variable, shock=shock, horizon=h).values for h in horizons]
            ax.fill_between(x, bottom, bottom + y, label=shock)
            bottom += y
            
        # Add labels and legend
        ax.set_xlabel('Horizon')
        ax.set_ylabel('Variance Contribution')
        ax.legend(loc='best')
        
        # Add title
        if title is None:
            title = f"Forecast Error Variance Decomposition: {variable}"
            
        ax.set_title(title)
        
        # Adjust layout
        fig.tight_layout()
        
        return fig
        
    def plot_all_forecast_variances(self, variance_decomp: xr.DataArray,
                                   variables: Optional[List[str]] = None,
                                   horizons: Optional[List[int]] = None,
                                   figsize: Tuple[int, int] = (15, 10),
                                   ncols: int = 2,
                                   title: Optional[str] = None) -> plt.Figure:
        """Plot the forecast error variance decomposition for multiple variables.
        
        Args:
            variance_decomp (xr.DataArray): DataArray containing the variance decomposition
            variables (List[str], optional): Variables to plot. Defaults to None (all variables).
            horizons (List[int], optional): Horizons to plot. Defaults to None (all horizons).
            figsize (Tuple[int, int], optional): Figure size. Defaults to (15, 10).
            ncols (int, optional): Number of columns in the plot grid. Defaults to 2.
            title (str, optional): Title for the plot. Defaults to None.
                
        Returns:
            plt.Figure: Figure object
        """
        # Check if this is a forecast variance decomposition
        if variance_decomp.attrs.get('type') != 'forecast':
            raise ValueError("This is not a forecast error variance decomposition")
            
        # Get variables to plot
        if variables is None:
            variables = variance_decomp.variable.values
        else:
            for var in variables:
                if var not in variance_decomp.variable.values:
                    raise ValueError(f"Variable {var} not found in variance decomposition")
                    
        # Get horizons to plot
        if horizons is None:
            horizons = variance_decomp.horizon.values
        else:
            for h in horizons:
                if h not in variance_decomp.horizon.values:
                    raise ValueError(f"Horizon {h} not found in variance decomposition")
                    
        # Get shocks
        shocks = variance_decomp.shock.values
        
        # Compute number of rows and columns
        n_vars = len(variables)
        ncols = min(ncols, n_vars)
        nrows = (n_vars + ncols - 1) // ncols
        
        # Create figure
        fig, axes = plt.subplots(nrows, ncols, figsize=figsize, squeeze=False)
        
        # Plot decompositions
        for i, var in enumerate(variables):
            row = i // ncols
            col = i % ncols
            ax = axes[row, col]
            
            # Create stacked area plot
            x = horizons
            bottom = np.zeros(len(horizons))
            
            for shock in shocks:
                y = [variance_decomp.sel(variable=var, shock=shock, horizon=h).values for h in horizons]
                ax.fill_between(x, bottom, bottom + y, label=shock if i == 0 else None)
                bottom += y
                
            # Add labels
            ax.set_xlabel('Horizon')
            ax.set_ylabel('Variance Contribution')
            ax.set_title(var)
            
        # Add legend to figure
        handles, labels = axes[0, 0].get_legend_handles_labels()
        fig.legend(handles, labels, loc='upper center', bbox_to_anchor=(0.5, 0.05), 
                  ncol=min(len(shocks), 5))
        
        # Add overall title
        if title is None:
            title = "Forecast Error Variance Decomposition"
            
        fig.suptitle(title, fontsize=14)
        
        # Adjust layout
        fig.tight_layout(rect=[0, 0.1, 1, 0.95])
        
        # Remove empty subplots
        for i in range(n_vars, nrows * ncols):
            row = i // ncols
            col = i % ncols
            fig.delaxes(axes[row, col])
            
        return fig
