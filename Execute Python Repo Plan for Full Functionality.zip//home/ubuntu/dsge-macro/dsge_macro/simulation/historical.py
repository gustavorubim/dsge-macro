"""
Historical decomposition tools for DSGE models.

This module provides utilities for computing and visualizing historical
decompositions of macroeconomic variables in DSGE models.
"""

import numpy as np
import jax
import jax.numpy as jnp
from typing import Dict, List, Tuple, Optional, Union, Callable
import pandas as pd
import xarray as xr
import matplotlib.pyplot as plt

from dsge_macro.core.model import DSGEModel


class HistoricalDecomposition:
    """Historical decomposition for DSGE models.
    
    This class provides methods for computing and visualizing historical
    decompositions of macroeconomic variables in DSGE models.
    
    Attributes:
        model (DSGEModel): DSGE model
    """
    
    def __init__(self, model: DSGEModel):
        """Initialize a historical decomposition.
        
        Args:
            model (DSGEModel): DSGE model
        """
        self.model = model
        
    def compute_decomposition(self, data: Union[pd.DataFrame, xr.Dataset],
                             variable_mapping: Optional[Dict[str, str]] = None) -> xr.Dataset:
        """Compute historical decomposition.
        
        Args:
            data (Union[pd.DataFrame, xr.Dataset]): Data for decomposition
            variable_mapping (Dict[str, str], optional): Mapping from model variables
                to data columns. Defaults to None (use same names).
                
        Returns:
            xr.Dataset: Dataset containing the historical decomposition
        """
        if not self.model.solved:
            self.model.solve()
            
        # Convert xarray Dataset to pandas DataFrame if necessary
        if isinstance(data, xr.Dataset):
            data_df = data.to_dataframe().reset_index()
        else:
            data_df = data.copy()
            
        # Create variable mapping if not provided
        if variable_mapping is None:
            variable_mapping = {var: var for var in self.model.variables}
            
        # Get observed variables
        observed_vars = [var for var in variable_mapping.keys() if variable_mapping[var] in data_df.columns]
        
        # Get observed data
        observed_data = data_df[[variable_mapping[var] for var in observed_vars]].values
        
        # Get state space representation
        state_space = self.model.get_state_space_representation()
        
        # Extract state space matrices
        A = state_space['A']  # State transition matrix
        B = state_space['B']  # Shock impact matrix
        
        # Number of periods, variables, and shocks
        T, n_obs = observed_data.shape
        n_vars = len(self.model.variables)
        n_shocks = len(self.model.shocks)
        
        # Initialize decomposition
        decomposition = np.zeros((T, n_vars, n_shocks + 1))  # +1 for initial conditions
        
        # Compute smoothed states and shocks
        # This is a placeholder for the actual Kalman smoother implementation
        # In a real implementation, we would use a proper Kalman smoother
        smoothed_states = np.zeros((T, n_vars))
        smoothed_shocks = np.zeros((T, n_shocks))
        
        # Compute historical decomposition
        # Initialize with initial conditions
        decomposition[0, :, -1] = smoothed_states[0, :]
        
        # Compute contribution of each shock
        for t in range(1, T):
            # Contribution of initial conditions
            decomposition[t, :, -1] = A @ decomposition[t-1, :, -1]
            
            # Contribution of each shock
            for j in range(n_shocks):
                # Propagate previous contributions
                decomposition[t, :, j] = A @ decomposition[t-1, :, j]
                
                # Add new contribution
                if t < T:
                    decomposition[t, :, j] += B[:, j] * smoothed_shocks[t, j]
        
        # Create xarray dataset
        coords = {
            'time': np.arange(T),
            'variable': self.model.variables,
            'component': self.model.shocks + ['initial']
        }
        
        ds = xr.Dataset(
            data_vars={'decomposition': (('time', 'variable', 'component'), decomposition)},
            coords=coords
        )
        
        # Add metadata
        ds.attrs['model'] = self.model.name
        
        return ds
        
    def plot_decomposition(self, decomposition: xr.Dataset, variable: str,
                          figsize: Tuple[int, int] = (12, 6),
                          title: Optional[str] = None,
                          stacked: bool = True) -> plt.Figure:
        """Plot historical decomposition for a variable.
        
        Args:
            decomposition (xr.Dataset): Dataset containing the historical decomposition
            variable (str): Variable to plot
            figsize (Tuple[int, int], optional): Figure size. Defaults to (12, 6).
            title (str, optional): Title for the plot. Defaults to None.
            stacked (bool, optional): Whether to create a stacked bar plot. Defaults to True.
                
        Returns:
            plt.Figure: Figure object
        """
        # Check if variable exists in decomposition
        if variable not in decomposition.variable.values:
            raise ValueError(f"Variable {variable} not found in decomposition dataset")
            
        # Get variable index
        var_idx = np.where(decomposition.variable.values == variable)[0][0]
        
        # Get decomposition for this variable
        var_decomp = decomposition.decomposition.sel(variable=variable)
        
        # Create figure
        fig, ax = plt.subplots(figsize=figsize)
        
        # Get components
        components = decomposition.component.values
        
        if stacked:
            # Create stacked bar plot
            bottom = np.zeros(len(decomposition.time))
            
            for comp in components:
                values = var_decomp.sel(component=comp).values
                ax.bar(decomposition.time, values, bottom=bottom, label=comp)
                bottom += values
                
            # Add total line
            ax.plot(decomposition.time, var_decomp.sum(dim='component'), 
                   color='black', linewidth=2, label='Total')
        else:
            # Create line plot for each component
            for comp in components:
                values = var_decomp.sel(component=comp).values
                ax.plot(decomposition.time, values, linewidth=2, label=comp)
                
            # Add total line
            ax.plot(decomposition.time, var_decomp.sum(dim='component'), 
                   color='black', linewidth=3, label='Total')
            
        # Add horizontal line at zero
        ax.axhline(y=0, color='k', linestyle='-', alpha=0.2)
        
        # Add labels and legend
        ax.set_xlabel('Time')
        ax.set_ylabel('Contribution')
        ax.legend(loc='best')
        
        # Add title
        if title is None:
            title = f"Historical Decomposition: {variable}"
            
        ax.set_title(title)
        
        # Adjust layout
        fig.tight_layout()
        
        return fig
        
    def plot_all_decompositions(self, decomposition: xr.Dataset, 
                               variables: Optional[List[str]] = None,
                               figsize: Tuple[int, int] = (15, 10),
                               ncols: int = 2,
                               stacked: bool = True) -> plt.Figure:
        """Plot historical decomposition for multiple variables.
        
        Args:
            decomposition (xr.Dataset): Dataset containing the historical decomposition
            variables (List[str], optional): Variables to plot. Defaults to None (all variables).
            figsize (Tuple[int, int], optional): Figure size. Defaults to (15, 10).
            ncols (int, optional): Number of columns in the plot grid. Defaults to 2.
            stacked (bool, optional): Whether to create stacked bar plots. Defaults to True.
                
        Returns:
            plt.Figure: Figure object
        """
        # Get variables to plot
        if variables is None:
            variables = decomposition.variable.values
        else:
            for var in variables:
                if var not in decomposition.variable.values:
                    raise ValueError(f"Variable {var} not found in decomposition dataset")
                    
        # Compute number of rows and columns
        n_vars = len(variables)
        ncols = min(ncols, n_vars)
        nrows = (n_vars + ncols - 1) // ncols
        
        # Create figure
        fig, axes = plt.subplots(nrows, ncols, figsize=figsize, squeeze=False)
        
        # Get components
        components = decomposition.component.values
        
        # Plot decompositions
        for i, var in enumerate(variables):
            row = i // ncols
            col = i % ncols
            ax = axes[row, col]
            
            # Get decomposition for this variable
            var_decomp = decomposition.decomposition.sel(variable=var)
            
            if stacked:
                # Create stacked bar plot
                bottom = np.zeros(len(decomposition.time))
                
                for comp in components:
                    values = var_decomp.sel(component=comp).values
                    ax.bar(decomposition.time, values, bottom=bottom, label=comp if i == 0 else None)
                    bottom += values
                    
                # Add total line
                ax.plot(decomposition.time, var_decomp.sum(dim='component'), 
                       color='black', linewidth=2, label='Total' if i == 0 else None)
            else:
                # Create line plot for each component
                for comp in components:
                    values = var_decomp.sel(component=comp).values
                    ax.plot(decomposition.time, values, linewidth=2, label=comp if i == 0 else None)
                    
                # Add total line
                ax.plot(decomposition.time, var_decomp.sum(dim='component'), 
                       color='black', linewidth=3, label='Total' if i == 0 else None)
                
            # Add horizontal line at zero
            ax.axhline(y=0, color='k', linestyle='-', alpha=0.2)
            
            # Add labels
            ax.set_title(var)
            ax.set_xlabel('Time')
            ax.set_ylabel('Contribution')
            
        # Add legend to figure
        handles, labels = axes[0, 0].get_legend_handles_labels()
        fig.legend(handles, labels, loc='upper center', bbox_to_anchor=(0.5, 0.05), 
                  ncol=min(len(components) + 1, 5))
        
        # Add overall title
        fig.suptitle("Historical Decomposition", fontsize=14)
        
        # Adjust layout
        fig.tight_layout(rect=[0, 0.1, 1, 0.95])
        
        # Remove empty subplots
        for i in range(n_vars, nrows * ncols):
            row = i // ncols
            col = i % ncols
            fig.delaxes(axes[row, col])
            
        return fig
        
    def compute_variance_contribution(self, decomposition: xr.Dataset) -> xr.DataArray:
        """Compute the contribution of each shock to the variance of each variable.
        
        Args:
            decomposition (xr.Dataset): Dataset containing the historical decomposition
                
        Returns:
            xr.DataArray: DataArray containing the variance contributions
        """
        # Initialize variance contributions
        variables = decomposition.variable.values
        components = decomposition.component.values[:-1]  # Exclude initial conditions
        
        variance_contrib = np.zeros((len(variables), len(components)))
        
        # Compute variance contribution for each variable and shock
        for i, var in enumerate(variables):
            # Get decomposition for this variable
            var_decomp = decomposition.decomposition.sel(variable=var)
            
            # Compute total variance (excluding initial conditions)
            total_var = var_decomp.sel(component=components).sum(dim='component').var(dim='time')
            
            # Compute contribution of each shock
            for j, comp in enumerate(components):
                shock_contrib = var_decomp.sel(component=comp).values
                variance_contrib[i, j] = np.var(shock_contrib) / total_var
                
        # Create xarray DataArray
        da = xr.DataArray(
            data=variance_contrib,
            dims=['variable', 'component'],
            coords={'variable': variables, 'component': components}
        )
        
        return da
        
    def plot_variance_contribution(self, variance_contrib: xr.DataArray,
                                  variables: Optional[List[str]] = None,
                                  figsize: Tuple[int, int] = (10, 6),
                                  title: Optional[str] = None) -> plt.Figure:
        """Plot the contribution of each shock to the variance of each variable.
        
        Args:
            variance_contrib (xr.DataArray): DataArray containing the variance contributions
            variables (List[str], optional): Variables to plot. Defaults to None (all variables).
            figsize (Tuple[int, int], optional): Figure size. Defaults to (10, 6).
            title (str, optional): Title for the plot. Defaults to None.
                
        Returns:
            plt.Figure: Figure object
        """
        # Get variables to plot
        if variables is None:
            variables = variance_contrib.variable.values
        else:
            for var in variables:
                if var not in variance_contrib.variable.values:
                    raise ValueError(f"Variable {var} not found in variance contribution dataset")
                    
        # Get components
        components = variance_contrib.component.values
        
        # Create figure
        fig, ax = plt.subplots(figsize=figsize)
        
        # Create stacked bar plot
        bottom = np.zeros(len(variables))
        
        for comp in components:
            values = [variance_contrib.sel(variable=var, component=comp).values for var in variables]
            ax.bar(variables, values, bottom=bottom, label=comp)
            bottom += values
            
        # Add labels and legend
        ax.set_xlabel('Variable')
        ax.set_ylabel('Variance Contribution')
        ax.legend(loc='best')
        
        # Add title
        if title is None:
            title = "Variance Decomposition"
            
        ax.set_title(title)
        
        # Adjust layout
        fig.tight_layout()
        
        return fig
