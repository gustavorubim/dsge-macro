"""
Data download and preparation utilities for DSGE models.

This module provides functions for downloading and preparing US macroeconomic
data for use with DSGE models.
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from typing import Dict, List, Tuple, Optional, Union
from datetime import datetime
import statsmodels.api as sm

# Add path for data API access
sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient


def download_us_macro_data(start_year: int = 1960, 
                          end_year: int = 2023,
                          save_path: Optional[str] = None) -> pd.DataFrame:
    """Download US macroeconomic data from DataBank API.
    
    Args:
        start_year (int, optional): Start year for data. Defaults to 1960.
        end_year (int, optional): End year for data. Defaults to 2023.
        save_path (str, optional): Path to save the data. Defaults to None.
        
    Returns:
        pd.DataFrame: DataFrame containing US macroeconomic data
    """
    # Initialize API client
    client = ApiClient()
    
    # Define indicators to download
    indicators = {
        # GDP and components
        "NY.GDP.MKTP.KN": "gdp_real",                  # Real GDP
        "NE.CON.PRVT.KN": "consumption_real",          # Real private consumption
        "NE.GDI.FTOT.KN": "investment_real",           # Real gross fixed capital formation
        "NE.CON.GOVT.KN": "government_real",           # Real government consumption
        
        # Prices and inflation
        "FP.CPI.TOTL": "cpi",                          # Consumer price index
        "NY.GDP.DEFL": "gdp_deflator",                 # GDP deflator
        
        # Labor market
        "SL.TLF.TOTL.IN": "labor_force",               # Total labor force
        "SL.EMP.TOTL": "employment",                   # Total employment
        "SL.UEM.TOTL.ZS": "unemployment_rate",         # Unemployment rate
        
        # Monetary indicators
        "FR.INR.RINR": "real_interest_rate",           # Real interest rate
        "FR.INR.LEND": "lending_rate",                 # Lending interest rate
        "FM.LBL.BMNY.CN": "broad_money",               # Broad money
        
        # External sector
        "BN.CAB.XOKA.GD.ZS": "current_account",        # Current account balance (% of GDP)
        "NE.EXP.GNFS.KD": "exports_real",              # Exports of goods and services (constant)
        "NE.IMP.GNFS.KD": "imports_real",              # Imports of goods and services (constant)
        
        # Government
        "GC.DOD.TOTL.GD.ZS": "government_debt",        # Government debt (% of GDP)
        "GC.REV.XGRT.GD.ZS": "government_revenue",     # Government revenue (% of GDP)
        "GC.XPN.TOTL.GD.ZS": "government_expenditure", # Government expenditure (% of GDP)
    }
    
    # Initialize data dictionary
    data_dict = {}
    
    # Download data for each indicator
    print("Downloading US macroeconomic data...")
    for indicator_code, indicator_name in indicators.items():
        try:
            # Call API to get indicator data for US
            result = client.call_api('DataBank/indicator_data', 
                                    query={'indicator': indicator_code, 'country': 'USA'})
            
            # Extract data
            if result and 'data' in result:
                # Convert data to series
                years = []
                values = []
                for year, value in result['data'].items():
                    if value is not None and int(year) >= start_year and int(year) <= end_year:
                        years.append(int(year))
                        values.append(value)
                
                if years and values:
                    # Create series
                    series = pd.Series(values, index=years, name=indicator_name)
                    data_dict[indicator_name] = series
                    print(f"Downloaded {indicator_name} data")
                else:
                    print(f"No data available for {indicator_name}")
            else:
                print(f"Failed to download {indicator_name} data")
        except Exception as e:
            print(f"Error downloading {indicator_name}: {str(e)}")
    
    # Combine all series into a DataFrame
    if data_dict:
        data = pd.DataFrame(data_dict)
        
        # Save data if path is provided
        if save_path:
            data.to_csv(save_path)
            print(f"Data saved to {save_path}")
        
        return data
    else:
        raise ValueError("Failed to download any data")


def download_us_financial_data(start_date: str = '2000-01-01',
                              end_date: str = None,
                              save_path: Optional[str] = None) -> pd.DataFrame:
    """Download US financial data from Yahoo Finance API.
    
    Args:
        start_date (str, optional): Start date for data. Defaults to '2000-01-01'.
        end_date (str, optional): End date for data. Defaults to current date.
        save_path (str, optional): Path to save the data. Defaults to None.
        
    Returns:
        pd.DataFrame: DataFrame containing US financial data
    """
    # Initialize API client
    client = ApiClient()
    
    # Set end date to current date if not provided
    if end_date is None:
        end_date = datetime.now().strftime('%Y-%m-%d')
    
    # Convert dates to epoch timestamps
    start_timestamp = int(datetime.strptime(start_date, '%Y-%m-%d').timestamp())
    end_timestamp = int(datetime.strptime(end_date, '%Y-%m-%d').timestamp())
    
    # Define financial indicators to download
    indicators = {
        "^GSPC": "sp500",                  # S&P 500
        "^TNX": "treasury_10y",            # 10-Year Treasury Yield
        "^FVX": "treasury_5y",             # 5-Year Treasury Yield
        "^IRX": "treasury_13w",            # 13-Week Treasury Bill
        "^VIX": "vix",                     # Volatility Index
        "^DJI": "dow_jones",               # Dow Jones Industrial Average
        "^IXIC": "nasdaq",                 # NASDAQ Composite
        "GC=F": "gold",                    # Gold Futures
        "CL=F": "oil",                     # Crude Oil Futures
    }
    
    # Initialize data dictionary
    financial_data = {}
    
    # Download data for each indicator
    print("Downloading US financial data...")
    for symbol, name in indicators.items():
        try:
            # Call API to get stock chart data
            result = client.call_api('YahooFinance/get_stock_chart', 
                                    query={
                                        'symbol': symbol,
                                        'region': 'US',
                                        'interval': '1mo',
                                        'period1': str(start_timestamp),
                                        'period2': str(end_timestamp),
                                        'includeAdjustedClose': 'true'
                                    })
            
            # Extract data
            if result and 'chart' in result and 'result' in result['chart'] and result['chart']['result']:
                chart_data = result['chart']['result'][0]
                
                # Get timestamps
                timestamps = chart_data.get('timestamp', [])
                
                # Get close prices
                close_prices = None
                if 'indicators' in chart_data and 'quote' in chart_data['indicators']:
                    quotes = chart_data['indicators']['quote']
                    if quotes and 'close' in quotes[0]:
                        close_prices = quotes[0]['close']
                
                if timestamps and close_prices and len(timestamps) == len(close_prices):
                    # Convert timestamps to dates
                    dates = [datetime.fromtimestamp(ts).strftime('%Y-%m-%d') for ts in timestamps]
                    
                    # Create series
                    series = pd.Series(close_prices, index=pd.to_datetime(dates), name=name)
                    financial_data[name] = series
                    print(f"Downloaded {name} data")
                else:
                    print(f"No data available for {name}")
            else:
                print(f"Failed to download {name} data")
        except Exception as e:
            print(f"Error downloading {name}: {str(e)}")
    
    # Combine all series into a DataFrame
    if financial_data:
        data = pd.DataFrame(financial_data)
        
        # Save data if path is provided
        if save_path:
            data.to_csv(save_path)
            print(f"Financial data saved to {save_path}")
        
        return data
    else:
        raise ValueError("Failed to download any financial data")


def transform_data_for_dsge(data: pd.DataFrame, 
                           output_freq: str = 'Q',
                           detrend_method: str = 'hp',
                           hp_lambda: float = 1600,
                           log_transform: bool = True,
                           save_path: Optional[str] = None) -> pd.DataFrame:
    """Transform macroeconomic data for use with DSGE models.
    
    Args:
        data (pd.DataFrame): Raw macroeconomic data
        output_freq (str, optional): Output frequency. Defaults to 'Q' (quarterly).
        detrend_method (str, optional): Detrending method. Defaults to 'hp'.
            Options: 'hp' (Hodrick-Prescott), 'linear', 'first_diff', 'pct_change'
        hp_lambda (float, optional): Lambda parameter for HP filter. Defaults to 1600.
        log_transform (bool, optional): Whether to log-transform data. Defaults to True.
        save_path (str, optional): Path to save the transformed data. Defaults to None.
        
    Returns:
        pd.DataFrame: DataFrame containing transformed data
    """
    # Check if data is annual and needs to be converted
    is_annual = isinstance(data.index[0], (int, np.integer))
    
    if is_annual:
        # Convert annual data to datetime index
        data.index = pd.to_datetime([f"{year}-01-01" for year in data.index])
    
    # Resample data to desired frequency if needed
    if output_freq != 'A':
        # Define aggregation methods for different variables
        agg_methods = {}
        for col in data.columns:
            if 'rate' in col or col.endswith('_ratio'):
                # Use mean for rates and ratios
                agg_methods[col] = 'mean'
            else:
                # Use last value for levels
                agg_methods[col] = 'last'
        
        # Resample data
        data = data.resample(output_freq).agg(agg_methods)
    
    # Apply log transformation if requested
    if log_transform:
        for col in data.columns:
            # Skip rates, ratios, and columns with negative values
            if ('rate' in col or col.endswith('_ratio') or 
                (data[col] <= 0).any()):
                continue
            
            # Apply log transformation
            data[col] = np.log(data[col])
    
    # Detrend data
    detrended_data = pd.DataFrame(index=data.index)
    
    for col in data.columns:
        # Skip columns with missing values
        if data[col].isna().any():
            print(f"Skipping {col} due to missing values")
            continue
        
        # Apply detrending method
        if detrend_method == 'hp':
            # Apply HP filter
            cycle, trend = sm.tsa.filters.hpfilter(data[col], lamb=hp_lambda)
            detrended_data[col] = cycle
        elif detrend_method == 'linear':
            # Apply linear detrending
            x = np.arange(len(data[col]))
            y = data[col].values
            mask = ~np.isnan(y)
            if np.sum(mask) > 1:  # Need at least 2 points for regression
                slope, intercept = np.polyfit(x[mask], y[mask], 1)
                trend = intercept + slope * x
                detrended_data[col] = y - trend
        elif detrend_method == 'first_diff':
            # Apply first differencing
            detrended_data[col] = data[col].diff()
        elif detrend_method == 'pct_change':
            # Apply percentage change
            detrended_data[col] = data[col].pct_change()
        else:
            raise ValueError(f"Unknown detrending method: {detrend_method}")
    
    # Drop rows with missing values (due to differencing or other transformations)
    detrended_data = detrended_data.dropna()
    
    # Save data if path is provided
    if save_path:
        detrended_data.to_csv(save_path)
        print(f"Transformed data saved to {save_path}")
    
    return detrended_data


def create_dsge_dataset(macro_data: pd.DataFrame, 
                       financial_data: Optional[pd.DataFrame] = None,
                       variable_mapping: Optional[Dict[str, str]] = None,
                       start_date: Optional[str] = None,
                       end_date: Optional[str] = None,
                       save_path: Optional[str] = None) -> pd.DataFrame:
    """Create a dataset for DSGE model estimation.
    
    Args:
        macro_data (pd.DataFrame): Macroeconomic data
        financial_data (pd.DataFrame, optional): Financial data. Defaults to None.
        variable_mapping (Dict[str, str], optional): Mapping from model variables
            to data columns. Defaults to None.
        start_date (str, optional): Start date for the dataset. Defaults to None.
        end_date (str, optional): End date for the dataset. Defaults to None.
        save_path (str, optional): Path to save the dataset. Defaults to None.
        
    Returns:
        pd.DataFrame: DataFrame containing the dataset for DSGE model estimation
    """
    # Create a copy of the macro data
    dsge_data = macro_data.copy()
    
    # Merge with financial data if provided
    if financial_data is not None:
        # Ensure both datasets have datetime index
        if not isinstance(dsge_data.index, pd.DatetimeIndex):
            dsge_data.index = pd.to_datetime(dsge_data.index)
        
        if not isinstance(financial_data.index, pd.DatetimeIndex):
            financial_data.index = pd.to_datetime(financial_data.index)
        
        # Resample financial data to match macro data frequency
        freq = pd.infer_freq(dsge_data.index)
        if freq:
            financial_data = financial_data.resample(freq).last()
        
        # Merge datasets
        dsge_data = dsge_data.join(financial_data, how='left')
    
    # Apply variable mapping if provided
    if variable_mapping:
        dsge_data = dsge_data.rename(columns=variable_mapping)
    
    # Filter by date range if provided
    if start_date or end_date:
        dsge_data = dsge_data.loc[start_date:end_date]
    
    # Save data if path is provided
    if save_path:
        dsge_data.to_csv(save_path)
        print(f"DSGE dataset saved to {save_path}")
    
    return dsge_data


def plot_data_overview(data: pd.DataFrame, 
                      figsize: Tuple[int, int] = (15, 10),
                      ncols: int = 3,
                      save_path: Optional[str] = None) -> plt.Figure:
    """Plot an overview of the data.
    
    Args:
        data (pd.DataFrame): Data to plot
        figsize (Tuple[int, int], optional): Figure size. Defaults to (15, 10).
        ncols (int, optional): Number of columns in the plot grid. Defaults to 3.
        save_path (str, optional): Path to save the plot. Defaults to None.
        
    Returns:
        plt.Figure: Figure object
    """
    # Get variables to plot
    variables = data.columns
    
    # Compute number of rows and columns
    n_vars = len(variables)
    ncols = min(ncols, n_vars)
    nrows = (n_vars + ncols - 1) // ncols
    
    # Create figure
    fig, axes = plt.subplots(nrows, ncols, figsize=figsize, squeeze=False)
    
    # Plot each variable
    for i, var in enumerate(variabl
(Content truncated due to size limit. Use line ranges to read in chunks)