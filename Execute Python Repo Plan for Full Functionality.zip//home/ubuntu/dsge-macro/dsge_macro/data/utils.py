"""
Data utilities for DSGE models.

This module provides utility functions for working with data in DSGE models.
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from typing import Dict, List, Tuple, Optional, Union
import statsmodels.api as sm
from statsmodels.tsa.stattools import acf, pacf
import seaborn as sns


def load_data(file_path: str) -> pd.DataFrame:
    """Load data from a file.
    
    Args:
        file_path (str): Path to the data file
        
    Returns:
        pd.DataFrame: Loaded data
    """
    # Check file extension
    _, ext = os.path.splitext(file_path)
    
    if ext.lower() == '.csv':
        # Load CSV file
        data = pd.read_csv(file_path, index_col=0)
    elif ext.lower() in ['.xls', '.xlsx']:
        # Load Excel file
        data = pd.read_excel(file_path, index_col=0)
    elif ext.lower() == '.pkl':
        # Load pickle file
        data = pd.read_pickle(file_path)
    else:
        raise ValueError(f"Unsupported file format: {ext}")
    
    # Convert index to datetime if it looks like dates
    if isinstance(data.index, pd.Index) and not isinstance(data.index, pd.DatetimeIndex):
        try:
            data.index = pd.to_datetime(data.index)
        except:
            pass
    
    return data


def save_data(data: pd.DataFrame, file_path: str) -> None:
    """Save data to a file.
    
    Args:
        data (pd.DataFrame): Data to save
        file_path (str): Path to save the data
    """
    # Create directory if it doesn't exist
    os.makedirs(os.path.dirname(os.path.abspath(file_path)), exist_ok=True)
    
    # Check file extension
    _, ext = os.path.splitext(file_path)
    
    if ext.lower() == '.csv':
        # Save as CSV file
        data.to_csv(file_path)
    elif ext.lower() in ['.xls', '.xlsx']:
        # Save as Excel file
        data.to_excel(file_path)
    elif ext.lower() == '.pkl':
        # Save as pickle file
        data.to_pickle(file_path)
    else:
        raise ValueError(f"Unsupported file format: {ext}")
    
    print(f"Data saved to {file_path}")


def create_data_summary(data: pd.DataFrame, save_path: Optional[str] = None) -> pd.DataFrame:
    """Create a summary of the data.
    
    Args:
        data (pd.DataFrame): Data to summarize
        save_path (str, optional): Path to save the summary. Defaults to None.
        
    Returns:
        pd.DataFrame: Summary of the data
    """
    # Create summary DataFrame
    summary = pd.DataFrame({
        'mean': data.mean(),
        'std': data.std(),
        'min': data.min(),
        'max': data.max(),
        'median': data.median(),
        'skew': data.skew(),
        'kurtosis': data.kurtosis(),
        'missing': data.isna().sum(),
        'missing_pct': data.isna().mean() * 100,
    })
    
    # Add first and last dates if index is DatetimeIndex
    if isinstance(data.index, pd.DatetimeIndex):
        summary['start_date'] = data.index.min()
        summary['end_date'] = data.index.max()
    
    # Save summary if path is provided
    if save_path:
        summary.to_csv(save_path)
        print(f"Summary saved to {save_path}")
    
    return summary


def plot_data_correlation_heatmap(data: pd.DataFrame, 
                                 figsize: Tuple[int, int] = (12, 10),
                                 save_path: Optional[str] = None) -> plt.Figure:
    """Plot a correlation heatmap of the data.
    
    Args:
        data (pd.DataFrame): Data to plot
        figsize (Tuple[int, int], optional): Figure size. Defaults to (12, 10).
        save_path (str, optional): Path to save the plot. Defaults to None.
        
    Returns:
        plt.Figure: Figure object
    """
    # Compute correlation matrix
    corr = data.corr()
    
    # Create figure
    fig, ax = plt.subplots(figsize=figsize)
    
    # Create heatmap
    sns.heatmap(corr, annot=True, cmap='coolwarm', center=0, linewidths=0.5, ax=ax)
    
    # Add labels
    ax.set_title('Correlation Heatmap')
    
    # Adjust layout
    fig.tight_layout()
    
    # Save figure if path is provided
    if save_path:
        fig.savefig(save_path)
        print(f"Plot saved to {save_path}")
    
    return fig


def plot_data_pairplot(data: pd.DataFrame, 
                      variables: Optional[List[str]] = None,
                      figsize: Tuple[int, int] = (15, 15),
                      save_path: Optional[str] = None) -> plt.Figure:
    """Plot a pairplot of the data.
    
    Args:
        data (pd.DataFrame): Data to plot
        variables (List[str], optional): Variables to plot. Defaults to None (all).
        figsize (Tuple[int, int], optional): Figure size. Defaults to (15, 15).
        save_path (str, optional): Path to save the plot. Defaults to None.
        
    Returns:
        plt.Figure: Figure object
    """
    # Get variables to plot
    if variables is None:
        # Limit to a reasonable number of variables
        if len(data.columns) > 6:
            print(f"Warning: Too many variables ({len(data.columns)}). Limiting to first 6.")
            variables = data.columns[:6]
        else:
            variables = data.columns
    
    # Create pairplot
    g = sns.pairplot(data[variables])
    
    # Adjust figure size
    g.fig.set_size_inches(figsize)
    
    # Save figure if path is provided
    if save_path:
        g.savefig(save_path)
        print(f"Plot saved to {save_path}")
    
    return g.fig


def plot_data_time_series(data: pd.DataFrame,
                         variables: Optional[List[str]] = None,
                         figsize: Tuple[int, int] = (15, 10),
                         ncols: int = 1,
                         save_path: Optional[str] = None) -> plt.Figure:
    """Plot time series of the data.
    
    Args:
        data (pd.DataFrame): Data to plot
        variables (List[str], optional): Variables to plot. Defaults to None (all).
        figsize (Tuple[int, int], optional): Figure size. Defaults to (15, 10).
        ncols (int, optional): Number of columns in the plot grid. Defaults to 1.
        save_path (str, optional): Path to save the plot. Defaults to None.
        
    Returns:
        plt.Figure: Figure object
    """
    # Get variables to plot
    if variables is None:
        variables = data.columns
    
    # Compute number of rows and columns
    n_vars = len(variables)
    ncols = min(ncols, n_vars)
    nrows = (n_vars + ncols - 1) // ncols
    
    # Create figure
    fig, axes = plt.subplots(nrows, ncols, figsize=figsize, squeeze=False)
    
    # Plot each variable
    for i, var in enumerate(variables):
        row = i // ncols
        col = i % ncols
        ax = axes[row, col]
        
        # Plot data
        ax.plot(data.index, data[var])
        
        # Add labels
        ax.set_title(var)
        ax.set_xlabel('Time')
        ax.set_ylabel('Value')
        
        # Rotate x-axis labels for better readability
        plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    # Remove empty subplots
    for i in range(n_vars, nrows * ncols):
        row = i // ncols
        col = i % ncols
        fig.delaxes(axes[row, col])
    
    # Adjust layout
    fig.tight_layout()
    
    # Save figure if path is provided
    if save_path:
        fig.savefig(save_path)
        print(f"Plot saved to {save_path}")
    
    return fig


def create_training_validation_split(data: pd.DataFrame,
                                    train_ratio: float = 0.8,
                                    shuffle: bool = False,
                                    random_state: Optional[int] = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Split data into training and validation sets.
    
    Args:
        data (pd.DataFrame): Data to split
        train_ratio (float, optional): Ratio of training data. Defaults to 0.8.
        shuffle (bool, optional): Whether to shuffle the data. Defaults to False.
        random_state (int, optional): Random state for shuffling. Defaults to None.
        
    Returns:
        Tuple[pd.DataFrame, pd.DataFrame]: Training and validation data
    """
    # Check if index is DatetimeIndex
    if isinstance(data.index, pd.DatetimeIndex) and not shuffle:
        # Split by date
        n = len(data)
        train_size = int(n * train_ratio)
        
        train_data = data.iloc[:train_size]
        val_data = data.iloc[train_size:]
    else:
        # Split randomly
        if shuffle:
            # Shuffle data
            data_shuffled = data.sample(frac=1, random_state=random_state)
        else:
            data_shuffled = data
        
        # Split data
        n = len(data_shuffled)
        train_size = int(n * train_ratio)
        
        train_data = data_shuffled.iloc[:train_size]
        val_data = data_shuffled.iloc[train_size:]
    
    return train_data, val_data


def create_lagged_features(data: pd.DataFrame,
                          lags: int = 1,
                          drop_na: bool = True) -> pd.DataFrame:
    """Create lagged features from data.
    
    Args:
        data (pd.DataFrame): Data to transform
        lags (int, optional): Number of lags. Defaults to 1.
        drop_na (bool, optional): Whether to drop rows with missing values. Defaults to True.
        
    Returns:
        pd.DataFrame: Data with lagged features
    """
    # Create a copy of the data
    lagged = data.copy()
    
    # Create lagged features
    for col in data.columns:
        for lag in range(1, lags + 1):
            lagged[f"{col}_lag{lag}"] = data[col].shift(lag)
    
    # Drop rows with missing values if requested
    if drop_na:
        lagged = lagged.dropna()
    
    return lagged


def create_rolling_features(data: pd.DataFrame,
                           window: int = 3,
                           functions: Optional[Dict[str, callable]] = None,
                           drop_na: bool = True) -> pd.DataFrame:
    """Create rolling window features from data.
    
    Args:
        data (pd.DataFrame): Data to transform
        window (int, optional): Window size. Defaults to 3.
        functions (Dict[str, callable], optional): Functions to apply to rolling window.
            Defaults to None (mean, std, min, max).
        drop_na (bool, optional): Whether to drop rows with missing values. Defaults to True.
        
    Returns:
        pd.DataFrame: Data with rolling window features
    """
    # Create a copy of the data
    rolling = data.copy()
    
    # Set default functions if not provided
    if functions is None:
        functions = {
            'mean': np.mean,
            'std': np.std,
            'min': np.min,
            'max': np.max
        }
    
    # Create rolling window features
    for col in data.columns:
        for func_name, func in functions.items():
            rolling[f"{col}_{func_name}{window}"] = data[col].rolling(window=window).apply(func)
    
    # Drop rows with missing values if requested
    if drop_na:
        rolling = rolling.dropna()
    
    return rolling


def create_expanding_features(data: pd.DataFrame,
                             min_periods: int = 1,
                             functions: Optional[Dict[str, callable]] = None,
                             drop_na: bool = True) -> pd.DataFrame:
    """Create expanding window features from data.
    
    Args:
        data (pd.DataFrame): Data to transform
        min_periods (int, optional): Minimum number of observations required.
            Defaults to 1.
        functions (Dict[str, callable], optional): Functions to apply to expanding window.
            Defaults to None (mean, std, min, max).
        drop_na (bool, optional): Whether to drop rows with missing values. Defaults to True.
        
    Returns:
        pd.DataFrame: Data with expanding window features
    """
    # Create a copy of the data
    expanding = data.copy()
    
    # Set default functions if not provided
    if functions is None:
        functions = {
            'mean': np.mean,
            'std': np.std,
            'min': np.min,
            'max': np.max
        }
    
    # Create expanding window features
    for col in data.columns:
        for func_name, func in functions.items():
            expanding[f"{col}_{func_name}_exp"] = data[col].expanding(min_periods=min_periods).apply(func)
    
    # Drop rows with missing values if requested
    if drop_na:
        expanding = expanding.dropna()
    
    return expanding


def interpolate_missing_values(data: pd.DataFrame,
                              method: str = 'linear',
                              limit: Optional[int] = None) -> pd.DataFrame:
    """Interpolate missing values in data.
    
    Args:
        data (pd.DataFrame): Data with missing values
        method (str, optional): Interpolation method. Defaults to 'linear'.
            Options: 'linear', 'time', 'index', 'values', 'nearest', 'zero',
            'slinear', 'quadratic', 'cubic', 'barycentric', 'krogh', 'spline',
            'polynomial', 'from_derivatives', 'piecewise_polynomial', 'pchip',
            'akima', 'cubicspline'
        limit (int, optional): Maximum number of consecutive NaNs to fill.
            Defaults to None (no limit).
        
    Returns:
        pd.DataFrame: Data with interpolated values
    """
    # Create a copy of the data
    interpolated = data.copy()
    
    # Interpolate missing values
    interpolated = interpolated.interpolate(method=method, limit=limit)
    
    return interpolated


def detect_outliers(data: pd.DataFrame,
                   method: str = 'zscore',
                   threshold: float = 3.0) -> pd.DataFrame:
    """Detect outliers in data.
    
    Args:
        data (pd.DataFrame): Data to analyze
        method (str, optional): Outlier detection method. Defaults to 'zscore'.
            Options: 'zscore', 'iqr'
        threshold (float, optional): Threshold for outlier detection.
            For 'zscore', values with absolute z-score > threshold are outliers.
            For 'iqr', values outside (Q1 - threshold * IQR, Q3 + threshold * IQR) are outliers.
            Defaults to 3.0.
        
    Returns:
        pd.DataFrame: Boolean DataFrame indicating outliers
    """
    # Initialize outliers DataFrame
    outliers = pd.DataFrame(False, index=data.index, columns=data.columns)
    
    # Detect outliers for each column
    for col in data.columns:
        if method == 'zscore':
            # Z-score method
            z_scores = (data[col] - data[col].mean()) / data[col].std()
            outliers[col] = abs(z_scores) > threshold
        elif method == 'iqr':
            # IQR method
            q1 = data[col].quantile(0.25)
            q3 = data[col].quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - threshold * iqr
            upper_bound = q3 + threshold * iqr
            outliers[col] = (data[col] < lower_bound) | (data[col] > upper_bound)
        else:
            raise ValueError(f"Unknown outlier detection method: {method}")
    
    return outliers


def replace_outliers(data: pd.DataFrame,
                    outliers: pd.DataFrame,
                    method: str = 'mean') -> pd.DataFrame:
    """Replace outliers in data.
    
    Args:
        data (pd.DataFrame): Data with outliers
        outliers (pd.DataFrame): Boolean DataFrame indicating outliers
        method (str, optional): Replacement method. Defaults to 'mean'.
            Options: 'mean', 'median', 'mode', 'nan'
        
    Returns:
        pd.DataFrame: Data with replaced outliers
    """
    # Create a copy of the data
    replaced = data.copy()
    
    # Replace outliers for each column
    for col in data.columns:
        if method == 'mean':
            # Replace with mean
            replaced.loc[outliers[col], col] = data[col].mean()
        elif method == 'median':
            # Replace with median
            replaced.loc[outliers[col], col] = data[col].median()
        
(Content truncated due to size limit. Use line ranges to read in chunks)