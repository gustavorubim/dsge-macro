"""
Data transformation utilities for DSGE models.

This module provides functions for transforming and preparing data for use with DSGE models.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from typing import Dict, List, Tuple, Optional, Union
from statsmodels.tsa.filters.hp_filter import hpfilter
from statsmodels.tsa.stattools import acf, pacf
from statsmodels.tsa.seasonal import seasonal_decompose


def log_transform(data: pd.DataFrame, 
                 exclude_columns: Optional[List[str]] = None) -> pd.DataFrame:
    """Apply log transformation to data.
    
    Args:
        data (pd.DataFrame): Data to transform
        exclude_columns (List[str], optional): Columns to exclude from transformation.
            Defaults to None.
            
    Returns:
        pd.DataFrame: Log-transformed data
    """
    # Create a copy of the data
    transformed = data.copy()
    
    # Initialize exclude_columns if None
    if exclude_columns is None:
        exclude_columns = []
        
    # Add columns with negative values or rates/ratios to exclude list
    for col in data.columns:
        if col in exclude_columns:
            continue
            
        if 'rate' in col or col.endswith('_ratio') or (data[col] <= 0).any():
            exclude_columns.append(col)
            
    # Apply log transformation
    for col in data.columns:
        if col not in exclude_columns:
            transformed[col] = np.log(data[col])
            
    return transformed


def compute_growth_rates(data: pd.DataFrame, 
                        periods: int = 1,
                        annualize: bool = True,
                        exclude_columns: Optional[List[str]] = None) -> pd.DataFrame:
    """Compute growth rates of data.
    
    Args:
        data (pd.DataFrame): Data to transform
        periods (int, optional): Number of periods for growth rate calculation.
            Defaults to 1.
        annualize (bool, optional): Whether to annualize growth rates.
            Defaults to True.
        exclude_columns (List[str], optional): Columns to exclude from transformation.
            Defaults to None.
            
    Returns:
        pd.DataFrame: Growth rates
    """
    # Create a copy of the data
    growth_rates = data.copy()
    
    # Initialize exclude_columns if None
    if exclude_columns is None:
        exclude_columns = []
        
    # Compute growth rates
    for col in data.columns:
        if col not in exclude_columns:
            # Compute percentage change
            growth_rates[col] = data[col].pct_change(periods=periods)
            
            # Annualize if requested
            if annualize:
                # Determine frequency
                if isinstance(data.index, pd.DatetimeIndex):
                    freq = pd.infer_freq(data.index)
                    if freq:
                        if freq.startswith('Q'):
                            # Quarterly data
                            growth_rates[col] = (1 + growth_rates[col]) ** (4 / periods) - 1
                        elif freq.startswith('M'):
                            # Monthly data
                            growth_rates[col] = (1 + growth_rates[col]) ** (12 / periods) - 1
                        elif freq.startswith('D') or freq.startswith('B'):
                            # Daily or business day data
                            growth_rates[col] = (1 + growth_rates[col]) ** (252 / periods) - 1
                            
    # Drop rows with missing values
    growth_rates = growth_rates.dropna()
    
    return growth_rates


def hp_filter_data(data: pd.DataFrame, 
                  lambda_param: float = 1600,
                  exclude_columns: Optional[List[str]] = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Apply Hodrick-Prescott filter to data.
    
    Args:
        data (pd.DataFrame): Data to filter
        lamb (float, optional): Lambda parameter for HP filter. Defaults to 1600.
        exclude_columns (List[str], optional): Columns to exclude from filtering.
            Defaults to None.
            
    Returns:
        Tuple[pd.DataFrame, pd.DataFrame]: Tuple containing cycle and trend components
    """
    # Initialize exclude_columns if None
    if exclude_columns is None:
        exclude_columns = []
        
    # Initialize cycle and trend DataFrames
    cycle = pd.DataFrame(index=data.index)
    trend = pd.DataFrame(index=data.index)
    
    # Apply HP filter to each column
    for col in data.columns:
        if col not in exclude_columns:
            try:
                # Apply HP filter
                cycle_component, trend_component = hpfilter(data[col], lamb=lambda_param)
                
                # Store results
                cycle[col] = cycle_component
                trend[col] = trend_component
            except Exception as e:
                print(f"Error applying HP filter to {col}: {str(e)}")
                
    return cycle, trend


def linear_detrend(data: pd.DataFrame,
                  exclude_columns: Optional[List[str]] = None) -> pd.DataFrame:
    """Apply linear detrending to data.
    
    Args:
        data (pd.DataFrame): Data to detrend
        exclude_columns (List[str], optional): Columns to exclude from detrending.
            Defaults to None.
            
    Returns:
        pd.DataFrame: Detrended data
    """
    # Initialize exclude_columns if None
    if exclude_columns is None:
        exclude_columns = []
        
    # Initialize detrended DataFrame
    detrended = pd.DataFrame(index=data.index)
    
    # Apply linear detrending to each column
    for col in data.columns:
        if col not in exclude_columns:
            # Create time index
            x = np.arange(len(data))
            y = data[col].values
            
            # Fit linear trend
            mask = ~np.isnan(y)
            if np.sum(mask) > 1:  # Need at least 2 points for regression
                slope, intercept = np.polyfit(x[mask], y[mask], 1)
                trend = intercept + slope * x
                
                # Detrend data
                detrended[col] = y - trend
            else:
                detrended[col] = np.nan
                
    return detrended


def first_difference(data: pd.DataFrame,
                    periods: int = 1,
                    exclude_columns: Optional[List[str]] = None) -> pd.DataFrame:
    """Apply first differencing to data.
    
    Args:
        data (pd.DataFrame): Data to difference
        periods (int, optional): Number of periods for differencing. Defaults to 1.
        exclude_columns (List[str], optional): Columns to exclude from differencing.
            Defaults to None.
            
    Returns:
        pd.DataFrame: Differenced data
    """
    # Initialize exclude_columns if None
    if exclude_columns is None:
        exclude_columns = []
        
    # Initialize differenced DataFrame
    differenced = pd.DataFrame(index=data.index)
    
    # Apply differencing to each column
    for col in data.columns:
        if col not in exclude_columns:
            differenced[col] = data[col].diff(periods=periods)
            
    # Drop rows with missing values
    differenced = differenced.dropna()
    
    return differenced


def seasonal_adjust(data: pd.DataFrame,
                   freq: Optional[str] = None,
                   model: str = 'additive',
                   exclude_columns: Optional[List[str]] = None) -> pd.DataFrame:
    """Apply seasonal adjustment to data.
    
    Args:
        data (pd.DataFrame): Data to adjust
        freq (str, optional): Frequency of the data. Defaults to None (inferred).
        model (str, optional): Type of seasonal component. Defaults to 'additive'.
            Options: 'additive', 'multiplicative'
        exclude_columns (List[str], optional): Columns to exclude from adjustment.
            Defaults to None.
            
    Returns:
        pd.DataFrame: Seasonally adjusted data
    """
    # Initialize exclude_columns if None
    if exclude_columns is None:
        exclude_columns = []
        
    # Initialize adjusted DataFrame
    adjusted = pd.DataFrame(index=data.index)
    
    # Determine frequency if not provided
    if freq is None and isinstance(data.index, pd.DatetimeIndex):
        freq = pd.infer_freq(data.index)
        
    # Apply seasonal adjustment to each column
    for col in data.columns:
        if col not in exclude_columns:
            try:
                # Apply seasonal decomposition
                decomposition = seasonal_decompose(data[col], model=model, period=freq)
                
                # Store seasonally adjusted data
                if model == 'additive':
                    adjusted[col] = data[col] - decomposition.seasonal
                else:
                    adjusted[col] = data[col] / decomposition.seasonal
            except Exception as e:
                print(f"Error applying seasonal adjustment to {col}: {str(e)}")
                adjusted[col] = data[col]
                
    return adjusted


def standardize_data(data: pd.DataFrame,
                    exclude_columns: Optional[List[str]] = None) -> pd.DataFrame:
    """Standardize data to have zero mean and unit variance.
    
    Args:
        data (pd.DataFrame): Data to standardize
        exclude_columns (List[str], optional): Columns to exclude from standardization.
            Defaults to None.
            
    Returns:
        pd.DataFrame: Standardized data
    """
    # Initialize exclude_columns if None
    if exclude_columns is None:
        exclude_columns = []
        
    # Initialize standardized DataFrame
    standardized = pd.DataFrame(index=data.index)
    
    # Apply standardization to each column
    for col in data.columns:
        if col not in exclude_columns:
            standardized[col] = (data[col] - data[col].mean()) / data[col].std()
        else:
            standardized[col] = data[col]
            
    return standardized


def compute_correlations_matrix(data: pd.DataFrame,
                               lags: int = 0) -> pd.DataFrame:
    """Compute correlation matrix of data.
    
    Args:
        data (pd.DataFrame): Data to analyze
        lags (int, optional): Number of lags for cross-correlation. Defaults to 0.
            
    Returns:
        pd.DataFrame: Correlation matrix
    """
    if lags == 0:
        # Compute contemporaneous correlation matrix
        return data.corr()
    else:
        # Compute cross-correlation matrix with lags
        columns = data.columns
        n_cols = len(columns)
        
        # Initialize correlation matrix
        corr_matrix = pd.DataFrame(np.zeros((n_cols, n_cols)),
                                  index=columns, columns=columns)
        
        # Compute cross-correlations
        for i, col1 in enumerate(columns):
            for j, col2 in enumerate(columns):
                # Skip if both columns are the same
                if i == j:
                    corr_matrix.loc[col1, col2] = 1.0
                    continue
                    
                # Compute cross-correlation
                series1 = data[col1].dropna()
                series2 = data[col2].dropna()
                
                # Align series
                series1, series2 = series1.align(series2, join='inner')
                
                if len(series1) > lags:
                    # Shift series2 by lags
                    series2_lagged = series2.shift(lags)
                    
                    # Compute correlation
                    valid_mask = ~np.isnan(series1) & ~np.isnan(series2_lagged)
                    if np.sum(valid_mask) > 1:
                        corr = np.corrcoef(series1[valid_mask], series2_lagged[valid_mask])[0, 1]
                        corr_matrix.loc[col1, col2] = corr
                        
        return corr_matrix


def compute_autocorrelations(data: pd.DataFrame,
                            lags: int = 10,
                            partial: bool = False) -> pd.DataFrame:
    """Compute autocorrelations of data.
    
    Args:
        data (pd.DataFrame): Data to analyze
        lags (int, optional): Number of lags. Defaults to 10.
        partial (bool, optional): Whether to compute partial autocorrelations.
            Defaults to False.
            
    Returns:
        pd.DataFrame: DataFrame containing autocorrelations
    """
    # Initialize autocorrelations DataFrame
    autocorr = pd.DataFrame(index=range(1, lags + 1))
    
    # Compute autocorrelations for each column
    for col in data.columns:
        series = data[col].dropna()
        
        if len(series) > lags:
            if partial:
                # Compute partial autocorrelations
                pacf_values = pacf(series, nlags=lags)[1:]
                autocorr[col] = pacf_values
            else:
                # Compute autocorrelations
                acf_values = acf(series, nlags=lags)[1:]
                autocorr[col] = acf_values
                
    return autocorr


def plot_transformed_data(original: pd.DataFrame,
                         transformed: pd.DataFrame,
                         variables: Optional[List[str]] = None,
                         figsize: Tuple[int, int] = (15, 10),
                         ncols: int = 2,
                         transformation_name: str = 'Transformed',
                         save_path: Optional[str] = None) -> plt.Figure:
    """Plot original and transformed data for comparison.
    
    Args:
        original (pd.DataFrame): Original data
        transformed (pd.DataFrame): Transformed data
        variables (List[str], optional): Variables to plot. Defaults to None (all).
        figsize (Tuple[int, int], optional): Figure size. Defaults to (15, 10).
        ncols (int, optional): Number of columns in the plot grid. Defaults to 2.
        transformation_name (str, optional): Name of the transformation. Defaults to 'Transformed'.
        save_path (str, optional): Path to save the plot. Defaults to None.
            
    Returns:
        plt.Figure: Figure object
    """
    # Get variables to plot
    if variables is None:
        variables = [col for col in original.columns if col in transformed.columns]
    else:
        variables = [col for col in variables if col in original.columns and col in transformed.columns]
        
    # Compute number of rows and columns
    n_vars = len(variables)
    ncols = min(ncols, n_vars)
    nrows = (n_vars + ncols - 1) // ncols
    
    # Create figure
    fig, axes = plt.subplots(nrows, ncols, figsize=figsize, squeeze=False)
    
    # Plot each variable
    for i, var in enumerate(variables):
        row = i // ncols
        col = i % ncols
        ax = axes[row, col]
        
        # Plot original data
        ax.plot(original.index, original[var], label='Original', color='blue')
        
        # Plot transformed data
        ax.plot(transformed.index, transformed[var], label=transformation_name, color='red')
        
        # Add labels
        ax.set_title(var)
        ax.set_xlabel('Time')
        ax.set_ylabel('Value')
        ax.legend()
        
        # Rotate x-axis labels for better readability
        plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    # Remove empty subplots
    for i in range(n_vars, nrows * ncols):
        row = i // ncols
        col = i % ncols
        fig.delaxes(axes[row, col])
    
    # Adjust layout
    fig.tight_layout()
    
    # Save figure if path is provided
    if save_path:
        fig.savefig(save_path)
        print(f"Plot saved to {save_path}")
    
    return fig


def plot_autocorrelations(data: pd.DataFrame,
                         lags: int = 10,
                         variables: Optional[List[str]] = None,
                         figsize: Tuple[int, int] = (15, 10),
                         ncols: int = 2,
                         save_
(Content truncated due to size limit. Use line ranges to read in chunks)