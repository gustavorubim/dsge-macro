"""
Posterior analysis tools for DSGE models.

This module provides utilities for analyzing posterior distributions
from Bayesian estimation of DSGE models, including posterior predictive
checks, marginal likelihood computation, and model comparison.
"""

import numpy as np
import jax
import jax.numpy as jnp
from typing import Dict, List, Tuple, Optional, Union, Callable
import pandas as pd
import xarray as xr
import arviz as az
import matplotlib.pyplot as plt
from scipy import stats

from dsge_macro.core.model import DSGEModel


class PosteriorAnalyzer:
    """Posterior analyzer for DSGE models.
    
    This class provides methods for analyzing posterior distributions
    from Bayesian estimation of DSGE models.
    
    Attributes:
        model (DSGEModel): DSGE model
        trace (az.InferenceData): MCMC trace from Bayesian estimation
        data (pd.DataFrame): Data used for estimation
    """
    
    def __init__(self, model: DSGEModel, trace: az.InferenceData, 
                data: Optional[pd.DataFrame] = None):
        """Initialize a posterior analyzer.
        
        Args:
            model (DSGEModel): DSGE model
            trace (az.InferenceData): MCMC trace from Bayesian estimation
            data (pd.DataFrame, optional): Data used for estimation. Defaults to None.
        """
        self.model = model
        self.trace = trace
        self.data = data
        
    def get_posterior_summary(self, parameters: Optional[List[str]] = None) -> pd.DataFrame:
        """Get a summary of the posterior distribution.
        
        Args:
            parameters (List[str], optional): Parameters to include in the summary.
                Defaults to None (all parameters).
                
        Returns:
            pd.DataFrame: Summary statistics of the posterior distribution
        """
        # Get parameters to include
        if parameters is None:
            parameters = [name for name in self.model.parameters if name in self.trace.posterior]
            
        # Compute summary statistics
        summary = az.summary(self.trace, var_names=parameters)
        
        return summary
        
    def get_posterior_mean(self, parameters: Optional[List[str]] = None) -> Dict[str, float]:
        """Get the posterior mean of the parameters.
        
        Args:
            parameters (List[str], optional): Parameters to include.
                Defaults to None (all parameters).
                
        Returns:
            Dict[str, float]: Posterior mean of the parameters
        """
        # Get parameters to include
        if parameters is None:
            parameters = [name for name in self.model.parameters if name in self.trace.posterior]
            
        # Compute posterior mean
        posterior_mean = {}
        for name in parameters:
            if name in self.trace.posterior:
                posterior_mean[name] = float(self.trace.posterior[name].mean())
                
        return posterior_mean
        
    def get_posterior_median(self, parameters: Optional[List[str]] = None) -> Dict[str, float]:
        """Get the posterior median of the parameters.
        
        Args:
            parameters (List[str], optional): Parameters to include.
                Defaults to None (all parameters).
                
        Returns:
            Dict[str, float]: Posterior median of the parameters
        """
        # Get parameters to include
        if parameters is None:
            parameters = [name for name in self.model.parameters if name in self.trace.posterior]
            
        # Compute posterior median
        posterior_median = {}
        for name in parameters:
            if name in self.trace.posterior:
                posterior_median[name] = float(self.trace.posterior[name].median())
                
        return posterior_median
        
    def get_posterior_std(self, parameters: Optional[List[str]] = None) -> Dict[str, float]:
        """Get the posterior standard deviation of the parameters.
        
        Args:
            parameters (List[str], optional): Parameters to include.
                Defaults to None (all parameters).
                
        Returns:
            Dict[str, float]: Posterior standard deviation of the parameters
        """
        # Get parameters to include
        if parameters is None:
            parameters = [name for name in self.model.parameters if name in self.trace.posterior]
            
        # Compute posterior std
        posterior_std = {}
        for name in parameters:
            if name in self.trace.posterior:
                posterior_std[name] = float(self.trace.posterior[name].std())
                
        return posterior_std
        
    def get_posterior_quantiles(self, q: List[float] = [0.025, 0.5, 0.975],
                               parameters: Optional[List[str]] = None) -> Dict[str, List[float]]:
        """Get the posterior quantiles of the parameters.
        
        Args:
            q (List[float], optional): Quantiles to compute. Defaults to [0.025, 0.5, 0.975].
            parameters (List[str], optional): Parameters to include.
                Defaults to None (all parameters).
                
        Returns:
            Dict[str, List[float]]: Posterior quantiles of the parameters
        """
        # Get parameters to include
        if parameters is None:
            parameters = [name for name in self.model.parameters if name in self.trace.posterior]
            
        # Compute posterior quantiles
        posterior_quantiles = {}
        for name in parameters:
            if name in self.trace.posterior:
                posterior_quantiles[name] = [float(self.trace.posterior[name].quantile(qi)) for qi in q]
                
        return posterior_quantiles
        
    def get_posterior_hdi(self, hdi_prob: float = 0.95,
                         parameters: Optional[List[str]] = None) -> Dict[str, Tuple[float, float]]:
        """Get the highest density interval of the parameters.
        
        Args:
            hdi_prob (float, optional): Probability mass of the HDI. Defaults to 0.95.
            parameters (List[str], optional): Parameters to include.
                Defaults to None (all parameters).
                
        Returns:
            Dict[str, Tuple[float, float]]: Highest density interval of the parameters
        """
        # Get parameters to include
        if parameters is None:
            parameters = [name for name in self.model.parameters if name in self.trace.posterior]
            
        # Compute posterior HDI
        posterior_hdi = {}
        for name in parameters:
            if name in self.trace.posterior:
                hdi = az.hdi(self.trace.posterior[name], hdi_prob=hdi_prob)
                posterior_hdi[name] = (float(hdi[0]), float(hdi[1]))
                
        return posterior_hdi
        
    def compute_convergence_diagnostics(self, parameters: Optional[List[str]] = None) -> Dict[str, Dict[str, float]]:
        """Compute convergence diagnostics for the MCMC chains.
        
        Args:
            parameters (List[str], optional): Parameters to include.
                Defaults to None (all parameters).
                
        Returns:
            Dict[str, Dict[str, float]]: Convergence diagnostics
        """
        # Get parameters to include
        if parameters is None:
            parameters = [name for name in self.model.parameters if name in self.trace.posterior]
            
        # Compute Gelman-Rubin statistic
        rhat = az.rhat(self.trace, var_names=parameters)
        
        # Compute effective sample size
        ess = az.ess(self.trace, var_names=parameters)
        
        # Compute Monte Carlo standard error
        mcse = az.mcse(self.trace, var_names=parameters)
        
        # Combine diagnostics
        diagnostics = {}
        for name in parameters:
            if name in self.trace.posterior:
                diagnostics[name] = {
                    'rhat': float(rhat[name]),
                    'ess': float(ess[name]),
                    'mcse': float(mcse[name])
                }
                
        return diagnostics
        
    def compute_posterior_predictive(self, n_samples: int = 100, 
                                    periods: int = 100) -> xr.Dataset:
        """Compute the posterior predictive distribution.
        
        Args:
            n_samples (int, optional): Number of posterior samples to use. Defaults to 100.
            periods (int, optional): Number of periods to simulate. Defaults to 100.
                
        Returns:
            xr.Dataset: Posterior predictive distribution
        """
        # Get posterior samples
        posterior_samples = self.trace.posterior.stack(sample=("chain", "draw"))
        
        # Randomly select samples
        n_available = posterior_samples.dims["sample"]
        if n_samples > n_available:
            n_samples = n_available
            print(f"Warning: Only {n_available} posterior samples available. Using all of them.")
            
        sample_indices = np.random.choice(n_available, size=n_samples, replace=False)
        
        # Initialize posterior predictive
        posterior_predictive = []
        
        # Simulate the model for each posterior sample
        for i in range(n_samples):
            # Get parameter values for this sample
            idx = sample_indices[i]
            params = {}
            for name in self.model.parameters:
                if name in posterior_samples:
                    params[name] = float(posterior_samples[name].isel(sample=idx))
                else:
                    params[name] = self.model.parameters[name]['value']
                    
            # Update model parameters
            self.model.calibrate(params)
            
            # Solve the model
            self.model.solve()
            
            # Simulate the model
            sim = self.model.simulate(periods)
            
            # Add to posterior predictive
            posterior_predictive.append(sim)
            
        # Combine simulations
        pp_dataset = xr.concat(posterior_predictive, dim="posterior_sample")
        
        return pp_dataset
        
    def compute_posterior_predictive_check(self, statistics: List[Callable],
                                          variable: str, n_samples: int = 100,
                                          periods: int = 100) -> Dict[str, Tuple[float, np.ndarray]]:
        """Compute posterior predictive checks for a variable.
        
        Args:
            statistics (List[Callable]): List of statistics to compute
            variable (str): Variable to check
            n_samples (int, optional): Number of posterior samples to use. Defaults to 100.
            periods (int, optional): Number of periods to simulate. Defaults to 100.
                
        Returns:
            Dict[str, Tuple[float, np.ndarray]]: Posterior predictive p-values and distributions
        """
        if self.data is None:
            raise ValueError("Data must be provided for posterior predictive checks")
            
        # Compute posterior predictive distribution
        pp_dataset = self.compute_posterior_predictive(n_samples, periods)
        
        # Get observed data for the variable
        if variable in self.data.columns:
            observed_data = self.data[variable].values
        else:
            raise ValueError(f"Variable {variable} not found in data")
            
        # Compute statistics for observed data
        observed_stats = {}
        for stat in statistics:
            stat_name = stat.__name__
            observed_stats[stat_name] = stat(observed_data)
            
        # Compute statistics for posterior predictive samples
        pp_stats = {}
        for stat in statistics:
            stat_name = stat.__name__
            pp_stats[stat_name] = np.array([stat(pp_dataset[variable].isel(posterior_sample=i).values) 
                                          for i in range(n_samples)])
            
        # Compute posterior predictive p-values
        pp_pvalues = {}
        for stat_name, observed_stat in observed_stats.items():
            pp_stat = pp_stats[stat_name]
            pp_pvalues[stat_name] = (np.mean(pp_stat >= observed_stat), pp_stat)
            
        return pp_pvalues
        
    def compute_marginal_likelihood(self, method: str = 'bridge_sampling') -> float:
        """Compute the marginal likelihood of the model.
        
        Args:
            method (str, optional): Method to use. Defaults to 'bridge_sampling'.
                Options: 'bridge_sampling', 'harmonic_mean'
                
        Returns:
            float: Marginal likelihood
        """
        if method == 'bridge_sampling':
            # This is a placeholder for the actual bridge sampling implementation
            # In a real implementation, we would use a proper bridge sampling algorithm
            return 0.0
        elif method == 'harmonic_mean':
            # This is a placeholder for the actual harmonic mean implementation
            # In a real implementation, we would use a proper harmonic mean algorithm
            return 0.0
        else:
            raise ValueError(f"Unknown method: {method}")
            
    def compute_bayes_factor(self, other_model: 'PosteriorAnalyzer',
                            method: str = 'bridge_sampling') -> float:
        """Compute the Bayes factor between this model and another model.
        
        Args:
            other_model (PosteriorAnalyzer): Another model to compare with
            method (str, optional): Method to use. Defaults to 'bridge_sampling'.
                Options: 'bridge_sampling', 'harmonic_mean'
                
        Returns:
            float: Bayes factor
        """
        # Compute marginal likelihoods
        ml1 = self.compute_marginal_likelihood(method)
        ml2 = other_model.compute_marginal_likelihood(method)
        
        # Compute Bayes factor
        bayes_factor = np.exp(ml1 - ml2)
        
        return bayes_factor
        
    def plot_posterior(self, parameters: Optional[List[str]] = None, 
                      figsize: Tuple[int, int] = (10, 8)):
        """Plot the posterior distributions of the parameters.
        
        Args:
            parameters (List[str], optional): Parameters to plot. Defaults to None (all parameters).
            figsize (Tuple[int, int], optional): Figure size. Defaults to (10, 8).
            
        Returns:
            matplotlib.figure.Figure: Figure object
        """
        # Get parameters to plot
        if parameters is None:
            parameters = [name for name in self.model.parameters if name in self.trace.posterior]
            
        # Plot posterior
        ax = az.plot_posterior(self.trace, var_names=parameters, figsize=figsize)
        
        return ax
        
    def plot_trace(self, parameters: Optional[List[str]] = None, 
                  figsize: Tuple[int, int] = (10, 8)):
        """Plot the MCMC trace of the parameters.
        
        Args:
            parameters (List[str], optional): Parameters to plot. Defaults to None (all parameters).
            figsize (Tuple[int, int], optional): Figure size. Defaults to (10, 8).
            
        Returns:
            matplotlib.figure.Figure: Figure object
        """
        # Get parameters to plot
        if parameters is None:
            parameters = [name for name in self.model.parameters if name in self.trace.posterior]
            
        # Plot trace
        ax = az.plot_trace(self.trace, var_names=parameters, figsize=figsize)
        
        return ax
        
    def plot_forest(self, parameters: Optional[List[str]] = None, 
                   figsize: Tuple[int, int] = (10, 8)):
        """Plot a forest plot of the parameters.
        
    
(Content truncated due to size limit. Use line ranges to read in chunks)