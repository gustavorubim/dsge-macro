"""
Calibration tools for DSGE models.

This module provides utilities for calibrating DSGE models using
various methods, including matching moments, steady state values,
and impulse response functions.
"""

import numpy as np
import jax
import jax.numpy as jnp
from typing import Dict, List, Tuple, Optional, Union, Callable
import pandas as pd
import xarray as xr
from scipy import optimize

from dsge_macro.core.model import DSGEModel


class Calibrator:
    """Calibrator for DSGE models.
    
    This class provides methods for calibrating DSGE models using
    various methods, including matching moments, steady state values,
    and impulse response functions.
    
    Attributes:
        model (DSGEModel): DSGE model to calibrate
        targets (Dict): Calibration targets
        results (Dict): Calibration results
    """
    
    def __init__(self, model: DSGEModel):
        """Initialize a calibrator.
        
        Args:
            model (DSGEModel): DSGE model to calibrate
        """
        self.model = model
        self.targets = {}
        self.results = None
        
    def set_steady_state_targets(self, targets: Dict[str, float]):
        """Set steady state targets for calibration.
        
        Args:
            targets (Dict[str, float]): Dictionary of steady state targets
        """
        self.targets['steady_state'] = targets
        
    def set_moment_targets(self, targets: Dict[str, Dict[str, float]]):
        """Set moment targets for calibration.
        
        Args:
            targets (Dict[str, Dict[str, float]]): Dictionary of moment targets
                The outer dictionary keys are variable names, and the inner
                dictionary keys are moment names (e.g., 'mean', 'std', 'autocorr')
        """
        self.targets['moments'] = targets
        
    def set_irf_targets(self, targets: Dict[str, Dict[str, List[float]]]):
        """Set impulse response function targets for calibration.
        
        Args:
            targets (Dict[str, Dict[str, List[float]]]): Dictionary of IRF targets
                The outer dictionary keys are shock names, the middle dictionary
                keys are variable names, and the values are lists of IRF values
        """
        self.targets['irf'] = targets
        
    def calibrate_steady_state(self, parameters_to_calibrate: List[str],
                              method: str = 'Nelder-Mead',
                              bounds: Optional[Dict[str, Tuple[float, float]]] = None,
                              options: Optional[Dict] = None) -> Dict:
        """Calibrate the model to match steady state targets.
        
        Args:
            parameters_to_calibrate (List[str]): List of parameters to calibrate
            method (str, optional): Optimization method. Defaults to 'Nelder-Mead'.
            bounds (Dict[str, Tuple[float, float]], optional): Parameter bounds.
                Defaults to None (no bounds).
            options (Dict, optional): Additional options for the optimizer.
                Defaults to None.
                
        Returns:
            Dict: Calibration results
        """
        if 'steady_state' not in self.targets:
            raise ValueError("Steady state targets must be set before calibration")
            
        # Get initial parameter values
        initial_params = {name: self.model.parameters[name]['value'] for name in parameters_to_calibrate}
        
        # Get parameter names and values
        param_names = list(initial_params.keys())
        param_values = np.array([initial_params[name] for name in param_names])
        
        # Define objective function
        def objective(x):
            # Convert parameter vector to dictionary
            params = {name: x[i] for i, name in enumerate(param_names)}
            
            # Update model parameters
            self.model.calibrate(params)
            
            # Compute steady state
            steady_state = self.model.compute_steady_state()
            
            # Compute sum of squared deviations from targets
            ss_targets = self.targets['steady_state']
            ss_error = 0.0
            
            for var, target in ss_targets.items():
                if var in steady_state:
                    ss_error += (steady_state[var] - target) ** 2
                else:
                    ss_error += 1e6  # Large penalty for missing variables
                    
            return ss_error
        
        # Set up bounds if provided
        if bounds is not None:
            # Convert bounds dictionary to list of tuples
            bounds_list = []
            for name in param_names:
                if name in bounds:
                    bounds_list.append(bounds[name])
                else:
                    bounds_list.append((None, None))
        else:
            bounds_list = None
            
        # Set up options
        if options is None:
            options = {'disp': True}
            
        # Minimize sum of squared deviations
        result = optimize.minimize(
            objective, 
            param_values, 
            method=method, 
            bounds=bounds_list, 
            options=options
        )
        
        # Check if optimization was successful
        if not result.success:
            print(f"Warning: Optimization did not converge: {result.message}")
            
        # Convert parameter vector to dictionary
        calibrated_params = {name: result.x[i] for i, name in enumerate(param_names)}
        
        # Update model parameters
        self.model.calibrate(calibrated_params)
        
        # Compute steady state with calibrated parameters
        steady_state = self.model.compute_steady_state()
        
        # Compute final deviations from targets
        ss_targets = self.targets['steady_state']
        ss_deviations = {}
        
        for var, target in ss_targets.items():
            if var in steady_state:
                ss_deviations[var] = steady_state[var] - target
            else:
                ss_deviations[var] = np.nan
                
        # Store results
        self.results = {
            'parameters': calibrated_params,
            'steady_state': steady_state,
            'targets': ss_targets,
            'deviations': ss_deviations,
            'objective_value': result.fun,
            'optimization_result': result
        }
        
        return self.results
        
    def calibrate_moments(self, parameters_to_calibrate: List[str],
                         method: str = 'Nelder-Mead',
                         bounds: Optional[Dict[str, Tuple[float, float]]] = None,
                         options: Optional[Dict] = None,
                         simulation_periods: int = 1000,
                         n_simulations: int = 10) -> Dict:
        """Calibrate the model to match moment targets.
        
        Args:
            parameters_to_calibrate (List[str]): List of parameters to calibrate
            method (str, optional): Optimization method. Defaults to 'Nelder-Mead'.
            bounds (Dict[str, Tuple[float, float]], optional): Parameter bounds.
                Defaults to None (no bounds).
            options (Dict, optional): Additional options for the optimizer.
                Defaults to None.
            simulation_periods (int, optional): Number of periods to simulate.
                Defaults to 1000.
            n_simulations (int, optional): Number of simulations to run.
                Defaults to 10.
                
        Returns:
            Dict: Calibration results
        """
        if 'moments' not in self.targets:
            raise ValueError("Moment targets must be set before calibration")
            
        # Get initial parameter values
        initial_params = {name: self.model.parameters[name]['value'] for name in parameters_to_calibrate}
        
        # Get parameter names and values
        param_names = list(initial_params.keys())
        param_values = np.array([initial_params[name] for name in param_names])
        
        # Define objective function
        def objective(x):
            # Convert parameter vector to dictionary
            params = {name: x[i] for i, name in enumerate(param_names)}
            
            # Update model parameters
            self.model.calibrate(params)
            
            # Solve the model
            self.model.solve()
            
            # Simulate the model multiple times
            moment_errors = []
            
            for i in range(n_simulations):
                # Simulate the model
                sim = self.model.simulate(simulation_periods)
                
                # Compute moments
                moments = {}
                for var in self.targets['moments']:
                    if var in sim:
                        var_data = sim[var].values
                        moments[var] = {
                            'mean': np.mean(var_data),
                            'std': np.std(var_data),
                            'autocorr': np.corrcoef(var_data[:-1], var_data[1:])[0, 1]
                        }
                    else:
                        moments[var] = {
                            'mean': np.nan,
                            'std': np.nan,
                            'autocorr': np.nan
                        }
                
                # Compute sum of squared deviations from targets
                moment_targets = self.targets['moments']
                sim_error = 0.0
                
                for var, target_moments in moment_targets.items():
                    if var in moments:
                        for moment, target in target_moments.items():
                            if moment in moments[var]:
                                sim_error += (moments[var][moment] - target) ** 2
                            else:
                                sim_error += 1e6  # Large penalty for missing moments
                    else:
                        sim_error += 1e6 * len(target_moments)  # Large penalty for missing variables
                        
                moment_errors.append(sim_error)
                
            # Return average error across simulations
            return np.mean(moment_errors)
        
        # Set up bounds if provided
        if bounds is not None:
            # Convert bounds dictionary to list of tuples
            bounds_list = []
            for name in param_names:
                if name in bounds:
                    bounds_list.append(bounds[name])
                else:
                    bounds_list.append((None, None))
        else:
            bounds_list = None
            
        # Set up options
        if options is None:
            options = {'disp': True}
            
        # Minimize sum of squared deviations
        result = optimize.minimize(
            objective, 
            param_values, 
            method=method, 
            bounds=bounds_list, 
            options=options
        )
        
        # Check if optimization was successful
        if not result.success:
            print(f"Warning: Optimization did not converge: {result.message}")
            
        # Convert parameter vector to dictionary
        calibrated_params = {name: result.x[i] for i, name in enumerate(param_names)}
        
        # Update model parameters
        self.model.calibrate(calibrated_params)
        
        # Solve the model
        self.model.solve()
        
        # Simulate the model
        sim = self.model.simulate(simulation_periods)
        
        # Compute moments with calibrated parameters
        moments = {}
        for var in self.targets['moments']:
            if var in sim:
                var_data = sim[var].values
                moments[var] = {
                    'mean': np.mean(var_data),
                    'std': np.std(var_data),
                    'autocorr': np.corrcoef(var_data[:-1], var_data[1:])[0, 1]
                }
            else:
                moments[var] = {
                    'mean': np.nan,
                    'std': np.nan,
                    'autocorr': np.nan
                }
        
        # Compute final deviations from targets
        moment_targets = self.targets['moments']
        moment_deviations = {}
        
        for var, target_moments in moment_targets.items():
            moment_deviations[var] = {}
            for moment, target in target_moments.items():
                if var in moments and moment in moments[var]:
                    moment_deviations[var][moment] = moments[var][moment] - target
                else:
                    moment_deviations[var][moment] = np.nan
                    
        # Store results
        self.results = {
            'parameters': calibrated_params,
            'moments': moments,
            'targets': moment_targets,
            'deviations': moment_deviations,
            'objective_value': result.fun,
            'optimization_result': result
        }
        
        return self.results
        
    def calibrate_irf(self, parameters_to_calibrate: List[str],
                     method: str = 'Nelder-Mead',
                     bounds: Optional[Dict[str, Tuple[float, float]]] = None,
                     options: Optional[Dict] = None) -> Dict:
        """Calibrate the model to match impulse response function targets.
        
        Args:
            parameters_to_calibrate (List[str]): List of parameters to calibrate
            method (str, optional): Optimization method. Defaults to 'Nelder-Mead'.
            bounds (Dict[str, Tuple[float, float]], optional): Parameter bounds.
                Defaults to None (no bounds).
            options (Dict, optional): Additional options for the optimizer.
                Defaults to None.
                
        Returns:
            Dict: Calibration results
        """
        if 'irf' not in self.targets:
            raise ValueError("IRF targets must be set before calibration")
            
        # Get initial parameter values
        initial_params = {name: self.model.parameters[name]['value'] for name in parameters_to_calibrate}
        
        # Get parameter names and values
        param_names = list(initial_params.keys())
        param_values = np.array([initial_params[name] for name in param_names])
        
        # Define objective function
        def objective(x):
            # Convert parameter vector to dictionary
            params = {name: x[i] for i, name in enumerate(param_names)}
            
            # Update model parameters
            self.model.calibrate(params)
            
            # Solve the model
            self.model.solve()
            
            # Compute IRFs
            irf_error = 0.0
            
            for shock, shock_targets in self.targets['irf'].items():
                # Generate IRF for this shock
                periods = max(len(target) for target in shock_targets.values())
                irf = self.model.generate_irf(shock, periods=periods)
                
                # Compute sum of squared deviations from targets
                for var, target in shock_targets.items():
                    if var in irf:
                        # Get IRF values
                        irf_values = irf[var].values
                        
                        # Compute error for available periods
                        n_periods = min(len(irf_values), len(target))
                        for t in range(n_periods):
                            irf_error += (irf_values[t] - target[t]) ** 2
                    else:
                        irf_error += 1e6 * len(target)  # Large penalty for missing variables
                        
            return irf_error
        
        # Set up bounds if provided
        if bounds is not None:
            # Con
(Content truncated due to size limit. Use line ranges to read in chunks)