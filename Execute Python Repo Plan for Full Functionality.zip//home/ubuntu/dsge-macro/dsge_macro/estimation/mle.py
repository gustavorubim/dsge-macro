"""
Maximum likelihood estimation for DSGE models.

This module provides utilities for maximum likelihood estimation of DSGE models
using optimization methods.
"""

import numpy as np
import jax
import jax.numpy as jnp
from typing import Dict, List, Tuple, Optional, Union, Callable
import pandas as pd
import xarray as xr
from scipy import optimize
from scipy import stats

from dsge_macro.core.model import DSGEModel


class MLEstimator:
    """Maximum likelihood estimator for DSGE models.
    
    This class provides methods for maximum likelihood estimation of DSGE models
    using optimization methods.
    
    Attributes:
        model (DSGEModel): DSGE model to estimate
        data (pd.DataFrame): Data for estimation
        results (Dict): Estimation results
    """
    
    def __init__(self, model: DSGEModel):
        """Initialize a maximum likelihood estimator.
        
        Args:
            model (DSGEModel): DSGE model to estimate
        """
        self.model = model
        self.data = None
        self.results = None
        
    def set_data(self, data: Union[pd.DataFrame, xr.Dataset], 
                variable_mapping: Optional[Dict[str, str]] = None):
        """Set the data for estimation.
        
        Args:
            data (Union[pd.DataFrame, xr.Dataset]): Data for estimation
            variable_mapping (Dict[str, str], optional): Mapping from model variables
                to data columns. Defaults to None (use same names).
        """
        if isinstance(data, xr.Dataset):
            # Convert xarray Dataset to pandas DataFrame
            data = data.to_dataframe().reset_index()
            
        self.data = data
        
        # Store variable mapping
        if variable_mapping is None:
            # Create default mapping (assume same names)
            self.variable_mapping = {var: var for var in self.model.variables}
        else:
            self.variable_mapping = variable_mapping
            
    def log_likelihood(self, parameters: Dict[str, float]) -> float:
        """Compute the log-likelihood of the model given the data.
        
        Args:
            parameters (Dict[str, float]): Model parameters
            
        Returns:
            float: Log-likelihood
        """
        # Update model parameters
        self.model.calibrate(parameters)
        
        # Solve the model
        self.model.solve()
        
        # Get state space representation
        state_space = self.model.get_state_space_representation()
        
        # Extract state space matrices
        A = state_space['A']  # State transition matrix
        B = state_space['B']  # Shock impact matrix
        C = state_space['C']  # Observation matrix
        D = state_space['D']  # Observation shock matrix
        
        # Get data
        data = self.data
        
        # Get variable mapping
        var_mapping = self.variable_mapping
        
        # Get observed variables
        observed_vars = [var for var in var_mapping.keys() if var_mapping[var] in data.columns]
        
        # Get observed data
        observed_data = data[[var_mapping[var] for var in observed_vars]].values
        
        # Number of observations and variables
        T, n_obs = observed_data.shape
        
        # Initialize Kalman filter
        # This is a placeholder for the actual Kalman filter implementation
        # In a real implementation, we would use a proper Kalman filter
        
        # Compute log-likelihood
        log_likelihood = 0.0
        
        # Return negative log-likelihood (for minimization)
        return -log_likelihood
        
    def estimate(self, initial_params: Optional[Dict[str, float]] = None, 
                method: str = 'BFGS', bounds: Optional[Dict[str, Tuple[float, float]]] = None,
                options: Optional[Dict] = None) -> Dict:
        """Estimate the model parameters using maximum likelihood.
        
        Args:
            initial_params (Dict[str, float], optional): Initial parameter values.
                Defaults to None (use model's current parameters).
            method (str, optional): Optimization method. Defaults to 'BFGS'.
            bounds (Dict[str, Tuple[float, float]], optional): Parameter bounds.
                Defaults to None (no bounds).
            options (Dict, optional): Additional options for the optimizer.
                Defaults to None.
                
        Returns:
            Dict: Estimation results
        """
        if self.data is None:
            raise ValueError("Data must be set before estimation")
            
        # Get initial parameters
        if initial_params is None:
            initial_params = {name: param['value'] for name, param in self.model.parameters.items()}
            
        # Get parameter names and values
        param_names = list(initial_params.keys())
        param_values = np.array([initial_params[name] for name in param_names])
        
        # Define objective function
        def objective(x):
            # Convert parameter vector to dictionary
            params = {name: x[i] for i, name in enumerate(param_names)}
            
            # Compute negative log-likelihood
            return self.log_likelihood(params)
        
        # Set up bounds if provided
        if bounds is not None:
            # Convert bounds dictionary to list of tuples
            bounds_list = []
            for name in param_names:
                if name in bounds:
                    bounds_list.append(bounds[name])
                else:
                    bounds_list.append((None, None))
        else:
            bounds_list = None
            
        # Set up options
        if options is None:
            options = {'disp': True}
            
        # Minimize negative log-likelihood
        result = optimize.minimize(
            objective, 
            param_values, 
            method=method, 
            bounds=bounds_list, 
            options=options
        )
        
        # Check if optimization was successful
        if not result.success:
            print(f"Warning: Optimization did not converge: {result.message}")
            
        # Convert parameter vector to dictionary
        estimated_params = {name: result.x[i] for i, name in enumerate(param_names)}
        
        # Compute standard errors
        # This is a placeholder for the actual standard error computation
        # In a real implementation, we would compute the Hessian and invert it
        std_errors = {name: np.nan for name in param_names}
        
        # Compute confidence intervals
        # This is a placeholder for the actual confidence interval computation
        # In a real implementation, we would use the standard errors
        conf_intervals = {name: (np.nan, np.nan) for name in param_names}
        
        # Compute information criteria
        n_params = len(param_names)
        n_obs = len(self.data)
        log_likelihood = -result.fun
        
        aic = 2 * n_params - 2 * log_likelihood
        bic = n_params * np.log(n_obs) - 2 * log_likelihood
        
        # Store results
        self.results = {
            'parameters': estimated_params,
            'std_errors': std_errors,
            'conf_intervals': conf_intervals,
            'log_likelihood': log_likelihood,
            'aic': aic,
            'bic': bic,
            'n_obs': n_obs,
            'n_params': n_params,
            'optimization_result': result
        }
        
        return self.results
        
    def update_model_with_estimates(self):
        """Update the model parameters with the estimated values.
        
        Returns:
            DSGEModel: Updated model
        """
        if self.results is None:
            raise ValueError("Model must be estimated before updating parameters")
            
        # Get estimated parameters
        estimated_params = self.results['parameters']
        
        # Update model parameters
        self.model.calibrate(estimated_params)
        
        return self.model
        
    def compute_standard_errors(self):
        """Compute standard errors for the estimated parameters.
        
        Returns:
            Dict[str, float]: Standard errors
        """
        if self.results is None:
            raise ValueError("Model must be estimated before computing standard errors")
            
        # Get parameter names and estimated values
        param_names = list(self.results['parameters'].keys())
        param_values = np.array([self.results['parameters'][name] for name in param_names])
        
        # Define objective function
        def objective(x):
            # Convert parameter vector to dictionary
            params = {name: x[i] for i, name in enumerate(param_names)}
            
            # Compute negative log-likelihood
            return self.log_likelihood(params)
        
        # Compute Hessian
        try:
            hessian = optimize.approx_fprime(param_values, lambda x: optimize.approx_fprime(x, objective, 1e-6), 1e-6)
            
            # Invert Hessian to get covariance matrix
            cov_matrix = np.linalg.inv(hessian)
            
            # Extract standard errors (square root of diagonal elements)
            std_errors = {name: np.sqrt(cov_matrix[i, i]) for i, name in enumerate(param_names)}
        except:
            # If Hessian computation fails, return NaN
            std_errors = {name: np.nan for name in param_names}
            
        # Update results
        self.results['std_errors'] = std_errors
        
        return std_errors
        
    def compute_confidence_intervals(self, alpha: float = 0.05):
        """Compute confidence intervals for the estimated parameters.
        
        Args:
            alpha (float, optional): Significance level. Defaults to 0.05.
            
        Returns:
            Dict[str, Tuple[float, float]]: Confidence intervals
        """
        if self.results is None:
            raise ValueError("Model must be estimated before computing confidence intervals")
            
        # Compute standard errors if not already computed
        if all(np.isnan(se) for se in self.results['std_errors'].values()):
            self.compute_standard_errors()
            
        # Get parameter names, estimated values, and standard errors
        param_names = list(self.results['parameters'].keys())
        param_values = {name: self.results['parameters'][name] for name in param_names}
        std_errors = {name: self.results['std_errors'][name] for name in param_names}
        
        # Compute critical value
        critical_value = stats.norm.ppf(1 - alpha/2)
        
        # Compute confidence intervals
        conf_intervals = {}
        for name in param_names:
            if np.isnan(std_errors[name]):
                conf_intervals[name] = (np.nan, np.nan)
            else:
                lower = param_values[name] - critical_value * std_errors[name]
                upper = param_values[name] + critical_value * std_errors[name]
                conf_intervals[name] = (lower, upper)
                
        # Update results
        self.results['conf_intervals'] = conf_intervals
        
        return conf_intervals
        
    def print_results(self):
        """Print the estimation results."""
        if self.results is None:
            raise ValueError("Model must be estimated before printing results")
            
        # Get parameter names, estimated values, standard errors, and confidence intervals
        param_names = list(self.results['parameters'].keys())
        param_values = {name: self.results['parameters'][name] for name in param_names}
        std_errors = {name: self.results['std_errors'][name] for name in param_names}
        conf_intervals = {name: self.results['conf_intervals'][name] for name in param_names}
        
        # Print header
        print("Maximum Likelihood Estimation Results")
        print("=====================================")
        print(f"Number of observations: {self.results['n_obs']}")
        print(f"Number of parameters: {self.results['n_params']}")
        print(f"Log-likelihood: {self.results['log_likelihood']:.4f}")
        print(f"AIC: {self.results['aic']:.4f}")
        print(f"BIC: {self.results['bic']:.4f}")
        print()
        
        # Print parameter estimates
        print("Parameter Estimates")
        print("------------------")
        print(f"{'Parameter':<20} {'Estimate':<10} {'Std. Error':<10} {'95% CI':<20}")
        print(f"{'-'*20} {'-'*10} {'-'*10} {'-'*20}")
        
        for name in param_names:
            estimate = param_values[name]
            std_error = std_errors[name]
            ci_lower, ci_upper = conf_intervals[name]
            
            if np.isnan(std_error):
                print(f"{name:<20} {estimate:<10.4f} {'N/A':<10} {'N/A':<20}")
            else:
                ci_str = f"({ci_lower:.4f}, {ci_upper:.4f})"
                print(f"{name:<20} {estimate:<10.4f} {std_error:<10.4f} {ci_str:<20}")
                
        print()
        
        # Print optimization details
        print("Optimization Details")
        print("-------------------")
        print(f"Method: {self.results['optimization_result'].get('method', 'N/A')}")
        print(f"Success: {self.results['optimization_result'].success}")
        print(f"Message: {self.results['optimization_result'].message}")
        print(f"Number of function evaluations: {self.results['optimization_result'].get('nfev', 'N/A')}")
        print(f"Number of iterations: {self.results['optimization_result'].get('nit', 'N/A')}")
