import unittest
import numpy as np
import pandas as pd
from dsge_macro.simulation.irf import IRFGenerator
from dsge_macro.simulation.variance import VarianceDecomposition
from dsge_macro.simulation.forecast import Forecaster
from dsge_macro.simulation.historical import HistoricalDecomposition
from dsge_macro.core.smets_wouters import SWModel

class TestIRFGenerator(unittest.TestCase):
    """Test cases for the IRFGenerator class."""
    
    def setUp(self):
        """Set up a model and IRF generator."""
        self.model = SWModel()
        self.model.solve()
        self.irf_generator = IRFGenerator(self.model)
        
    def test_initialization(self):
        """Test IRF generator initialization."""
        self.assertEqual(self.irf_generator.model, self.model)
        
    def test_generate_irf(self):
        """Test IRF generation."""
        # Generate IRFs for a technology shock
        tech_irf = self.irf_generator.generate_irf(shock="eps_a", periods=40, shock_size=0.01)
        
        # Check that IRFs are generated for all variables
        self.assertEqual(len(tech_irf.columns), len(self.model.variables))
        
        # Check that IRFs have the correct length
        self.assertEqual(len(tech_irf), 40)
        
        # Check that IRFs start from non-zero values (shock impact)
        self.assertNotEqual(tech_irf.iloc[0]['y'], 0)
        
    def test_multiple_shocks(self):
        """Test IRF generation for multiple shocks."""
        # Generate IRFs for different shocks
        tech_irf = self.irf_generator.generate_irf(shock="eps_a", periods=40, shock_size=0.01)
        mp_irf = self.irf_generator.generate_irf(shock="eps_r", periods=40, shock_size=0.01)
        
        # Check that IRFs are different for different shocks
        self.assertNotEqual(tech_irf.iloc[0]['y'], mp_irf.iloc[0]['y'])
        
    def test_shock_size(self):
        """Test IRF scaling with shock size."""
        # Generate IRFs with different shock sizes
        small_irf = self.irf_generator.generate_irf(shock="eps_a", periods=40, shock_size=0.01)
        large_irf = self.irf_generator.generate_irf(shock="eps_a", periods=40, shock_size=0.02)
        
        # Check that IRFs scale with shock size
        self.assertAlmostEqual(small_irf.iloc[0]['y'] * 2, large_irf.iloc[0]['y'], places=6)


class TestVarianceDecomposition(unittest.TestCase):
    """Test cases for the VarianceDecomposition class."""
    
    def setUp(self):
        """Set up a model and variance decomposition."""
        self.model = SWModel()
        self.model.solve()
        self.vd = VarianceDecomposition(self.model)
        
    def test_initialization(self):
        """Test variance decomposition initialization."""
        self.assertEqual(self.vd.model, self.model)
        
    def test_compute_variance_decomposition(self):
        """Test variance decomposition computation."""
        # Compute variance decomposition
        variance_decomp = self.vd.compute_variance_decomposition()
        
        # Check that variance decomposition is computed for all variables
        self.assertEqual(len(variance_decomp), len(self.model.variables))
        
        # Check that variance decomposition is computed for all shocks
        for var in variance_decomp:
            self.assertEqual(len(variance_decomp[var]), len(self.model.shocks))
            
        # Check that variance decomposition sums to 1 for each variable
        for var in variance_decomp:
            self.assertAlmostEqual(variance_decomp[var].sum(), 1.0, places=6)


class TestForecaster(unittest.TestCase):
    """Test cases for the Forecaster class."""
    
    def setUp(self):
        """Set up a model and forecaster."""
        self.model = SWModel()
        self.model.solve()
        self.forecaster = Forecaster(self.model)
        
    def test_initialization(self):
        """Test forecaster initialization."""
        self.assertEqual(self.forecaster.model, self.model)
        
    def test_generate_forecast(self):
        """Test forecast generation."""
        # Generate forecast
        forecast = self.forecaster.generate_forecast(periods=20, n_simulations=10)
        
        # Check that forecast is generated for all variables
        self.assertEqual(len(forecast), len(self.model.variables))
        
        # Check that forecast has the correct dimensions
        for var in forecast:
            self.assertEqual(forecast[var].shape, (10, 20))
            
    def test_forecast_statistics(self):
        """Test forecast statistics computation."""
        # Generate forecast
        forecast = self.forecaster.generate_forecast(periods=20, n_simulations=100)
        
        # Compute forecast statistics
        stats = self.forecaster.compute_forecast_statistics(forecast)
        
        # Check that statistics are computed for all variables
        self.assertEqual(len(stats), len(self.model.variables))
        
        # Check that statistics include mean and standard deviation
        for var in stats:
            self.assertIn('mean', stats[var])
            self.assertIn('std', stats[var])
            
            # Check that statistics have the correct length
            self.assertEqual(len(stats[var]['mean']), 20)
            self.assertEqual(len(stats[var]['std']), 20)


class TestHistoricalDecomposition(unittest.TestCase):
    """Test cases for the HistoricalDecomposition class."""
    
    def setUp(self):
        """Set up a model and historical decomposition."""
        self.model = SWModel()
        self.model.solve()
        self.hd = HistoricalDecomposition(self.model)
        
        # Create synthetic data for testing
        np.random.seed(42)
        dates = pd.date_range(start='2000-01-01', periods=40, freq='Q')
        self.data = pd.DataFrame({
            'y': 0.01 * np.random.randn(40),
            'c': 0.01 * np.random.randn(40),
            'i': 0.02 * np.random.randn(40),
            'l': 0.005 * np.random.randn(40),
            'r': 0.003 * np.random.randn(40),
            'pi': 0.002 * np.random.randn(40)
        }, index=dates)
        
    def test_initialization(self):
        """Test historical decomposition initialization."""
        self.assertEqual(self.hd.model, self.model)
        
    def test_compute_historical_decomposition(self):
        """Test historical decomposition computation."""
        # Compute historical decomposition
        hist_decomp = self.hd.compute_historical_decomposition(self.data)
        
        # Check that historical decomposition is computed for all variables
        self.assertEqual(len(hist_decomp), len(self.model.variables))
        
        # Check that historical decomposition includes all shocks and initial conditions
        for var in hist_decomp:
            self.assertEqual(len(hist_decomp[var].columns), len(self.model.shocks) + 1)  # +1 for initial conditions
            
            # Check that historical decomposition has the correct length
            self.assertEqual(len(hist_decomp[var]), len(self.data))
            
        # Check that historical decomposition sums to the data
        for var in hist_decomp:
            if var in self.data.columns:
                decomp_sum = hist_decomp[var].sum(axis=1)
                self.assertTrue(np.allclose(decomp_sum.values, self.data[var].values, atol=1e-6))


if __name__ == "__main__":
    unittest.main()
