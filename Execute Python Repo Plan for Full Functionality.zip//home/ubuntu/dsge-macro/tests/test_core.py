import unittest
import numpy as np
import pandas as pd
from dsge_macro.core.model import DSGEModel
from dsge_macro.core.parameters import ParameterManager
from dsge_macro.core.smets_wouters import SWModel

class TestDSGEModel(unittest.TestCase):
    """Test cases for the base DSGEModel class."""
    
    def setUp(self):
        """Set up a simple test model."""
        self.model = DSGEModel(name="Test Model")
        
    def test_initialization(self):
        """Test model initialization."""
        self.assertEqual(self.model.name, "Test Model")
        self.assertEqual(len(self.model.parameters), 0)
        self.assertEqual(len(self.model.variables), 0)
        self.assertEqual(len(self.model.shocks), 0)
        self.assertEqual(len(self.model.equations), 0)
        
    def test_add_parameter(self):
        """Test adding parameters to the model."""
        self.model.add_parameter("beta", 0.99, description="Discount factor")
        self.assertEqual(len(self.model.parameters), 1)
        self.assertIn("beta", self.model.parameters)
        self.assertEqual(self.model.parameters["beta"]["value"], 0.99)
        self.assertEqual(self.model.parameters["beta"]["description"], "Discount factor")
        
    def test_add_variable(self):
        """Test adding variables to the model."""
        self.model.add_variable("y", "Output")
        self.assertEqual(len(self.model.variables), 1)
        self.assertIn("y", self.model.variables)
        self.assertEqual(self.model.variables["y"], "Output")
        
    def test_add_shock(self):
        """Test adding shocks to the model."""
        self.model.add_shock("eps_a", "Technology shock")
        self.assertEqual(len(self.model.shocks), 1)
        self.assertIn("eps_a", self.model.shocks)
        self.assertEqual(self.model.shocks["eps_a"], "Technology shock")
        
    def test_add_equation(self):
        """Test adding equations to the model."""
        self.model.add_equation("y = a * k + (1-a) * l", "Production function")
        self.assertEqual(len(self.model.equations), 1)
        self.assertEqual(self.model.equations[0]["equation"], "y = a * k + (1-a) * l")
        self.assertEqual(self.model.equations[0]["description"], "Production function")


class TestSWModel(unittest.TestCase):
    """Test cases for the Smets-Wouters model."""
    
    def setUp(self):
        """Set up a Smets-Wouters model."""
        self.model = SWModel()
        
    def test_initialization(self):
        """Test model initialization."""
        self.assertEqual(self.model.name, "Smets-Wouters (2007)")
        self.assertGreater(len(self.model.parameters), 0)
        self.assertGreater(len(self.model.variables), 0)
        self.assertGreater(len(self.model.shocks), 0)
        self.assertGreater(len(self.model.equations), 0)
        
    def test_parameters(self):
        """Test model parameters."""
        # Check key parameters
        self.assertIn("beta", self.model.parameters)
        self.assertIn("sigma_c", self.model.parameters)
        self.assertIn("phi", self.model.parameters)
        self.assertIn("alpha", self.model.parameters)
        
        # Check parameter values
        self.assertAlmostEqual(self.model.parameters["beta"]["value"], 0.99)
        self.assertGreater(self.model.parameters["sigma_c"]["value"], 0)
        
    def test_solve(self):
        """Test model solution."""
        self.model.solve()
        self.assertTrue(self.model.solved)
        self.assertIsNotNone(self.model.solution)
        
    def test_steady_state(self):
        """Test steady state computation."""
        ss = self.model.get_steady_state()
        self.assertIsNotNone(ss)
        self.assertIsInstance(ss, dict)
        
    def test_state_space(self):
        """Test state space representation."""
        self.model.solve()
        ss_rep = self.model.get_state_space_representation()
        self.assertIsNotNone(ss_rep)
        self.assertIn("A", ss_rep)
        self.assertIn("B", ss_rep)
        self.assertIn("C", ss_rep)
        self.assertIn("D", ss_rep)


if __name__ == "__main__":
    unittest.main()