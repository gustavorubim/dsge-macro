import unittest
import os
import sys

# Add the parent directory to the path so we can import the tests
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import test modules
from tests.test_core import TestDSGEModel, TestSWModel
from tests.test_estimation import TestBayesianEstimator, TestMLEstimator, TestCalibration
from tests.test_simulation import TestIRFGenerator, TestVarianceDecomposition, TestForecaster, TestHistoricalDecomposition
from tests.test_extensions import TestFiscalExtension, TestTechnologyExtension, TestFinancialExtension
from tests.test_data import TestDataDownload, TestDataTransform, TestDataUtils

if __name__ == "__main__":
    # Create test suite
    test_suite = unittest.TestSuite()
    
    # Add tests from test_core
    test_suite.addTest(unittest.makeSuite(TestDSGEModel))
    test_suite.addTest(unittest.makeSuite(TestSWModel))
    
    # Add tests from test_estimation
    test_suite.addTest(unittest.makeSuite(TestBayesianEstimator))
    test_suite.addTest(unittest.makeSuite(TestMLEstimator))
    test_suite.addTest(unittest.makeSuite(TestCalibration))
    
    # Add tests from test_simulation
    test_suite.addTest(unittest.makeSuite(TestIRFGenerator))
    test_suite.addTest(unittest.makeSuite(TestVarianceDecomposition))
    test_suite.addTest(unittest.makeSuite(TestForecaster))
    test_suite.addTest(unittest.makeSuite(TestHistoricalDecomposition))
    
    # Add tests from test_extensions
    test_suite.addTest(unittest.makeSuite(TestFiscalExtension))
    test_suite.addTest(unittest.makeSuite(TestTechnologyExtension))
    test_suite.addTest(unittest.makeSuite(TestFinancialExtension))
    
    # Add tests from test_data
    test_suite.addTest(unittest.makeSuite(TestDataDownload))
    test_suite.addTest(unittest.makeSuite(TestDataTransform))
    test_suite.addTest(unittest.makeSuite(TestDataUtils))
    
    # Run the tests
    runner = unittest.TextTestRunner()
    runner.run(test_suite)
