import unittest
import numpy as np
import pandas as pd
import os
from dsge_macro.data.download import download_us_macro_data, download_us_financial_data, transform_data_for_dsge, create_dsge_dataset
from dsge_macro.data.transform import log_transform, hp_filter_data, compute_growth_rates, linear_detrend, first_difference
from dsge_macro.data.utils import load_data, save_data, create_data_summary, plot_data_correlation_heatmap, plot_data_time_series

class TestDataDownload(unittest.TestCase):
    """Test cases for the data download functions."""
    
    def test_generate_synthetic_data(self):
        """Test synthetic data generation."""
        # Since we're using synthetic data, we can test the generation functions
        from scripts.generate_synthetic_data import generate_synthetic_macro_data, generate_synthetic_financial_data
        
        # Generate synthetic macro data
        macro_data = generate_synthetic_macro_data(start_year=2000, end_year=2020, frequency='Q')
        
        # Check that data is generated
        self.assertIsNotNone(macro_data)
        self.assertIsInstance(macro_data, pd.DataFrame)
        
        # Check that data has the correct shape
        expected_periods = (2020 - 2000 + 1) * 4  # Quarterly data
        self.assertEqual(len(macro_data), expected_periods)
        
        # Check that data contains key variables
        for var in ['gdp_real', 'consumption_real', 'investment_real', 'cpi']:
            self.assertIn(var, macro_data.columns)
            
        # Generate synthetic financial data
        financial_data = generate_synthetic_financial_data(start_date='2000-01-01', end_date='2020-12-31', frequency='M')
        
        # Check that data is generated
        self.assertIsNotNone(financial_data)
        self.assertIsInstance(financial_data, pd.DataFrame)
        
        # Check that data contains key variables
        for var in ['sp500', 'treasury_10y', 'vix']:
            self.assertIn(var, financial_data.columns)
    
    def test_transform_data_for_dsge(self):
        """Test data transformation for DSGE models."""
        # Generate synthetic data for testing
        np.random.seed(42)
        dates = pd.date_range(start='2000-01-01', periods=40, freq='Q')
        
        data = pd.DataFrame({
            'gdp_real': np.exp(np.log(100) + 0.01 * np.arange(40) + 0.02 * np.sin(np.arange(40) / 8) + 0.01 * np.random.randn(40)),
            'consumption_real': np.exp(np.log(60) + 0.008 * np.arange(40) + 0.015 * np.sin(np.arange(40) / 8) + 0.008 * np.random.randn(40)),
            'investment_real': np.exp(np.log(20) + 0.012 * np.arange(40) + 0.03 * np.sin(np.arange(40) / 8) + 0.015 * np.random.randn(40))
        }, index=dates)
        
        # Transform data for DSGE model
        transformed_data = transform_data_for_dsge(
            data, 
            output_freq='Q',
            detrend_method='hp',
            hp_lambda=1600,
            log_transform=True
        )
        
        # Check that transformed data is generated
        self.assertIsNotNone(transformed_data)
        self.assertIsInstance(transformed_data, pd.DataFrame)
        
        # Check that transformed data has the same variables
        for var in data.columns:
            self.assertIn(var, transformed_data.columns)
            
        # Check that transformed data has zero mean (detrended)
        for var in transformed_data.columns:
            self.assertAlmostEqual(transformed_data[var].mean(), 0, places=2)
    
    def test_create_dsge_dataset(self):
        """Test creation of DSGE dataset."""
        # Generate synthetic data for testing
        np.random.seed(42)
        dates = pd.date_range(start='2000-01-01', periods=40, freq='Q')
        
        macro_data = pd.DataFrame({
            'gdp_real': 0.01 * np.random.randn(40),
            'consumption_real': 0.01 * np.random.randn(40),
            'investment_real': 0.02 * np.random.randn(40)
        }, index=dates)
        
        financial_data = pd.DataFrame({
            'sp500': 0.02 * np.random.randn(40),
            'treasury_10y': 0.005 * np.random.randn(40),
            'vix': 0.1 * np.random.randn(40)
        }, index=dates)
        
        # Create DSGE dataset
        dsge_data = create_dsge_dataset(macro_data, financial_data)
        
        # Check that dataset is created
        self.assertIsNotNone(dsge_data)
        self.assertIsInstance(dsge_data, pd.DataFrame)
        
        # Check that dataset contains all variables
        for var in macro_data.columns:
            self.assertIn(var, dsge_data.columns)
            
        for var in financial_data.columns:
            self.assertIn(var, dsge_data.columns)


class TestDataTransform(unittest.TestCase):
    """Test cases for the data transformation functions."""
    
    def setUp(self):
        """Set up test data."""
        np.random.seed(42)
        dates = pd.date_range(start='2000-01-01', periods=40, freq='Q')
        
        self.data = pd.DataFrame({
            'gdp_real': np.exp(np.log(100) + 0.01 * np.arange(40) + 0.02 * np.sin(np.arange(40) / 8) + 0.01 * np.random.randn(40)),
            'consumption_real': np.exp(np.log(60) + 0.008 * np.arange(40) + 0.015 * np.sin(np.arange(40) / 8) + 0.008 * np.random.randn(40)),
            'investment_real': np.exp(np.log(20) + 0.012 * np.arange(40) + 0.03 * np.sin(np.arange(40) / 8) + 0.015 * np.random.randn(40))
        }, index=dates)
    
    def test_log_transform(self):
        """Test log transformation."""
        # Apply log transformation
        log_data = log_transform(self.data)
        
        # Check that log transformation is applied
        self.assertIsNotNone(log_data)
        self.assertIsInstance(log_data, pd.DataFrame)
        
        # Check that log transformation is correct
        for var in self.data.columns:
            self.assertTrue(np.allclose(log_data[var].values, np.log(self.data[var].values)))
    
    def test_hp_filter(self):
        """Test HP filter."""
        # Apply log transformation first
        log_data = log_transform(self.data)
        
        # Apply HP filter
        cycle, trend = hp_filter_data(log_data, lambda_param=1600)
        
        # Check that HP filter is applied
        self.assertIsNotNone(cycle)
        self.assertIsNotNone(trend)
        self.assertIsInstance(cycle, pd.DataFrame)
        self.assertIsInstance(trend, pd.DataFrame)
        
        # Check that cycle + trend = original data
        for var in log_data.columns:
            self.assertTrue(np.allclose(cycle[var].values + trend[var].values, log_data[var].values))
            
        # Check that cycle has zero mean
        for var in cycle.columns:
            self.assertAlmostEqual(cycle[var].mean(), 0, places=2)
    
    def test_growth_rates(self):
        """Test growth rate computation."""
        # Compute growth rates
        growth_data = compute_growth_rates(self.data, periods=1, annualize=False)
        
        # Check that growth rates are computed
        self.assertIsNotNone(growth_data)
        self.assertIsInstance(growth_data, pd.DataFrame)
        
        # Check that growth rates are correct
        for var in self.data.columns:
            expected_growth = self.data[var].pct_change(1)
            # Use dropna to ensure same length arrays
            actual = growth_data[var].dropna().values
            expected = expected_growth.dropna().values
            self.assertTrue(np.allclose(actual, expected, equal_nan=True))
    
    def test_linear_detrend(self):
        """Test linear detrending."""
        # Apply log transformation first
        log_data = log_transform(self.data)
        
        # Apply linear detrending
        detrended_data = linear_detrend(log_data)
        
        # Check that detrending is applied
        self.assertIsNotNone(detrended_data)
        self.assertIsInstance(detrended_data, pd.DataFrame)
        
        # Check that detrended data has zero mean
        for var in detrended_data.columns:
            self.assertAlmostEqual(detrended_data[var].mean(), 0, places=2)
    
    def test_first_difference(self):
        """Test first differencing."""
        # Apply log transformation first
        log_data = log_transform(self.data)
        
        # Apply first differencing
        diff_data = first_difference(log_data)
        
        # Check that differencing is applied
        self.assertIsNotNone(diff_data)
        self.assertIsInstance(diff_data, pd.DataFrame)
        
        # Check that differencing is correct
        for var in log_data.columns:
            expected_diff = log_data[var].diff(1)
            # Use dropna to ensure same length arrays
            actual = diff_data[var].dropna().values
            expected = expected_diff.dropna().values
            self.assertTrue(np.allclose(actual, expected, equal_nan=True))


class TestDataUtils(unittest.TestCase):
    """Test cases for the data utility functions."""
    
    def setUp(self):
        """Set up test data and directory."""
        np.random.seed(42)
        dates = pd.date_range(start='2000-01-01', periods=40, freq='Q')
        
        self.data = pd.DataFrame({
            'gdp_real': np.exp(np.log(100) + 0.01 * np.arange(40) + 0.02 * np.sin(np.arange(40) / 8) + 0.01 * np.random.randn(40)),
            'consumption_real': np.exp(np.log(60) + 0.008 * np.arange(40) + 0.015 * np.sin(np.arange(40) / 8) + 0.008 * np.random.randn(40)),
            'investment_real': np.exp(np.log(20) + 0.012 * np.arange(40) + 0.03 * np.sin(np.arange(40) / 8) + 0.015 * np.random.randn(40))
        }, index=dates)
        
        # Create test directory if it doesn't exist
        os.makedirs("test_data", exist_ok=True)
    
    def test_save_and_load_data(self):
        """Test saving and loading data."""
        # Save data
        save_data(self.data, "test_data/test_data.csv")
        
        # Check that file exists
        self.assertTrue(os.path.exists("test_data/test_data.csv"))
        
        # Load data
        loaded_data = load_data("test_data/test_data.csv")
        
        # Check that loaded data is correct
        self.assertIsNotNone(loaded_data)
        self.assertIsInstance(loaded_data, pd.DataFrame)
        self.assertEqual(loaded_data.shape, self.data.shape)
        
        # Clean up
        os.remove("test_data/test_data.csv")
    
    def test_create_data_summary(self):
        """Test data summary creation."""
        # Create data summary
        summary = create_data_summary(self.data)
        
        # Check that summary is created
        self.assertIsNotNone(summary)
        self.assertIsInstance(summary, pd.DataFrame)
        
        # Check that summary contains key statistics
        for stat in ['mean', 'std', 'min', 'max', 'median']:
            self.assertIn(stat, summary.columns)
            
        # Check that summary has entries for all variables
        for var in self.data.columns:
            self.assertIn(var, summary.index)
    
    def tearDown(self):
        """Clean up test directory."""
        if os.path.exists("test_data"):
            # Remove test directory
            os.rmdir("test_data")


if __name__ == "__main__":
    unittest.main()
