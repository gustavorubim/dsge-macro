        for friction_type in self.friction_types:
            model = self.models[friction_type]
            self.assertEqual(model.friction_type, friction_type)
            self.assertIn("efp", model.variables)  # All models have external finance premium
            
            if friction_type == "accelerator":
                self.assertIn("n", model.variables)    # Financial accelerator has net worth
                self.assertIn("lev", model.variables)  # Financial accelerator has leverage
            elif friction_type == "collateral":
                self.assertIn("n", model.variables)     # Collateral model has net worth
                self.assertIn("ltv", model.variables)   # Collateral model has loan-to-value ratio
            elif friction_type == "banking":
                self.assertIn("kb", model.variables)    # Banking model has bank capital
                self.assertIn("levb", model.variables)  # Banking model has bank leverage
            
    def test_financial_parameters(self):
        """Test financial parameters."""
        # Check financial accelerator parameters
        fa_model = self.models["accelerator"]
        self.assertIn("efp_ss", fa_model.parameters)