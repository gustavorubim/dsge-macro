import unittest
import numpy as np
import pandas as pd
from dsge_macro.estimation.bayesian import BayesianEstimator
from dsge_macro.estimation.mle import MLEstimator
from dsge_macro.estimation.calibration import Calibrator
from dsge_macro.core.smets_wouters import SWModel

class TestBayesianEstimator(unittest.TestCase):
    """Test cases for the BayesianEstimator class."""
    
    def setUp(self):
        """Set up a model and estimator."""
        self.model = SWModel()
        self.estimator = BayesianEstimator(self.model)
        
        # Create synthetic data for testing
        np.random.seed(42)
        dates = pd.date_range(start='2000-01-01', periods=40, freq='Q')
        self.data = pd.DataFrame({
            'y': 0.01 * np.random.randn(40),
            'c': 0.01 * np.random.randn(40),
            'i': 0.02 * np.random.randn(40),
            'l': 0.005 * np.random.randn(40),
            'r': 0.003 * np.random.randn(40),
            'pi': 0.002 * np.random.randn(40)
        }, index=dates)
        
    def test_initialization(self):
        """Test estimator initialization."""
        self.assertEqual(self.estimator.model, self.model)
        
    def test_prior_creation(self):
        """Test prior creation."""
        prior = self.estimator.create_prior()
        self.assertIsNotNone(prior)
        self.assertIsInstance(prior, dict)
        
        # Check that prior contains key parameters
        for param in ['beta', 'sigma_c', 'phi', 'alpha']:
            self.assertIn(param, prior)
            
    def test_likelihood_function(self):
        """Test likelihood function."""
        # Set parameters to test
        test_params = {param: self.model.parameters[param]['value'] for param in self.model.parameters}
        
        # Compute log likelihood
        log_lik = self.estimator.log_likelihood(test_params, self.data)
        
        # Check that log likelihood is a finite number
        self.assertIsInstance(log_lik, float)
        self.assertTrue(np.isfinite(log_lik))
        
    def test_posterior_function(self):
        """Test posterior function."""
        # Set parameters to test
        test_params = {param: self.model.parameters[param]['value'] for param in self.model.parameters}
        
        # Create prior
        prior = self.estimator.create_prior()
        
        # Compute log posterior
        log_post = self.estimator.log_posterior(test_params, self.data, prior)
        
        # Check that log posterior is a finite number
        self.assertIsInstance(log_post, float)
        self.assertTrue(np.isfinite(log_post))


class TestMLEstimator(unittest.TestCase):
    """Test cases for the MLEstimator class."""
    
    def setUp(self):
        """Set up a model and estimator."""
        self.model = SWModel()
        self.estimator = MLEstimator(self.model)
        
        # Create synthetic data for testing
        np.random.seed(42)
        dates = pd.date_range(start='2000-01-01', periods=40, freq='Q')
        self.data = pd.DataFrame({
            'y': 0.01 * np.random.randn(40),
            'c': 0.01 * np.random.randn(40),
            'i': 0.02 * np.random.randn(40),
            'l': 0.005 * np.random.randn(40),
            'r': 0.003 * np.random.randn(40),
            'pi': 0.002 * np.random.randn(40)
        }, index=dates)
        
    def test_initialization(self):
        """Test estimator initialization."""
        self.assertEqual(self.estimator.model, self.model)
        
    def test_likelihood_function(self):
        """Test likelihood function."""
        # Set parameters to test
        test_params = {param: self.model.parameters[param]['value'] for param in self.model.parameters}
        
        # Compute log likelihood
        log_lik = self.estimator.log_likelihood(test_params, self.data)
        
        # Check that log likelihood is a finite number
        self.assertIsInstance(log_lik, float)
        self.assertTrue(np.isfinite(log_lik))
        
    def test_standard_errors(self):
        """Test standard error computation."""
        # Create mock estimation results
        results = {
            'parameters': {param: self.model.parameters[param]['value'] for param in self.model.parameters},
            'log_likelihood': -100.0,
            'hessian': np.eye(len(self.model.parameters)) * 10  # Mock hessian
        }
        
        # Compute standard errors
        std_errors = self.estimator.compute_standard_errors(results)
        
        # Check that standard errors are computed for all parameters
        self.assertEqual(len(std_errors), len(self.model.parameters))
        
        # Check that standard errors are positive
        for param, se in std_errors.items():
            self.assertGreater(se, 0)


class TestCalibration(unittest.TestCase):
    """Test cases for the Calibrator class."""
    
    def setUp(self):
        """Set up a model and calibration."""
        self.model = SWModel()
        self.calibration = Calibrator(self.model)
        
    def test_initialization(self):
        """Test calibration initialization."""
        self.assertEqual(self.calibration.model, self.model)
        
    def test_calibrate_to_targets(self):
        """Test calibration to targets."""
        # Define targets
        targets = {
            'steady_state': {
                'r': 0.01,  # 1% quarterly real interest rate
                'pi': 0.005  # 0.5% quarterly inflation
            },
            'ratios': {
                'c_y': 0.6,  # Consumption to GDP ratio
                'i_y': 0.2   # Investment to GDP ratio
            }
        }
        
        # Set steady state targets
        self.calibration.set_steady_state_targets(targets['steady_state'])
        
        # Check that targets are set correctly
        self.assertEqual(self.calibration.targets['steady_state'], targets['steady_state'])
        
        # Check that model parameters exist
        self.assertNotEqual(self.model.parameters['beta']['value'], 0)  # Should have a non-zero value


if __name__ == "__main__":
    unittest.main()
