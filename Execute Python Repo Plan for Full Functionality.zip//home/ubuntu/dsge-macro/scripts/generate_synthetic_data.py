"""
Script to create synthetic US macroeconomic data for DSGE models.

Since we're having issues with the DataBank API, this script creates synthetic
US macroeconomic data that mimics the properties of real data for use with DSGE models.
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from typing import Dict, List, Tuple, Optional, Union
import statsmodels.api as sm
from datetime import datetime, timedelta

# Import data utilities
from dsge_macro.data.transform import (
    log_transform,
    compute_growth_rates,
    hp_filter_data,
    linear_detrend,
    first_difference,
    standardize_data,
    plot_transformed_data,
    plot_autocorrelations
)
from dsge_macro.data.utils import (
    save_data,
    create_data_summary,
    plot_data_correlation_heatmap,
    plot_data_time_series
)


def generate_synthetic_macro_data(start_year: int = 1980,
                                 end_year: int = 2023,
                                 frequency: str = 'Q',
                                 save_path: Optional[str] = None) -> pd.DataFrame:
    """Generate synthetic US macroeconomic data.
    
    Args:
        start_year (int, optional): Start year for data. Defaults to 1980.
        end_year (int, optional): End year for data. Defaults to 2023.
        frequency (str, optional): Data frequency. Defaults to 'Q' (quarterly).
        save_path (str, optional): Path to save the data. Defaults to None.
        
    Returns:
        pd.DataFrame: DataFrame containing synthetic US macroeconomic data
    """
    # Create date range
    if frequency == 'Q':
        periods = (end_year - start_year + 1) * 4
        start_date = f"{start_year}-01-01"
        date_range = pd.date_range(start=start_date, periods=periods, freq='Q')
    elif frequency == 'M':
        periods = (end_year - start_year + 1) * 12
        start_date = f"{start_year}-01-01"
        date_range = pd.date_range(start=start_date, periods=periods, freq='M')
    elif frequency == 'A':
        periods = end_year - start_year + 1
        start_date = f"{start_year}-01-01"
        date_range = pd.date_range(start=start_date, periods=periods, freq='A')
    else:
        raise ValueError(f"Unsupported frequency: {frequency}")
    
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Create time trend
    t = np.arange(len(date_range))
    
    # Generate synthetic data
    data_dict = {}
    
    # GDP and components
    # Real GDP (with trend, cycle, and noise)
    trend = 0.005 * t  # 0.5% quarterly growth trend
    cycle1 = 0.03 * np.sin(2 * np.pi * t / 20)  # 5-year business cycle
    cycle2 = 0.01 * np.sin(2 * np.pi * t / 8)   # 2-year cycle
    noise = 0.01 * np.random.randn(len(t))      # Random noise
    
    # Create log GDP
    log_gdp = 9.0 + trend + cycle1 + cycle2 + noise
    gdp = np.exp(log_gdp)
    data_dict["gdp_real"] = gdp
    
    # Consumption (correlated with GDP)
    consumption_share = 0.65 + 0.02 * np.sin(2 * np.pi * t / 32) + 0.01 * np.random.randn(len(t))
    consumption = consumption_share * gdp
    data_dict["consumption_real"] = consumption
    
    # Investment (more volatile than GDP)
    investment_share = 0.20 + 0.04 * np.sin(2 * np.pi * t / 16) + 0.02 * np.random.randn(len(t))
    investment = investment_share * gdp
    data_dict["investment_real"] = investment
    
    # Government spending
    government_share = 0.15 + 0.01 * np.sin(2 * np.pi * t / 40) + 0.005 * np.random.randn(len(t))
    government = government_share * gdp
    data_dict["government_real"] = government
    
    # Prices and inflation
    # CPI (with trend and noise)
    cpi_trend = 0.007 * t  # 0.7% quarterly inflation trend
    cpi_cycle = 0.02 * np.sin(2 * np.pi * t / 24)  # 6-year inflation cycle
    cpi_noise = 0.005 * np.random.randn(len(t))    # Random noise
    
    # Create log CPI
    log_cpi = 4.5 + cpi_trend + cpi_cycle + cpi_noise
    cpi = np.exp(log_cpi)
    data_dict["cpi"] = cpi
    
    # GDP deflator (correlated with CPI)
    deflator_noise = 0.003 * np.random.randn(len(t))
    log_deflator = log_cpi + deflator_noise
    deflator = np.exp(log_deflator)
    data_dict["gdp_deflator"] = deflator
    
    # Labor market
    # Labor force (growing with population)
    labor_trend = 0.0025 * t  # 0.25% quarterly growth
    labor_cycle = 0.005 * np.sin(2 * np.pi * t / 28)
    labor_noise = 0.002 * np.random.randn(len(t))
    
    log_labor = 11.0 + labor_trend + labor_cycle + labor_noise
    labor_force = np.exp(log_labor)
    data_dict["labor_force"] = labor_force
    
    # Employment (correlated with GDP)
    employment_cycle = 0.01 * np.sin(2 * np.pi * t / 20)  # Business cycle
    employment_noise = 0.003 * np.random.randn(len(t))
    
    # Employment is labor force minus unemployment
    employment_ratio = 0.94 + employment_cycle + employment_noise
    employment = labor_force * employment_ratio
    data_dict["employment"] = employment
    
    # Unemployment rate
    unemployment_rate = 100 * (1 - employment / labor_force)
    data_dict["unemployment_rate"] = unemployment_rate
    
    # Monetary indicators
    # Real interest rate (correlated with business cycle)
    real_rate_cycle = 0.5 * np.sin(2 * np.pi * t / 20)  # Business cycle
    real_rate_noise = 0.3 * np.random.randn(len(t))
    
    real_interest_rate = 2.0 + real_rate_cycle + real_rate_noise
    data_dict["real_interest_rate"] = real_interest_rate
    
    # Lending rate (real rate plus inflation)
    inflation = np.diff(log_cpi, prepend=log_cpi[0]) * 400  # Annualized inflation rate
    lending_rate = real_interest_rate + inflation
    data_dict["lending_rate"] = lending_rate
    
    # Broad money (correlated with GDP and inflation)
    money_trend = 0.01 * t  # 1% quarterly growth
    money_cycle = 0.02 * np.sin(2 * np.pi * t / 16)
    money_noise = 0.01 * np.random.randn(len(t))
    
    log_money = 9.5 + money_trend + money_cycle + money_noise
    broad_money = np.exp(log_money)
    data_dict["broad_money"] = broad_money
    
    # External sector
    # Current account (% of GDP)
    current_account_cycle = 2.0 * np.sin(2 * np.pi * t / 24)
    current_account_noise = 0.5 * np.random.randn(len(t))
    
    current_account = -2.0 + current_account_cycle + current_account_noise
    data_dict["current_account"] = current_account
    
    # Exports (correlated with global business cycle)
    exports_trend = 0.006 * t  # 0.6% quarterly growth
    exports_cycle = 0.04 * np.sin(2 * np.pi * t / 20)  # Business cycle
    exports_noise = 0.02 * np.random.randn(len(t))
    
    log_exports = 8.0 + exports_trend + exports_cycle + exports_noise
    exports = np.exp(log_exports)
    data_dict["exports_real"] = exports
    
    # Imports (correlated with GDP)
    imports_trend = 0.007 * t  # 0.7% quarterly growth
    imports_cycle = 0.03 * np.sin(2 * np.pi * t / 20)  # Business cycle
    imports_noise = 0.02 * np.random.randn(len(t))
    
    log_imports = 8.2 + imports_trend + imports_cycle + imports_noise
    imports = np.exp(log_imports)
    data_dict["imports_real"] = imports
    
    # Government
    # Government debt (% of GDP)
    debt_trend = 0.1 * t  # Increasing trend
    debt_cycle = 3.0 * np.sin(2 * np.pi * t / 40)  # Long cycle
    debt_noise = 1.0 * np.random.randn(len(t))
    
    government_debt = 40.0 + debt_trend + debt_cycle + debt_noise
    data_dict["government_debt"] = government_debt
    
    # Government revenue (% of GDP)
    revenue_cycle = 0.5 * np.sin(2 * np.pi * t / 16)
    revenue_noise = 0.3 * np.random.randn(len(t))
    
    government_revenue = 18.0 + revenue_cycle + revenue_noise
    data_dict["government_revenue"] = government_revenue
    
    # Government expenditure (% of GDP)
    expenditure_cycle = 0.7 * np.sin(2 * np.pi * t / 20)
    expenditure_noise = 0.4 * np.random.randn(len(t))
    
    government_expenditure = 20.0 + expenditure_cycle + expenditure_noise
    data_dict["government_expenditure"] = government_expenditure
    
    # Create DataFrame
    data = pd.DataFrame(data_dict, index=date_range)
    
    # Save data if path is provided
    if save_path:
        data.to_csv(save_path)
        print(f"Synthetic data saved to {save_path}")
    
    return data


def generate_synthetic_financial_data(start_date: str = '2000-01-01',
                                     end_date: Optional[str] = None,
                                     frequency: str = 'M',
                                     save_path: Optional[str] = None) -> pd.DataFrame:
    """Generate synthetic US financial data.
    
    Args:
        start_date (str, optional): Start date for data. Defaults to '2000-01-01'.
        end_date (str, optional): End date for data. Defaults to current date.
        frequency (str, optional): Data frequency. Defaults to 'M' (monthly).
        save_path (str, optional): Path to save the data. Defaults to None.
        
    Returns:
        pd.DataFrame: DataFrame containing synthetic US financial data
    """
    # Set end date to current date if not provided
    if end_date is None:
        end_date = datetime.now().strftime('%Y-%m-%d')
    
    # Create date range
    date_range = pd.date_range(start=start_date, end=end_date, freq=frequency)
    
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Create time trend
    t = np.arange(len(date_range))
    
    # Generate synthetic data
    data_dict = {}
    
    # S&P 500
    sp_trend = 0.005 * t  # 0.5% monthly growth trend
    sp_cycle1 = 0.1 * np.sin(2 * np.pi * t / 60)  # 5-year market cycle
    sp_cycle2 = 0.05 * np.sin(2 * np.pi * t / 24)  # 2-year cycle
    sp_noise = 0.03 * np.random.randn(len(t))      # Random noise
    
    # Create log S&P 500
    log_sp = 7.0 + sp_trend + sp_cycle1 + sp_cycle2 + sp_noise
    sp500 = np.exp(log_sp)
    data_dict["sp500"] = sp500
    
    # 10-Year Treasury Yield
    tnx_trend = -0.001 * t  # Declining trend
    tnx_cycle = 0.5 * np.sin(2 * np.pi * t / 48)  # 4-year cycle
    tnx_noise = 0.2 * np.random.randn(len(t))
    
    treasury_10y = 4.0 + tnx_trend + tnx_cycle + tnx_noise
    data_dict["treasury_10y"] = treasury_10y
    
    # 5-Year Treasury Yield
    fvx_trend = -0.001 * t  # Declining trend
    fvx_cycle = 0.4 * np.sin(2 * np.pi * t / 48)  # 4-year cycle
    fvx_noise = 0.15 * np.random.randn(len(t))
    
    treasury_5y = 3.5 + fvx_trend + fvx_cycle + fvx_noise
    data_dict["treasury_5y"] = treasury_5y
    
    # 13-Week Treasury Bill
    irx_trend = -0.001 * t  # Declining trend
    irx_cycle = 0.3 * np.sin(2 * np.pi * t / 48)  # 4-year cycle
    irx_noise = 0.1 * np.random.randn(len(t))
    
    treasury_13w = 2.5 + irx_trend + irx_cycle + irx_noise
    data_dict["treasury_13w"] = treasury_13w
    
    # Volatility Index (VIX)
    vix_cycle1 = 5.0 * np.sin(2 * np.pi * t / 60)  # 5-year cycle
    vix_cycle2 = 3.0 * np.sin(2 * np.pi * t / 12)  # 1-year cycle
    vix_noise = 2.0 * np.random.randn(len(t))
    
    vix = 20.0 + vix_cycle1 + vix_cycle2 + vix_noise
    data_dict["vix"] = vix
    
    # Dow Jones Industrial Average
    dji_trend = 0.005 * t  # 0.5% monthly growth trend
    dji_cycle1 = 0.1 * np.sin(2 * np.pi * t / 60)  # 5-year market cycle
    dji_cycle2 = 0.05 * np.sin(2 * np.pi * t / 24)  # 2-year cycle
    dji_noise = 0.03 * np.random.randn(len(t))      # Random noise
    
    # Create log Dow Jones
    log_dji = 9.5 + dji_trend + dji_cycle1 + dji_cycle2 + dji_noise
    dow_jones = np.exp(log_dji)
    data_dict["dow_jones"] = dow_jones
    
    # NASDAQ Composite
    nasdaq_trend = 0.006 * t  # 0.6% monthly growth trend
    nasdaq_cycle1 = 0.12 * np.sin(2 * np.pi * t / 60)  # 5-year market cycle
    nasdaq_cycle2 = 0.06 * np.sin(2 * np.pi * t / 24)  # 2-year cycle
    nasdaq_noise = 0.04 * np.random.randn(len(t))      # Random noise
    
    # Create log NASDAQ
    log_nasdaq = 7.5 + nasdaq_trend + nasdaq_cycle1 + nasdaq_cycle2 + nasdaq_noise
    nasdaq = np.exp(log_nasdaq)
    data_dict["nasdaq"] = nasdaq
    
    # Gold Futures
    gold_trend = 0.003 * t  # 0.3% monthly growth trend
    gold_cycle1 = 0.08 * np.sin(2 * np.pi * t / 72)  # 6-year cycle
    gold_cycle2 = 0.04 * np.sin(2 * np.pi * t / 24)  # 2-year cycle
    gold_noise = 0.02 * np.random.randn(len(t))      # Random noise
    
    # Create log Gold
    log_gold = 6.0 + gold_trend + gold_cycle1 + gold_cycle2 + gold_noise
    gold = np.exp(log_gold)
    data_dict["gold"] = gold
    
    # Oil Futures
    oil_trend = 0.002 * t  # 0.2% monthly growth trend
    oil_cycle1 = 0.15 * np.sin(2 * np.pi * t / 48)  # 4-year cycle
    oil_cycle2 = 0.1 * np.sin(2 * np.pi * t / 12)   # 1-year cycle
    oil_noise = 0.05 * np.random.randn(len(t))      # Random noise
    
    # Create log Oil
    log_oil = 4.0 + oil_trend + oil_cycle1 + oil_cycle2 + oil_noise
    oil = np.exp(log_oil)
    data_dict["oil"] = oil
    
    # Create DataFrame
    data = pd.DataFrame(data_dict, index=date_range)
    
    # Save data if path is provided
    if save_path:
        data.to_csv(save_path)
        print(f"Synthetic financial data saved to {save_path}")
    
    return data


def transform_data_for_dsge(data: pd.DataFrame, 
                           output_freq: str = 'Q',
                           detrend_method: str = 'hp',
                           hp_lambda: float = 1600,
                           log_transform: bool = True,
                           save_path: Optional[str] = None) -> pd.DataFrame:
    """Transform macroeconomic data for use with DSGE models.
    
    Args:
        data (pd.DataFrame): Raw macroeconomic data
        output_freq (str, optional): Output frequency. Defaults to 'Q' (quarterly).
        detrend_method (str, optional): Detrending method. Defaults to 'hp'.
            Options: 'hp' (Hodrick-Prescott), 'linear', 'first_diff', 'pct_change'
        hp_lambda (float, optional): Lambda parameter for HP filter. Defaults to 1600.
        log_transform (bool, optional): Whether to log-transform data. Defaults to True.
        save_path (str, optional): Path to save the transformed data. Defaults to None.
        
    Returns:
        pd.DataFrame: DataFrame containing transformed data
    """
    # Check if data is annual and needs to be converted
    is_annual = isinstance(data.index[0], (int, np.integer))
    
    if is_annual:
        # Convert annual data to datetime index
        data.index = pd.to_datetime([f"{year}-01-01" for year in data.index])
    
    # Resample data to desired frequency if needed
    if output_freq != 'A':
        # Define aggregation methods for different variables
        agg_methods = {}
        for col in data.columns:
            if 'rate' in col or col.endswith('_ratio'):
                # Use mean for rates and ratios
                agg_methods[col] = 'mean'
            else:
                # Use last value for levels
                agg_methods[col] = 'last'
        
        # Resample data
        data = data.resample(output_freq).agg(agg_methods)
    
    # Apply log transformation if requested
    if log_transform:
        for col in data.columns:
            # Skip rates, ratios, and columns with negative values
            if ('rate' in col or col.endswith('_ratio') or 
                (data[col] <= 0).any()):
                continue
            
            # Apply log transformation
            data[col] = np.log(data[col])
    
    # Detrend data
    detrended_data = pd.DataFrame(index=data.index)
    
    for col in data.columns:
        # Skip columns with missing values
        if data[col].isna().any():
            print(f"Skipping {col} due to missing values")
            continue
        
        # Apply detrending method
        if detrend_method == 'hp':
            # Apply HP filter
            cycle, trend = sm.tsa.filters.hpfilter(data[col], lamb=hp_lambda)
            detrended_data[col] = cycle
        elif detrend_method == 'linear':
            # Apply linear detrending
            x = np.arange
(Content truncated due to size limit. Use line ranges to read in chunks)