"""
Script to download and prepare US macroeconomic data for DSGE models.

This script downloads US macroeconomic and financial data and prepares it
for use with DSGE models.
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from typing import Dict, List, Tuple, Optional, Union
import statsmodels.api as sm

# Add path for data API access
sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient

# Import data utilities
from dsge_macro.data.download import (
    download_us_macro_data,
    download_us_financial_data,
    transform_data_for_dsge,
    create_dsge_dataset,
    plot_data_overview,
    compute_data_moments,
    compute_correlations
)
from dsge_macro.data.transform import (
    log_transform,
    compute_growth_rates,
    hp_filter_data,
    linear_detrend,
    first_difference,
    seasonal_adjust,
    standardize_data,
    plot_transformed_data,
    plot_autocorrelations
)
from dsge_macro.data.utils import (
    save_data,
    create_data_summary,
    plot_data_correlation_heatmap,
    plot_data_time_series
)


def main():
    """Main function to download and prepare US macroeconomic data."""
    # Create data directory if it doesn't exist
    os.makedirs("data", exist_ok=True)
    
    print("=== Downloading US Macroeconomic Data ===")
    # Download US macroeconomic data (1980-2023)
    macro_data = download_us_macro_data(
        start_year=1980, 
        end_year=2023, 
        save_path="data/us_macro_data_raw.csv"
    )
    
    print("\n=== Downloading US Financial Data ===")
    # Download US financial data (2000-present)
    financial_data = download_us_financial_data(
        start_date='2000-01-01',
        save_path="data/us_financial_data_raw.csv"
    )
    
    print("\n=== Creating Data Summary ===")
    # Create summary of the raw data
    macro_summary = create_data_summary(
        macro_data, 
        save_path="data/us_macro_data_summary.csv"
    )
    financial_summary = create_data_summary(
        financial_data, 
        save_path="data/us_financial_data_summary.csv"
    )
    
    print("\n=== Transforming Macroeconomic Data ===")
    # Transform macroeconomic data for DSGE model
    # 1. Convert to quarterly frequency
    # 2. Apply HP filter for detrending
    # 3. Log-transform appropriate variables
    transformed_data = transform_data_for_dsge(
        macro_data, 
        output_freq='Q',
        detrend_method='hp',
        hp_lambda=1600,
        log_transform=True,
        save_path="data/us_macro_data_transformed.csv"
    )
    
    print("\n=== Creating DSGE Dataset ===")
    # Create DSGE dataset by merging macroeconomic and financial data
    dsge_data = create_dsge_dataset(
        transformed_data, 
        financial_data,
        start_date='2000-01-01',
        save_path="data/us_dsge_dataset.csv"
    )
    
    print("\n=== Plotting Data Overview ===")
    # Plot overview of the DSGE dataset
    plot_data_overview(
        dsge_data, 
        figsize=(15, 10),
        ncols=3,
        save_path="data/us_data_overview.png"
    )
    
    print("\n=== Computing Data Moments ===")
    # Compute moments of the DSGE dataset
    moments = compute_data_moments(
        dsge_data, 
        save_path="data/us_data_moments.csv"
    )
    
    print("\n=== Computing Correlations ===")
    # Compute correlations with GDP
    gdp_correlations = compute_correlations(
        dsge_data, 
        'gdp_real', 
        save_path="data/us_gdp_correlations.csv"
    )
    
    print("\n=== Creating Correlation Heatmap ===")
    # Create correlation heatmap
    plot_data_correlation_heatmap(
        dsge_data,
        figsize=(12, 10),
        save_path="data/us_data_correlation_heatmap.png"
    )
    
    print("\n=== Plotting Autocorrelations ===")
    # Plot autocorrelations
    plot_autocorrelations(
        dsge_data,
        lags=10,
        save_path="data/us_data_autocorrelations.png"
    )
    
    print("\n=== Creating Alternative Transformations ===")
    # Create alternative transformations for comparison
    
    # 1. First difference transformation
    diff_data = first_difference(
        log_transform(macro_data),
        save_path="data/us_macro_data_diff.csv"
    )
    
    # 2. Growth rates
    growth_data = compute_growth_rates(
        macro_data,
        periods=4,  # Annual growth rate
        annualize=True,
        save_path="data/us_macro_data_growth.csv"
    )
    
    # 3. Linear detrending
    linear_data = linear_detrend(
        log_transform(macro_data),
        save_path="data/us_macro_data_linear.csv"
    )
    
    print("\n=== Comparing Transformations ===")
    # Compare HP filter with other transformations
    # Select a few key variables for comparison
    key_vars = ['gdp_real', 'consumption_real', 'investment_real']
    
    # Compare HP filter with first difference
    plot_transformed_data(
        transformed_data[key_vars],
        diff_data[key_vars],
        transformation_name='First Difference',
        save_path="data/comparison_hp_vs_diff.png"
    )
    
    # Compare HP filter with growth rates
    plot_transformed_data(
        transformed_data[key_vars],
        growth_data[key_vars],
        transformation_name='Growth Rate',
        save_path="data/comparison_hp_vs_growth.png"
    )
    
    # Compare HP filter with linear detrending
    plot_transformed_data(
        transformed_data[key_vars],
        linear_data[key_vars],
        transformation_name='Linear Detrend',
        save_path="data/comparison_hp_vs_linear.png"
    )
    
    print("\n=== Data Preparation Complete ===")
    print(f"All data files saved to the 'data' directory")


if __name__ == "__main__":
    main()
