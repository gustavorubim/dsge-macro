"""
DSGE-Macro package setup script.

This script configures the package for installation.
"""

from setuptools import setup, find_packages

setup(
    name="dsge-macro",
    version="0.1.0",
    description="A comprehensive Python package for DSGE macroeconomic modeling",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="DSGE-Macro Team",
    author_email="example@example.com",
    url="https://github.com/yourusername/dsge-macro",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "numpy>=1.20.0",
        "scipy>=1.7.0",
        "pandas>=1.3.0",
        "matplotlib>=3.4.0",
        "seaborn>=0.11.0",
        "jax>=0.3.0",
        "jaxlib>=0.3.0",
        "pymc>=4.0.0",
        "xarray>=0.20.0",
        "statsmodels>=0.13.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0.0",
            "pytest-cov>=2.12.0",
            "black>=21.5b2",
            "isort>=5.9.0",
            "flake8>=3.9.0",
            "sphinx>=4.0.0",
            "sphinx-rtd-theme>=0.5.0",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Topic :: Scientific/Engineering :: Economics",
    ],
    python_requires=">=3.8",
)
